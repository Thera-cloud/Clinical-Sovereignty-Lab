import asyncio
import re
import websockets
import json
import random
import datetime
import os
import shutil
import secrets
import hashlib
import uuid
import sys
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple

# NOTE:
# - In production, this module is executed as `python -m app.websocket.bridge_server`
# - In local dev, it is sometimes run directly (`python bridge_server.py`)
# So we support both import styles.
try:
    from .nevedal_handlers import NevedalHandler
    from .sanctuary_engine import FamilySanctuaryEngine
    from .bridge_handlers_v2 import CoachNexusV2
    from .device_protection import (
        handle_device_validation,
        get_user_devices,
        remove_device,
        force_logout_all_devices,
        get_device_limit,
        admin_get_user_devices,
        admin_reset_user_devices,
        detect_suspicious_activity,
    )
except Exception:
    from nevedal_handlers import NevedalHandler
    from sanctuary_engine import FamilySanctuaryEngine
    from bridge_handlers_v2 import CoachNexusV2
    from device_protection import (
        handle_device_validation,
        get_user_devices,
        remove_device,
        force_logout_all_devices,
        get_device_limit,
        admin_get_user_devices,
        admin_reset_user_devices,
        detect_suspicious_activity,
    )

# Optional Night School modules (bridge should run without them)
NightSchoolCurriculum = None
NightSchoolHandler = None
try:
    from .night_school_curriculum import NightSchoolCurriculum  # type: ignore
except Exception as e:
    try:
        from night_school_curriculum import NightSchoolCurriculum  # type: ignore
    except Exception:
        NightSchoolCurriculum = None
        print(f"[!] night_school_curriculum not found - curriculum disabled ({e})")

try:
    from .night_school_handlers import NightSchoolHandler  # type: ignore
except Exception as e:
    try:
        from night_school_handlers import NightSchoolHandler  # type: ignore
    except Exception:
        NightSchoolHandler = None
        print(f"[!] night_school_handlers not found - Dojo disabled ({e})")

# Optional: Local workbook retrieval for best-practice therapeutic guidance
try:
    from app.services.workbook_library import WorkbookLibrary
except Exception:
    WorkbookLibrary = None


# ==============================================================================
# SOVEREIGN BRIDGE v16.1: COMPLETE EDITION + ALL HANDLERS
# Full metrics, session tracking, e-commerce support, coach features
# ==============================================================================

# ------------------------------------------------------------------------------
# PART 1: INFRASTRUCTURE & CONFIGURATION
# ------------------------------------------------------------------------------
HOST = "0.0.0.0"
PORT = 8765
REQUIRED_CONSENT_VERSION = "v12.6_2026_FINAL"

# Load Environment Variables
try:
    from dotenv import load_dotenv
    script_dir = Path(__file__).resolve().parent
    # Allow importing `app.*` modules when running this file directly.
    backend_dir = script_dir.parents[2]  # .../backend
    if str(backend_dir) not in sys.path:
        sys.path.insert(0, str(backend_dir))
    master_env = script_dir.parent / '.env'
    if not master_env.exists(): master_env = script_dir / '.env'
    load_dotenv(dotenv_path=master_env, override=True)
except ImportError: pass

AZURE_API_KEY = os.getenv("AZURE_API_KEY")
_ep = os.getenv("AZURE_OPENAI_ENDPOINT", "").replace("https://", "").replace("wss://", "").replace("/", "")
AZURE_ENDPOINT = f"wss://{_ep}/openai/realtime?api-version=2024-10-01-preview&deployment={os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4o-realtime-preview')}"
# Azure OpenAI Helper Function
async def call_azure_openai(prompt: str, system_message: str = "You are a helpful assistant.", max_tokens: int = 2000) -> str:
    """Call Azure OpenAI Realtime API and return full response text"""
    import aiohttp
    
    url = AZURE_ENDPOINT
    headers = {
        "api-key": AZURE_API_KEY,
        "OpenAI-Beta": "realtime=v1"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.ws_connect(url, headers=headers) as azure_ws:
                # Configure session
                await azure_ws.send_str(json.dumps({
                    "type": "session.update",
                    "session": {
                        "modalities": ["text"],
                        "instructions": system_message,
                        "voice": "alloy",
                        "turn_detection": None
                    }
                }))
                
                # Send user message
                await azure_ws.send_str(json.dumps({
                    "type": "conversation.item.create",
                    "item": {
                        "type": "message",
                        "role": "user",
                        "content": [{"type": "input_text", "text": prompt}]
                    }
                }))
                
                # Request response
                await azure_ws.send_str(json.dumps({"type": "response.create"}))
                
                # Collect full response
                full_response = ""
                async for msg in azure_ws:
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        event = json.loads(msg.data)
                        event_type = event.get("type")
                        
                        if event_type == "response.text.delta":
                            full_response += event.get("delta", "")
                        elif event_type in ["response.text.done", "response.done"]:
                            break
                        elif event_type == "error":
                            raise Exception(f"Azure error: {event}")
                
                return full_response
                
    except Exception as e:
        print(f">>> [AZURE] call_azure_openai error: {e}")
        raise

async def update_client_story(
    client_id: str,
    member_name: str,
    summary_data: dict,
    messages: list,
    coaching_sessions: dict,
    eft_tracker: dict = None,
    reconsolidation_tracker: dict = None,
):
    """
    Update client's story.json with insights from completed sanctuary session.
    This grows Little Nate's relational wisdom about each person.
    """
    story_path = os.path.join(DATA_DIR, "Vaults", "Clients", client_id, "story.json")
    
    # Load existing story or create new one
    if os.path.exists(story_path):
        with open(story_path, 'r') as f:
            story = json.load(f)
    else:
        # Create minimal story structure
        os.makedirs(os.path.dirname(story_path), exist_ok=True)
        story = {
            "client_id": client_id,
            "name": member_name,
            "story_version": 1,
            "who_you_are": {"strengths": [], "values": []},
            "wounds": {"core_wounds": [], "recent_hurts": []},
            "growth": {"breakthroughs": [], "progress_markers": []},
            "patterns": {"when_activated": {}},
            "therapeutic_alliance": {"trust_level": "new", "what_builds_trust": []},
            "unfinished_business": [],
            "corrective_experiences_needed": [],
            "little_nate_notes": {"remember_to": [], "watch_for": []}
        }
    
    # Get individual insights for this member
    individual = summary_data.get("individual_insights", {}).get(member_name, {})
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    
    # === ADD BREAKTHROUGHS ===
    corrective_experiences = summary_data.get("corrective_experiences", [])
    for ce in corrective_experiences:
        if ce and len(ce) > 10:
            breakthrough = {
                "date": today,
                "moment": ce,
                "context": "Family Sanctuary session",
                "anchor_phrase": f"Remember this moment of connection, {member_name}"
            }
            # Avoid duplicates
            existing_moments = [b.get("moment", "")[:50] for b in story.get("growth", {}).get("breakthroughs", [])]
            if ce[:50] not in existing_moments:
                if "growth" not in story:
                    story["growth"] = {"breakthroughs": [], "progress_markers": []}
                story["growth"]["breakthroughs"].append(breakthrough)
    
    # === ADD PATTERNS OBSERVED ===
    patterns_observed = individual.get("patterns_observed", "")
    if patterns_observed and patterns_observed != "Review needed" and len(patterns_observed) > 10:
        if "patterns" not in story:
            story["patterns"] = {"when_activated": {}}
        if "session_patterns" not in story["patterns"]:
            story["patterns"]["session_patterns"] = []
        story["patterns"]["session_patterns"].append({
            "date": today,
            "observation": patterns_observed
        })
        # Keep last 10
        story["patterns"]["session_patterns"] = story["patterns"]["session_patterns"][-10:]
    
    # === ADD GROWTH AREAS ===
    growth_areas = individual.get("growth_areas", "")
    if growth_areas and growth_areas != "Discuss with coach" and len(growth_areas) > 10:
        if "growth" not in story:
            story["growth"] = {"breakthroughs": [], "progress_markers": [], "edges_of_growth": []}
        if "edges_of_growth" not in story["growth"]:
            story["growth"]["edges_of_growth"] = []
        # Add if not duplicate
        if growth_areas not in story["growth"]["edges_of_growth"]:
            story["growth"]["edges_of_growth"].append(growth_areas)
            story["growth"]["edges_of_growth"] = story["growth"]["edges_of_growth"][-5:]
    
    # === ADD STRENGTHS SHOWN ===
    strengths = individual.get("strengths_shown", "")
    if strengths and strengths != "Participated in session" and len(strengths) > 10:
        if "who_you_are" not in story:
            story["who_you_are"] = {"strengths": [], "values": []}
        if strengths not in story["who_you_are"]["strengths"]:
            story["who_you_are"]["strengths"].append(strengths)
            story["who_you_are"]["strengths"] = story["who_you_are"]["strengths"][-7:]
    
    # === CHECK FOR UNFINISHED BUSINESS FROM KEY CONFLICTS ===
    key_conflicts = summary_data.get("key_conflicts", [])
    for conflict in key_conflicts:
        if conflict and "Please review" not in conflict and len(conflict) > 10:
            # Check if already tracked
            existing_topics = [u.get("topic", "")[:30] for u in story.get("unfinished_business", [])]
            if conflict[:30] not in existing_topics:
                if "unfinished_business" not in story:
                    story["unfinished_business"] = []
                story["unfinished_business"].append({
                    "topic": conflict,
                    "status": "identified in sanctuary",
                    "importance": "medium",
                    "date_identified": today
                })
                story["unfinished_business"] = story["unfinished_business"][-5:]
    
    # === SCAN MESSAGES FOR SIGNIFICANT DISCLOSURES ===
    danger_words = {
        "hit me": "Physical abuse disclosed",
        "hits me": "Physical abuse disclosed", 
        "hitting me": "Physical abuse disclosed",
        "abuse": "Abuse mentioned",
        "scared of": "Fear/safety concern",
        "unsafe": "Safety concern",
        "suicide": "Crisis - suicidal ideation",
        "kill myself": "Crisis - suicidal ideation",
        "hurt myself": "Crisis - self-harm"
    }
    
    for msg in messages:
        if msg.get("sender_id") == client_id:
            content_lower = msg.get("content", "").lower()
            for phrase, label in danger_words.items():
                if phrase in content_lower:
                    # Add to wounds/recent_hurts
                    hurt_entry = {
                        "date": today,
                        "event": label,
                        "status": "disclosed - needs follow-up",
                        "context": msg.get("content", "")[:100]
                    }
                    existing_events = [h.get("event", "") for h in story.get("wounds", {}).get("recent_hurts", [])]
                    if label not in existing_events:
                        if "wounds" not in story:
                            story["wounds"] = {"core_wounds": [], "recent_hurts": []}
                        if "recent_hurts" not in story["wounds"]:
                            story["wounds"]["recent_hurts"] = []
                        story["wounds"]["recent_hurts"].append(hurt_entry)
                    
                    # Add to little_nate_notes
                    reminder = f"Member disclosed: {label} - validate and follow up"
                    if "little_nate_notes" not in story:
                        story["little_nate_notes"] = {"remember_to": [], "watch_for": []}
                    if reminder not in story["little_nate_notes"].get("remember_to", []):
                        story["little_nate_notes"]["remember_to"].append(reminder)
                    break

    # === EFT LONGINGS (Attachment needs) ===
    # Store compact, longitudinal signals for Little Nate's memory.
    if eft_tracker and isinstance(eft_tracker, dict):
        try:
            member_longings = (eft_tracker.get("member_longings") or {}).get(client_id, []) or []
            # Keep only last ~12 longing entries per member
            story.setdefault("attachment_longings", [])
            for l in member_longings[-6:]:
                # Minimal, safe schema
                entry = {
                    "date": today,
                    "type": l.get("type"),
                    "expressed_as": (l.get("expressed_as") or "")[:200],
                    "underlying_need": (l.get("underlying_need") or "")[:200],
                    "wound_indicated": (l.get("wound_indicated") or "")[:200] if l.get("wound_indicated") else None,
                }
                story["attachment_longings"].append(entry)
            story["attachment_longings"] = story["attachment_longings"][-12:]

            # Store negative cycle snapshot (shared)
            cycle = eft_tracker.get("negative_cycle")
            if cycle:
                story.setdefault("patterns", {}).setdefault("attachment_cycles", [])
                story["patterns"]["attachment_cycles"].append({
                    "date": today,
                    "pattern": cycle.get("pattern"),
                    "description": (cycle.get("description") or "")[:240],
                    "roles": (cycle.get("roles") or "")[:120] if cycle.get("roles") else None,
                })
                story["patterns"]["attachment_cycles"] = story["patterns"]["attachment_cycles"][-6:]

            # Gentle watch-for reminders
            story.setdefault("little_nate_notes", {"remember_to": [], "watch_for": []})
            if member_longings:
                reminder = f"EFT longing signal: {member_longings[-1].get('type', 'UNKNOWN')} (help deepen + enact)"
                if reminder not in story["little_nate_notes"].get("watch_for", []):
                    story["little_nate_notes"]["watch_for"].append(reminder)
                    story["little_nate_notes"]["watch_for"] = story["little_nate_notes"]["watch_for"][-12:]
        except Exception as e:
            print(f">>> [STORY] EFT write error for {client_id}: {e}")

    # === MEMORY RECONSOLIDATION (Schemas + verified shifts) ===
    if reconsolidation_tracker and isinstance(reconsolidation_tracker, dict):
        try:
            story.setdefault("schemas", [])
            story.setdefault("reconsolidations", [])

            schemas = reconsolidation_tracker.get("schemas") or {}
            # store per-member schema summaries (bounded)
            for _, s in list(schemas.items())[-10:]:
                if s.get("member_id") != client_id:
                    continue
                story["schemas"].append({
                    "date": today,
                    "core_belief": (s.get("core_belief") or "")[:220],
                    "emotional_charge": s.get("emotional_charge"),
                    "origin_hint": s.get("origin_hint"),
                    "activation_count": s.get("activation_count", 0),
                    "reconsolidation_complete": bool(s.get("reconsolidation_complete")),
                })
            story["schemas"] = story["schemas"][-20:]

            # store reconsolidation completions (bounded)
            for r in (reconsolidation_tracker.get("reconsolidations") or [])[-8:]:
                # Only keep those tied to this member via schema lookup when possible
                sid = r.get("schema_id")
                s = schemas.get(sid) if isinstance(schemas, dict) else None
                if s and s.get("member_id") != client_id:
                    continue
                story["reconsolidations"].append({
                    "date": today,
                    "old_belief": (r.get("old_belief") or "")[:200],
                    "new_belief": (r.get("new_belief") or "")[:200],
                    "confidence": r.get("confidence"),
                    "verification_response": (r.get("verification_response") or "")[:240],
                })
            story["reconsolidations"] = story["reconsolidations"][-20:]

            story.setdefault("little_nate_notes", {"remember_to": [], "watch_for": []})
            if story["reconsolidations"]:
                reminder = "Reconsolidation work present: continue consolidation prompts in next session if needed"
                if reminder not in story["little_nate_notes"].get("watch_for", []):
                    story["little_nate_notes"]["watch_for"].append(reminder)
                    story["little_nate_notes"]["watch_for"] = story["little_nate_notes"]["watch_for"][-12:]
        except Exception as e:
            print(f">>> [STORY] Reconsolidation write error for {client_id}: {e}")
    
    # === UPDATE METADATA ===
    story["story_updated"] = today
    story["story_version"] = story.get("story_version", 0) + 1
    
    # === SAVE ===
    with open(story_path, 'w') as f:
        json.dump(story, f, indent=2)
    
    print(f">>> [STORY] Updated story.json for {member_name} ({client_id})")
    return True

# Stripe Configuration
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY")
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET")

# SendGrid Configuration
SENDGRID_API_KEY = os.getenv("SENDGRID_API_KEY") 

# Database Setup
# - In Docker: default to /app/data
# - Locally: if /app/data isn't writable, fall back to ./data next to this file
current_dir = Path(__file__).resolve().parent
parent_dir = current_dir.parent

_env_data_dir = os.getenv("DATA_DIR")
DATA_DIR = Path(_env_data_dir) if _env_data_dir else Path("/app/data")
try:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
except OSError as e:
    # If user explicitly set DATA_DIR, surface the error (misconfiguration)
    if _env_data_dir:
        raise
    # Otherwise, assume we're running locally (macOS/Windows) and use ./data
    DATA_DIR = current_dir / "data"
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    print(f">>> [DATA_DIR] Falling back to local path: {DATA_DIR} (reason: {e})")

MASTER_PATH = DATA_DIR
print(f"[*] Database Root: {MASTER_PATH}")

VAULT_ROOT = DATA_DIR / "Vaults"
REGISTRY_FILE = DATA_DIR / "user_registry.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"
BILLING_FILE = DATA_DIR / "billing.json"
ANALYTICS_FILE = DATA_DIR / "analytics.json"
CRISIS_LOG_FILE = DATA_DIR / "crisis_log.json"
COACH_SESSION_NOTES_FILE = DATA_DIR / "coach_session_notes.json"
COACH_LIVE_SESSIONS_FILE = DATA_DIR / "coach_live_sessions.json"
COACH_LEARNING_QUEUE_FILE = DATA_DIR / "coach_learning_queue.json"
COACH_LEARNING_ARCHIVE_FILE = DATA_DIR / "coach_learning_archive.json"
COACH_COMPENSATION_LEDGER_FILE = DATA_DIR / "coach_compensation_ledger.json"

# In production, bridge mounts backend data read-only at /app/backend_data.
# Use it as a source-of-truth for shared registries where possible.
BACKEND_DATA_DIR = Path("/app/backend_data")
BACKEND_REGISTRY_FILE = BACKEND_DATA_DIR / "user_registry.json"
BACKEND_VAULT_ROOT = BACKEND_DATA_DIR / "Vaults"

# If enabled, coach-shared learnings go straight into Night School (no admin gate).
# Keep OFF by default to prevent corruption.
AUTO_APPROVE_COACH_LEARNING = os.getenv("AUTO_APPROVE_COACH_LEARNING", "").strip() in ("1", "true", "TRUE", "yes", "YES")

# Retention / anti-waste controls (safe defaults)
def _int_env(name: str, default: int) -> int:
    try:
        v = int(str(os.getenv(name, "")).strip() or default)
        return v
    except Exception:
        return default

COACH_LEARNING_RETENTION_DAYS = _int_env("COACH_LEARNING_RETENTION_DAYS", 90)
COACH_LEARNING_QUEUE_MAX_ITEMS = _int_env("COACH_LEARNING_QUEUE_MAX_ITEMS", 2000)
COACH_LEARNING_ARCHIVE_MAX_ITEMS = _int_env("COACH_LEARNING_ARCHIVE_MAX_ITEMS", 20000)
COACH_LIVE_SESSIONS_MAX_ENDED = _int_env("COACH_LIVE_SESSIONS_MAX_ENDED", 500)

ACTIVE_TOKENS = {}
LIVE_SESSION_TRACKER = {}
ACTIVE_WEBSOCKETS = {}

# Directory Structure
for folder in ["Admin", "Coaches", "Clients", "Guests"]:
    (VAULT_ROOT / folder).mkdir(parents=True, exist_ok=True)
(VAULT_ROOT / "Admin" / "admin_LN_training_folder").mkdir(parents=True, exist_ok=True)

# Workbooks live at repo root: ./Workbooks
WORKBOOKS_DIR = Path(__file__).resolve().parents[3] / "Workbooks"
workbook_library = WorkbookLibrary(WORKBOOKS_DIR) if WorkbookLibrary else None

# ------------------------------------------------------------------------------
# PART 2: UTILITY FUNCTIONS
# ------------------------------------------------------------------------------
def hash_password(password: str) -> str:
    """Hash password with salt for secure storage"""
    salt = secrets.token_hex(16)
    hashed = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
    return f"{salt}:{hashed.hex()}"

def verify_password(password: str, stored_hash: str) -> bool:
    """Verify password against stored hash"""
    try:
        salt, hash_hex = stored_hash.split(':')
        hashed = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
        return hashed.hex() == hash_hex
    except:
        # Fallback for plain text passwords (legacy)
        return password == stored_hash

def generate_session_id() -> str:
    """Generate unique session ID"""
    return f"SES_{datetime.datetime.now().strftime('%Y%m%d')}_{secrets.token_hex(6).upper()}"

def load_json_file(filepath: Path, default: Any = None) -> Any:
    """Safely load JSON file"""
    if default is None:
        default = {}
    if not filepath.exists():
        return default
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except:
        return default

def save_json_file(filepath: Path, data: Any) -> bool:
    """Safely save JSON file with backup"""
    try:
        # Ensure parent directory exists (important in Docker/bind-mount setups)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        backup = str(filepath) + ".bak"
        if filepath.exists():
            os.rename(filepath, backup)
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, default=str)
        return True
    except Exception as e:
        print(f">>> [ERROR] Failed to save {filepath}: {e}")
        return False


def ensure_json_file(filepath: Path, default: Any) -> None:
    """Ensure a JSON file exists on disk (do not overwrite if present)."""
    try:
        if filepath.exists():
            return
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "w") as f:
            json.dump(default, f, indent=2, default=str)
    except Exception as e:
        print(f">>> [WARN] Failed to ensure {filepath}: {e}")


# Ensure coach learning queue exists so tooling/scripts can inspect it even before first share.
ensure_json_file(COACH_LEARNING_QUEUE_FILE, [])
ensure_json_file(COACH_LEARNING_ARCHIVE_FILE, [])


def _parse_iso_any(s: Any) -> Optional[datetime.datetime]:
    ss = (s or "")
    if not isinstance(ss, str):
        ss = str(ss)
    ss = ss.strip()
    if not ss:
        return None
    try:
        return datetime.datetime.fromisoformat(ss.replace("Z", "+00:00"))
    except Exception:
        return None


def compact_coach_learning_queue(queue: Any) -> List[dict]:
    """
    Prevent unbounded growth:
    - Never drop PENDING items.
    - Archive APPROVED/REJECTED items older than COACH_LEARNING_RETENTION_DAYS.
    - Cap in-file queue size to COACH_LEARNING_QUEUE_MAX_ITEMS.
    """
    if not isinstance(queue, list):
        return []

    now = datetime.datetime.now(datetime.timezone.utc)
    cutoff = now - datetime.timedelta(days=max(1, COACH_LEARNING_RETENTION_DAYS))

    pending: List[dict] = []
    keep: List[dict] = []
    to_archive: List[dict] = []

    for raw in queue:
        if not isinstance(raw, dict):
            continue
        st = (raw.get("status") or "").upper()
        created = _parse_iso_any(raw.get("created_at")) or _parse_iso_any(raw.get("approved_at")) or _parse_iso_any(raw.get("rejected_at"))
        # Assume naive datetimes are local; compare conservatively
        if created and created.tzinfo is None:
            created = created.replace(tzinfo=datetime.timezone.utc)

        if st == "PENDING":
            pending.append(raw)
        else:
            if created and created < cutoff:
                to_archive.append(raw)
            else:
                keep.append(raw)

    if to_archive:
        try:
            arch = load_json_file(COACH_LEARNING_ARCHIVE_FILE, []) or []
            if not isinstance(arch, list):
                arch = []
            arch.extend(to_archive)
            # Keep newest N in archive
            if len(arch) > COACH_LEARNING_ARCHIVE_MAX_ITEMS:
                arch = arch[-COACH_LEARNING_ARCHIVE_MAX_ITEMS:]
            save_json_file(COACH_LEARNING_ARCHIVE_FILE, arch)
        except Exception:
            pass

    # Keep newest non-pending up to remaining space
    # Sort keep by created_at if possible, otherwise preserve relative order.
    keep_sorted = sorted(
        keep,
        key=lambda x: (_parse_iso_any(x.get("created_at")) or datetime.datetime.min.replace(tzinfo=datetime.timezone.utc)),
    )
    remaining = max(0, COACH_LEARNING_QUEUE_MAX_ITEMS - len(pending))
    if remaining <= 0:
        return pending
    keep_sorted = keep_sorted[-remaining:]
    return pending + keep_sorted


def compact_live_store(live_store: Any) -> Dict[str, Any]:
    """
    Cap ENDED sessions to COACH_LIVE_SESSIONS_MAX_ENDED, but always keep ACTIVE sessions.
    """
    if not isinstance(live_store, dict):
        return {}
    active_keys: List[str] = []
    ended_items: List[Tuple[datetime.datetime, str]] = []
    for k, v in live_store.items():
        if not isinstance(v, dict):
            continue
        st = (v.get("status") or "").upper()
        if st == "ACTIVE":
            active_keys.append(k)
            continue
        dt = _parse_iso_any(v.get("ended_at")) or _parse_iso_any(v.get("started_at")) or _parse_iso_any(v.get("created_at"))
        if dt is None:
            dt = datetime.datetime.min.replace(tzinfo=datetime.timezone.utc)
        elif dt.tzinfo is None:
            dt = dt.replace(tzinfo=datetime.timezone.utc)
        ended_items.append((dt, k))

    ended_items.sort(key=lambda t: t[0])
    keep_ended_keys = [k for _, k in ended_items[-max(1, COACH_LIVE_SESSIONS_MAX_ENDED):]]
    keep_set = set(active_keys) | set(keep_ended_keys)
    return {k: v for k, v in live_store.items() if k in keep_set}

# ------------------------------------------------------------------------------
# PART 3: DATABASE & AUTHENTICATION
# ------------------------------------------------------------------------------
def load_registry() -> dict:
    # Merge backend registry (read-only) with bridge registry (read-write) so all users can login consistently.
    local = load_json_file(REGISTRY_FILE, {}) or {}
    if not isinstance(local, dict):
        local = {}
    backend = load_json_file(BACKEND_REGISTRY_FILE, {}) or {}
    if not isinstance(backend, dict):
        backend = {}
    if not backend:
        return local
    if not local:
        return backend
    # Merge: keep local values when keys collide, but include missing backend users.
    merged = dict(backend)
    merged.update(local)
    return merged

def save_registry(new_data: dict) -> bool:
    return save_json_file(REGISTRY_FILE, new_data)


def sync_registry_from_backend() -> None:
    """
    Best-effort: if backend registry exists (prod), merge its users into the bridge registry file.
    This keeps client/coach/admin UX uniform across services even when data dirs are separate.
    """
    try:
        backend = load_json_file(BACKEND_REGISTRY_FILE, {}) or {}
        if not isinstance(backend, dict) or not backend:
            return
        local = load_json_file(REGISTRY_FILE, {}) or {}
        if not isinstance(local, dict):
            local = {}
        merged = dict(backend)
        merged.update(local)
        # Only write if bridge is missing users that backend has
        if len(merged) != len(local):
            save_json_file(REGISTRY_FILE, merged)
            print(f">>> [REGISTRY] Synced bridge registry from backend: {len(local)} -> {len(merged)} users")
    except Exception as e:
        print(f">>> [REGISTRY] Sync from backend failed: {e}")


# Run once at startup so bridge can authenticate all backend users.
sync_registry_from_backend()

# ==============================================================================
# INITIALIZE NEW SYSTEMS (AFTER all dependencies are defined)
# ==============================================================================
try:
    from .notification_system import NotificationSystem
    from .stripe_billing import StripeBillingSystem
except Exception:
    from notification_system import NotificationSystem
    from stripe_billing import StripeBillingSystem

notification_system = NotificationSystem(DATA_DIR, SENDGRID_API_KEY)
billing_system = StripeBillingSystem(
    DATA_DIR, 
    STRIPE_SECRET_KEY, 
    STRIPE_WEBHOOK_SECRET, 
    load_registry, 
    save_registry
)

# Initialize Nevedal Handler
nevedal_handler = NevedalHandler(VAULT_ROOT)

# Initialize Coach Nexus V2
coach_nexus_v2 = CoachNexusV2(VAULT_ROOT)

# Family Sanctuary Engine
#sanctuary_engine = FamilySanctuaryEngine(
 #   data_dir=DATA_DIR,
 #   azure_cortex=None,
  #  nevedal_handler=nevedal_handler,
  #  billing_system=billing_system
#)

def authenticate_user(username: str, password: str, expected_role: str = None) -> Tuple[Optional[str], Any]:
    registry = load_registry()
    target = None
    target_key = None
    identifier = (username or "").strip()
    identifier_l = identifier.lower()
    for k, v in registry.items():
        creds = v.get("credentials", {}) or {}
        prof = v.get("profile", {}) or {}
        stored_user = (creds.get("username") or "").strip()
        stored_email = (prof.get("email") or "").strip()

        # Allow login by either username or email (common for COACH/ADMIN portals).
        if stored_user == identifier or stored_user.lower() == identifier_l:
            target = v
            target_key = k
            break
        if stored_email and (stored_email == identifier or stored_email.lower() == identifier_l):
            target = v
            target_key = k
            break
    
    if not target:
        return None, "USER_NOT_FOUND"
    
    stored_password = target["credentials"].get("password", "")
    if not verify_password(password, stored_password):
        # Try plain text match for legacy accounts
        if stored_password != password:
            return None, "INVALID_PASSWORD"
    
    p = target.get("profile", {})
    
    if p.get("subscription_status") == "PENDING_VERIFICATION":
        return None, "ACCOUNT_PENDING_APPROVAL"
    if p.get("consent_version", "v0.0") != REQUIRED_CONSENT_VERSION:
        return None, "LEGAL_UPDATE_REQUIRED"
    if expected_role and p.get("role") != "ADMIN" and p.get("role") != expected_role:
        return None, "WRONG_PORTAL"

    token = secrets.token_hex(16)
    ACTIVE_TOKENS[token] = p
    
    # Update last login
    try:
        if target_key and target_key in registry:
            registry[target_key].setdefault("profile", {})
            registry[target_key]["profile"]["last_login"] = str(datetime.datetime.now())
            registry[target_key]["profile"]["login_count"] = registry[target_key]["profile"].get("login_count", 0) + 1
            save_registry(registry)
    except Exception as e:
        print(f">>> [WARN] Could not update last_login for {identifier}: {e}")
    
    return token, p

def register_new_user(data: dict) -> Tuple[bool, str]:
    if not data.get("consent_agreed"):
        return False, "CONSENT_REQUIRED"
    
    username = data.get("username")
    email = data.get("email", "")
    role = data.get("role", "CLIENT")
    registry = load_registry()
    
    # Check for existing username or email
    for k, v in registry.items():
        if v["credentials"]["username"] == username:
            return False, "USERNAME_TAKEN"
        if email and v.get("profile", {}).get("email") == email:
            return False, "EMAIL_TAKEN"

    # Hash the password
    hashed_password = hash_password(data.get("password", ""))
    
    new_profile = {
        "role": role,
        "name": data.get("name"),
        "email": email,
        "phone": data.get("phone", ""),
        "hardware_id": f"{role}_{username.upper()}_ID",
        "family_id": f"FAM_{secrets.token_hex(4).upper()}",
        "joined_date": str(datetime.datetime.now().date()),
        "tier": "STANDARD",
        "dob": data.get("dob"),
        "consent_version": data.get("consent_version", "v0.0"),
        "timezone": data.get("timezone", "America/New_York"),
        "profile_photo_url": "",
        "emergency_contact": data.get("emergency_contact", ""),
        
        # Subscription & Billing
        "subscription_status": "TRIAL_ACTIVE" if role == "CLIENT" else "PENDING_VERIFICATION",
        "subscription_plan": "TRIAL",
        "stripe_customer_id": "",
        "subscription_start_date": str(datetime.datetime.now().date()),
        "trial_end_date": str((datetime.datetime.now() + datetime.timedelta(days=14)).date()),
        
        # Usage Tracking
        "total_sessions_count": 0,
        "token_balance": 10000,  # Starting tokens
        "token_usage_today": 0,
        "token_usage_month": 0,
        "last_token_reset": str(datetime.datetime.now().date()),
        
        # Relationships
        "assigned_coach_id": "",
        
        # Timestamps
        "last_login": "",
        "login_count": 0,
        "created_at": str(datetime.datetime.now()),
        "updated_at": str(datetime.datetime.now())
    }
    
    if role == "COACH":
        new_profile["subscription_status"] = "PENDING_VERIFICATION"
        new_profile["assigned_clients"] = []
        new_profile["specializations"] = data.get("specializations", [])
        new_profile["certification_status"] = "PENDING"
        new_profile["hourly_rate"] = 0
        new_profile["total_sessions_conducted"] = 0
        new_profile["average_client_rating"] = 0
        new_profile["revenue_this_month"] = 0
        new_profile["zoom_link"] = data.get("zoom_link", "")
        
        coach_root = VAULT_ROOT / "Coaches" / new_profile["hardware_id"]
        coach_root.mkdir(parents=True, exist_ok=True)
        (coach_root / f"{username}_LN_training_folder").mkdir(parents=True, exist_ok=True)
        (coach_root / "Reports").mkdir(parents=True, exist_ok=True)
        (coach_root / "Billing").mkdir(parents=True, exist_ok=True)
        (coach_root / "Inbox").mkdir(parents=True, exist_ok=True)
        
        # Create availability file
        with open(coach_root / "availability.json", "w") as f:
            json.dump({"slots": [], "timezone": new_profile["timezone"]}, f)

    registry[f"{role.lower()}_{username}"] = {
        "credentials": {"username": username, "password": hashed_password},
        "profile": new_profile
    }
    
    if save_registry(registry):
        (VAULT_ROOT / f"{role.title()}s" / new_profile["hardware_id"]).mkdir(parents=True, exist_ok=True)
        
        # Initialize metrics for new user
        metrics_engine = MetricsEngine(VAULT_ROOT)
        metrics_engine.initialize_metrics(new_profile)
        
        return True, "REGISTRATION_SUCCESS"
    
    return False, "SAVE_ERROR"

def create_dependent_account(guardian_id: str, data: dict) -> Tuple[bool, str]:
    """Create a dependent/child account linked to guardian"""
    username = data.get("username")
    registry = load_registry()
    
    for k, v in registry.items():
        if v["credentials"]["username"] == username:
            return False, "USERNAME_TAKEN"
    
    # Find guardian by hardware_id
    guardian_profile = None
    for v in registry.values():
        if v.get("profile", {}).get("hardware_id") == guardian_id:
            guardian_profile = v["profile"]
            break
    
    if not guardian_profile:
        return False, "GUARDIAN_NOT_FOUND"
    
    fam_id = guardian_profile.get("family_id", f"FAM_{secrets.token_hex(4).upper()}")
    hashed_password = hash_password(data.get("password", ""))
    
    new_profile = {
        "role": "CLIENT",
        "name": data.get("name"),
        "email": "",
        "phone": "",
        "family_id": fam_id,
        "hardware_id": f"CHILD_{username.upper()}_ID",
        "tier": "DEPENDENT",
        "guardian_id": guardian_id,
        "is_minor": True,
        "consent_version": REQUIRED_CONSENT_VERSION,
        "dob": data.get("dob"),
        "timezone": guardian_profile.get("timezone", "America/New_York"),
        "subscription_status": "FAMILY_PLAN_ACTIVE",
        "subscription_plan": "FAMILY_DEPENDENT",
        "total_sessions_count": 0,
        "token_balance": 5000,
        "token_usage_today": 0,
        "token_usage_month": 0,
        "last_token_reset": str(datetime.datetime.now().date()),
        "assigned_coach_id": guardian_profile.get("assigned_coach_id", ""),
        "last_login": "",
        "login_count": 0,
        "created_at": str(datetime.datetime.now()),
        "updated_at": str(datetime.datetime.now())
    }
    
    registry[f"client_{username}"] = {
        "credentials": {"username": username, "password": hashed_password},
        "profile": new_profile
    }
    
    if save_registry(registry):
        (VAULT_ROOT / "Clients" / new_profile["hardware_id"]).mkdir(parents=True, exist_ok=True)
        
        # Initialize metrics
        metrics_engine = MetricsEngine(VAULT_ROOT)
        metrics_engine.initialize_metrics(new_profile)
        
        return True, "DEPENDENT_CREATED"
    
    return False, "SAVE_ERROR"

# ------------------------------------------------------------------------------
# PART 4: MEMORY SYSTEM (Hippocampus)
# ------------------------------------------------------------------------------
class MemorySystem:
    def __init__(self, root: Path):
        self.root = root
    
    def _path(self, p: dict) -> Path:
        folder = "Clients"
        if p.get('role') == "COACH": folder = "Coaches"
        if p.get('role') == "ADMIN": folder = "Admin"
        return self.root / folder / p.get('hardware_id') / "memory.json"
    
    def _sessions_path(self, p: dict) -> Path:
        folder = "Clients"
        if p.get('role') == "COACH": folder = "Coaches"
        if p.get('role') == "ADMIN": folder = "Admin"
        return self.root / folder / p.get('hardware_id') / "sessions.json"

    def recall(self, p: dict, limit: int = 5) -> str:
        path = self._path(p)
        if not path.exists():
            return "No prior history."
        try:
            with open(path, 'r') as f:
                recent = json.load(f)[-limit:]
                return "\n".join([f"- User: {i['user']}\n  Nate: {i['ai']}" for i in recent])
        except:
            return "Memory Corrupted."

    def recall_full(self, p: dict, limit: int = 100) -> List[dict]:
        """Get full memory entries with all metadata"""
        path = self._path(p)
        if not path.exists():
            return []
        try:
            with open(path, 'r') as f:
                return json.load(f)[-limit:]
        except:
            return []

    def memorize(self, p: dict, u_text: str, a_text: str, session_id: str = None, metadata: dict = None):
        path = self._path(p)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        hist = []
        if path.exists():
            try:
                with open(path, 'r') as f:
                    hist = json.load(f)
            except:
                pass
        
        entry = {
            "timestamp": str(datetime.datetime.now()),
            "session_id": session_id,
            "user": u_text,
            "ai": a_text,
            "word_count_user": len(u_text.split()),
            "word_count_ai": len(a_text.split())
        }
        
        if metadata:
            entry.update(metadata)
        
        hist.append(entry)
        
        # Keep last 1000 entries
        with open(path, 'w') as f:
            json.dump(hist[-1000:], f, indent=2)

    def get_topics_discussed(self, p: dict, days: int = 30) -> List[str]:
        """Extract topics from recent conversations"""
        memories = self.recall_full(p, limit=50)
        topics = set()
        
        # Simple keyword extraction
        keywords = ["anxiety", "depression", "family", "work", "relationship", 
                   "sleep", "stress", "anger", "fear", "grief", "trauma",
                   "childhood", "parent", "spouse", "child", "boss", "friend"]
        
        for m in memories:
            text = (m.get("user", "") + " " + m.get("ai", "")).lower()
            for kw in keywords:
                if kw in text:
                    topics.add(kw)
        
        return list(topics)

    def get_breakthroughs(self, p: dict) -> List[dict]:
        """Get recorded breakthroughs"""
        path = self._path(p).parent / "breakthroughs.json"
        if not path.exists():
            return []
        try:
            with open(path, 'r') as f:
                return json.load(f)
        except:
            return []

    def record_breakthrough(self, p: dict, description: str, context: str = ""):
        """Record a breakthrough moment"""
        path = self._path(p).parent / "breakthroughs.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        
        breakthroughs = []
        if path.exists():
            try:
                with open(path, 'r') as f:
                    breakthroughs = json.load(f)
            except:
                pass
        
        breakthroughs.append({
            "timestamp": str(datetime.datetime.now()),
            "description": description,
            "context": context
        })
        
        with open(path, 'w') as f:
            json.dump(breakthroughs[-100:], f, indent=2)

# ------------------------------------------------------------------------------
# PART 5: METRICS ENGINE (Parietal Cortex - Nevedal Integration)
# ------------------------------------------------------------------------------
class MetricsEngine:
    def __init__(self, root: Path):
        self.root = root
    
    def _path(self, p: dict) -> Path:
        folder = "Clients"
        if p.get('role') == "COACH": folder = "Coaches"
        if p.get('role') == "ADMIN": folder = "Admin"
        return self.root / folder / p.get('hardware_id') / "metrics.json"

    def _backend_path(self, p: dict) -> Path:
        """
        In production, bridge mounts backend data at /app/backend_data (read-only).
        This lets us read/copy missing vaults so all members (e.g. CLIENT_001B) resolve
        the same metrics/history even if the bridge data dir is missing that file.
        """
        folder = "Clients"
        if p.get('role') == "COACH":
            folder = "Coaches"
        if p.get('role') == "ADMIN":
            folder = "Admin"
        return BACKEND_VAULT_ROOT / folder / p.get('hardware_id') / "metrics.json"
    
    def initialize_metrics(self, p: dict):
        """Initialize metrics for a new user"""
        path = self._path(p)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        initial_metrics = {
            "nevedal_state": {
                "C_emo": 0.5,
                "E_warmth": 0.3,
                "T_tunnel": 0.2,
                "GAP": 0.3,
                "Velocity": 0.0,
                "Quantum": 0.5,
                "anxiety_level": 0.0,
                "depression_indicators": 0.0,
                "stress_level": 0.0,
                "engagement": 0.5,
                "session_count": 0,
                "breakthrough_count": 0,
                "homework_completion_rate": 0.0,
                "risk_level": "LOW",
                "last_risk_assessment": "",
                "crisis_count": 0,
                "mood_current": "neutral",
                "mood_trend": "stable",
                "mood_history": [],
                "sleep_quality": "unknown",
                "sleep_issues_mentioned": 0
            },
            "history": [],
            "last_updated": str(datetime.datetime.now()),
            "created_at": str(datetime.datetime.now())
        }
        
        with open(path, 'w') as f:
            json.dump(initial_metrics, f, indent=2)
    
    def load_metrics(self, p: dict) -> dict:
        path = self._path(p)
        print(f">>> [METRICS DEBUG] Loading from: {path}")
        bpath = None
        try:
            bpath = self._backend_path(p)
        except Exception:
            bpath = None

        if not path.exists():
            # If backend vault exists (prod), copy it into bridge vault before initializing defaults.
            try:
                if bpath and bpath.exists():
                    path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(bpath, path)
                    print(f">>> [METRICS DEBUG] Copied missing metrics from backend vault: {bpath} -> {path}")
                else:
                    print(f">>> [METRICS DEBUG] File missing, initializing")
                    self.initialize_metrics(p)
            except Exception as e:
                print(f">>> [METRICS DEBUG] Backend vault copy failed ({e}); initializing defaults")
                self.initialize_metrics(p)
        try:
            with open(path, 'r') as f:
                data = json.load(f)

                # If a default/empty local file exists but backend has richer history, prefer backend.
                # This commonly happens when bridge initialized defaults before the backend vault was mounted/copied.
                try:
                    if bpath and bpath.exists():
                        with open(bpath, "r") as bf:
                            bdata = json.load(bf)
                        lns = (data.get("nevedal_state") or {}) if isinstance(data, dict) else {}
                        bns = (bdata.get("nevedal_state") or {}) if isinstance(bdata, dict) else {}
                        lmh = lns.get("mood_history", []) if isinstance(lns, dict) else []
                        bmh = bns.get("mood_history", []) if isinstance(bns, dict) else []
                        lhist = data.get("history", []) if isinstance(data, dict) else []
                        bhist = bdata.get("history", []) if isinstance(bdata, dict) else []
                        lsc = int(lns.get("session_count") or 0) if isinstance(lns, dict) else 0
                        bsc = int(bns.get("session_count") or 0) if isinstance(bns, dict) else 0

                        # Overwrite only when local looks like an uninitialized stub but backend clearly has data.
                        should_overwrite = (
                            (isinstance(lmh, list) and len(lmh) == 0 and isinstance(bmh, list) and len(bmh) > 0)
                            or (isinstance(lhist, list) and len(lhist) == 0 and isinstance(bhist, list) and len(bhist) > 0 and bsc > lsc)
                        )
                        if should_overwrite:
                            path.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(bpath, path)
                            print(f">>> [METRICS DEBUG] Replaced stub metrics with backend vault: {bpath} -> {path}")
                            data = bdata
                except Exception as e:
                    print(f">>> [METRICS DEBUG] Backend reconcile skipped: {e}")

                # ------------------------------------------------------------------
                # HYDRATE: If we have richer recent history than nevedal_state/last_updated,
                # update nevedal_state to reflect the newest known snapshot.
                # This ensures dashboards show best-available real-time values on refresh.
                # ------------------------------------------------------------------
                def _parse_dt(v):
                    if not v:
                        return None
                    try:
                        # Handles "YYYY-MM-DD HH:MM:SS.mmmmmm" and ISO strings
                        return datetime.datetime.fromisoformat(str(v))
                    except Exception:
                        return None

                history = data.get("history", [])
                ns = data.get("nevedal_state", {}) or {}
                last_updated_dt = _parse_dt(data.get("last_updated"))

                hydrated = False
                if isinstance(history, list) and history:
                    last_hist = history[-1] if isinstance(history[-1], dict) else None
                    hist_dt = _parse_dt(last_hist.get("timestamp") if last_hist else None)
                    if hist_dt and (last_updated_dt is None or last_updated_dt < hist_dt):
                        # Map history snapshot -> nevedal_state (only fields we can trust)
                        if isinstance(last_hist.get("C_emo"), (int, float)):
                            ns["C_emo"] = float(last_hist["C_emo"])
                        if isinstance(last_hist.get("GAP"), (int, float)):
                            ns["GAP"] = float(last_hist["GAP"])
                        if isinstance(last_hist.get("Quantum"), (int, float)):
                            ns["Quantum"] = float(last_hist["Quantum"])
                        # History uses "anxiety" while state uses "anxiety_level"
                        if isinstance(last_hist.get("anxiety"), (int, float)):
                            ns["anxiety_level"] = float(last_hist["anxiety"])
                        if isinstance(last_hist.get("mood"), str) and last_hist["mood"]:
                            ns["mood_current"] = last_hist["mood"]

                        data["nevedal_state"] = ns
                        data["last_updated"] = str(hist_dt)
                        hydrated = True

                if hydrated:
                    try:
                        with open(path, "w") as wf:
                            json.dump(data, wf, indent=2)
                    except Exception as e:
                        print(f">>> [METRICS DEBUG] Hydration write failed: {e}")

                print(f">>> [METRICS DEBUG] C_emo={data.get('nevedal_state', {}).get('C_emo')}, last_updated={data.get('last_updated')}")
                return data
        except Exception as e:
            print(f">>> [METRICS DEBUG] EXCEPTION: {e}")
            return {"nevedal_state": {}, "history": []}

    def update_metric(self, p: dict, key: str, value: Any):
        """Update a single metric"""
        metrics = self.load_metrics(p)
        if "nevedal_state" not in metrics:
            metrics["nevedal_state"] = {}
        metrics["nevedal_state"][key] = value
        metrics["last_updated"] = str(datetime.datetime.now())
        
        path = self._path(p)
        with open(path, 'w') as f:
            json.dump(metrics, f, indent=2)
        
        print(f">>> [OBSERVER] Updated {key} to {value} for {p.get('name')}")

    def analyze_and_update(self, p: dict, user_text: str, ai_text: str):
        """Analyze conversation and update metrics"""
        current_metrics = self.load_metrics(p)
        ns = current_metrics.get("nevedal_state", {})
        history = current_metrics.get("history", [])
        
        # === SENTIMENT ANALYSIS (Simplified) ===
        combined_text = (user_text + " " + ai_text).lower()
        
        # Positive indicators
        positive_words = ["happy", "good", "great", "better", "progress", "hopeful", 
                        "grateful", "calm", "peaceful", "excited", "love", "joy"]
        # Negative indicators
        negative_words = ["sad", "anxious", "worried", "scared", "angry", "frustrated",
                        "hopeless", "tired", "exhausted", "hate", "fear", "panic"]
        # Crisis indicators
        crisis_words = ["suicide", "kill myself", "end it", "die", "hurt myself", 
                       "self-harm", "cutting", "overdose", "no point"]
        
        pos_count = sum(1 for w in positive_words if w in combined_text)
        neg_count = sum(1 for w in negative_words if w in combined_text)
        crisis_detected = any(w in combined_text for w in crisis_words)
        
        # === UPDATE EMOTIONAL COHERENCE (C_emo) ===
        sentiment_score = (pos_count - neg_count) / max(1, pos_count + neg_count + 1)
        c_emo = ns.get("C_emo", 0.5)
        c_emo = round(c_emo * 0.7 + (0.5 + sentiment_score * 0.3) * 0.3, 2)
        c_emo = max(0.1, min(1.0, c_emo))
        self.update_metric(p, "C_emo", c_emo)
        
        # === UPDATE WARMTH (E_warmth) ===
        warmth_words = ["thank", "appreciate", "help", "support", "kind", "care"]
        warmth_score = sum(1 for w in warmth_words if w in combined_text) * 0.1
        e_warmth = ns.get("E_warmth", 0.3)
        e_warmth = round(min(1.0, e_warmth + warmth_score), 2)
        self.update_metric(p, "E_warmth", e_warmth)
        
        # === UPDATE TUNNEL (T_tunnel) - unchanged for now ===
        self.update_metric(p, "T_tunnel", ns.get("T_tunnel", 0.2))
        
        # === UPDATE ANXIETY LEVEL ===
        anxiety_words = ["anxious", "nervous", "worried", "panic", "racing", "tense"]
        anxiety_level = sum(1 for w in anxiety_words if w in combined_text) * 0.15
        anxiety_level = max(0, min(1.0, anxiety_level))
        self.update_metric(p, "anxiety_level", round(anxiety_level, 2))
        
        # === UPDATE DEPRESSION INDICATORS ===
        depression_words = ["hopeless", "worthless", "empty", "numb", "tired", "no energy"]
        depression_score = sum(1 for w in depression_words if w in combined_text) * 0.15
        depression_score = max(0, min(1.0, depression_score))
        self.update_metric(p, "depression_indicators", round(depression_score, 2))
        
        # === UPDATE STRESS LEVEL ===
        stress_words = ["stressed", "overwhelmed", "pressure", "deadline", "too much"]
        stress_level = sum(1 for w in stress_words if w in combined_text) * 0.15
        stress_level = max(0, min(1.0, stress_level))
        self.update_metric(p, "stress_level", round(stress_level, 2))
        
        # === UPDATE ENGAGEMENT ===
        word_count = len(user_text.split())
        engagement = min(1.0, word_count / 50) * 0.5 + (0.5 if "?" in user_text else 0.3)
        engagement = round((ns.get("engagement", 0.5) + engagement) / 2, 2)
        self.update_metric(p, "engagement", engagement)
        
        # === UPDATE SESSION COUNT ===
        session_count = ns.get("session_count", 0) + 1
        self.update_metric(p, "session_count", session_count)
        
        # === UPDATE MOOD ===
        if pos_count > neg_count:
            detected_mood = "happy"
        elif neg_count > pos_count:
            detected_mood = "sad"
        else:
            detected_mood = "neutral"
        
        self.update_metric(p, "mood_current", detected_mood)
        
        # Update mood history
        mood_history = ns.get("mood_history", [])
        mood_history.append({
            "date": str(datetime.datetime.now().date()),
            "mood": detected_mood,
            "anxiety": anxiety_level,
            "engagement": engagement
        })
        self.update_metric(p, "mood_history", mood_history[-30:])  # Keep last 30
        
        # === CALCULATE GAP (Growth Attunement Potential) ===
        gap = round((c_emo * 0.4 + e_warmth * 0.3 + engagement * 0.3), 3)
        self.update_metric(p, "GAP", gap)
        
        # === CALCULATE VELOCITY (Change rate) ===
        if len(history) > 0:
            prev_gap = history[-1].get("GAP", 0.3)
            velocity = round(gap - prev_gap, 3)
        else:
            velocity = 0.0
        self.update_metric(p, "Velocity", velocity)
        
        # === CALCULATE QUANTUM SCORE ===
        quantum = round(0.3 * c_emo + 0.25 * gap + 0.25 * engagement + 0.2 * (1 - anxiety_level), 3)
        self.update_metric(p, "Quantum", quantum)
        
        # === RISK ASSESSMENT ===
        risk_level = "LOW"
        if crisis_detected:
            risk_level = "CRITICAL"
            self._log_crisis(p, "crisis_keywords", user_text[:200])
        elif depression_score > 0.6 or anxiety_level > 0.7:
            risk_level = "MEDIUM"
            if depression_score > 0.8:
                risk_level = "HIGH"
        
        self.update_metric(p, "risk_level", risk_level)
        self.update_metric(p, "last_risk_assessment", str(datetime.datetime.now()))
        
        # === SAVE HISTORY SNAPSHOT ===
        history.append({
            "timestamp": str(datetime.datetime.now()),
            "C_emo": c_emo,
            "GAP": gap,
            "Quantum": quantum,
            "anxiety": anxiety_level,
            "mood": detected_mood
        })
        
        # Keep last 100 history entries
        current_metrics = self.load_metrics(p)
        current_metrics["history"] = history[-100:]
        path = self._path(p)
        with open(path, 'w') as f:
            json.dump(current_metrics, f, indent=2)
        
        print(f">>> [NEVEDAL] Metrics updated for {p.get('name')}: C_emo={c_emo}, GAP={gap}, Risk={risk_level}")
        
        return {
            "C_emo": c_emo,
            "GAP": gap,
            "risk_level": risk_level,
            "mood": detected_mood
        }

    def _log_crisis(self, p: dict, trigger: str, context: str):
        """Log crisis event"""
        crisis_log = load_json_file(CRISIS_LOG_FILE, [])
        
        crisis_log.append({
            "timestamp": str(datetime.datetime.now()),
            "user_id": p.get("hardware_id"),
            "user_name": p.get("name"),
            "trigger_keyword": trigger,
            "context": context[:500],
            "status": "ACTIVE",
            "resolved": False,
            "resolved_by": "",
            "resolution_notes": ""
        })
        
        save_json_file(CRISIS_LOG_FILE, crisis_log)
        
        # Update user's crisis count
        ns = self.load_metrics(p).get("nevedal_state", {})
        self.update_metric(p, "crisis_count", ns.get("crisis_count", 0) + 1)

    def get_metrics_summary(self, p: dict) -> dict:
        """Get formatted metrics summary for display"""
        metrics = self.load_metrics(p)
        ns = metrics.get("nevedal_state", {})
        
        return {
            "coherence": f"{ns.get('C_emo', 0.5) * 100:.0f}%",
            "growth_potential": f"{ns.get('GAP', 0.3) * 100:.0f}%",
            "wellness_score": f"{ns.get('Quantum', 0.5) * 100:.0f}%",
            "anxiety_level": f"{ns.get('anxiety_level', 0) * 100:.0f}%",
            "engagement": f"{ns.get('engagement', 0.5) * 100:.0f}%",
            "sessions_total": ns.get("session_count", 0),
            "breakthroughs": ns.get("breakthrough_count", 0),
            "current_mood": ns.get("mood_current", "neutral"),
            "mood_trend": ns.get("mood_trend", "stable"),
            "risk_level": ns.get("risk_level", "LOW"),
            "last_updated": metrics.get("last_updated", "")
        }

# ------------------------------------------------------------------------------
# PART 6: SESSION TRACKING SYSTEM
# ------------------------------------------------------------------------------
class SessionTracker:
    def __init__(self, data_dir: Path):
        self.sessions_file = data_dir / "sessions.json"
    
    def load_sessions(self) -> List[dict]:
        return load_json_file(self.sessions_file, [])
    
    def save_sessions(self, sessions: List[dict]) -> bool:
        return save_json_file(self.sessions_file, sessions)
    
    def create_session(self, client_id: str, session_type: str = "AI", 
                       coach_id: str = None) -> dict:
        """Create a new session"""
        session = {
            "session_id": generate_session_id(),
            "client_id": client_id,
            "coach_id": coach_id,
            "session_type": session_type,  # AI, COACH, FAMILY
            "status": "active",
            "scheduled_start": None,
            "scheduled_end": None,
            "actual_start": str(datetime.datetime.now()),
            "actual_end": None,
            "duration_seconds": 0,
            "zoom_meeting_id": "",
            "recording_url": "",
            "transcript_summary": "",
            "topics_covered": [],
            "mood_at_start": "",
            "mood_at_end": "",
            "homework_assigned": [],
            "coach_notes": "",
            "nate_summary": "",
            "message_count": 0,
            "created_at": str(datetime.datetime.now())
        }
        
        sessions = self.load_sessions()
        sessions.append(session)
        self.save_sessions(sessions)
        
        LIVE_SESSION_TRACKER[session["session_id"]] = session
        
        return session
    
    def end_session(self, session_id: str, summary: str = "", 
                    mood_at_end: str = "", topics: List[str] = None) -> bool:
        """End a session and calculate duration"""
        sessions = self.load_sessions()
        
        for session in sessions:
            if session["session_id"] == session_id:
                session["actual_end"] = str(datetime.datetime.now())
                session["status"] = "completed"
                
                # Calculate duration
                try:
                    start = datetime.datetime.fromisoformat(session["actual_start"])
                    end = datetime.datetime.now()
                    session["duration_seconds"] = int((end - start).total_seconds())
                except:
                    pass
                
                session["nate_summary"] = summary
                session["mood_at_end"] = mood_at_end
                if topics:
                    session["topics_covered"] = topics
                
                self.save_sessions(sessions)
                
                if session_id in LIVE_SESSION_TRACKER:
                    del LIVE_SESSION_TRACKER[session_id]
                
                return True
        
        return False
    
    def get_client_sessions(self, client_id: str, limit: int = 10) -> List[dict]:
        """Get sessions for a client"""
        sessions = self.load_sessions()
        client_sessions = [s for s in sessions if s.get("client_id") == client_id]
        return sorted(client_sessions, key=lambda x: x.get("created_at", ""), reverse=True)[:limit]
    
    def get_coach_sessions(self, coach_id: str, limit: int = 20) -> List[dict]:
        """Get sessions for a coach"""
        sessions = self.load_sessions()
        coach_sessions = [s for s in sessions if s.get("coach_id") == coach_id]
        return sorted(coach_sessions, key=lambda x: x.get("created_at", ""), reverse=True)[:limit]
    
    def schedule_session(self, client_id: str, coach_id: str, 
                        scheduled_start: str, scheduled_end: str,
                        session_type: str = "COACH") -> dict:
        """Schedule a future session"""
        session = {
            "session_id": generate_session_id(),
            "client_id": client_id,
            "coach_id": coach_id,
            "session_type": session_type,
            "status": "scheduled",
            "scheduled_start": scheduled_start,
            "scheduled_end": scheduled_end,
            "actual_start": None,
            "actual_end": None,
            "duration_seconds": 0,
            "zoom_meeting_id": "",
            "recording_url": "",
            "transcript_summary": "",
            "topics_covered": [],
            "mood_at_start": "",
            "mood_at_end": "",
            "homework_assigned": [],
            "coach_notes": "",
            "nate_summary": "",
            "message_count": 0,
            "created_at": str(datetime.datetime.now())
        }
        
        sessions = self.load_sessions()
        sessions.append(session)
        self.save_sessions(sessions)
        
        return session

# ------------------------------------------------------------------------------
# PART 7: BILLING & SUBSCRIPTION SYSTEM
# ------------------------------------------------------------------------------
class BillingSystem:
    def __init__(self, data_dir: Path):
        self.billing_file = data_dir / "billing.json"
        self.transactions_file = data_dir / "transactions.json"
    
    def load_billing(self) -> dict:
        return load_json_file(self.billing_file, {"customers": {}, "subscriptions": {}})
    
    def save_billing(self, data: dict) -> bool:
        return save_json_file(self.billing_file, data)
    
    def create_customer(self, user_id: str, email: str, name: str) -> dict:
        """Create billing customer record"""
        billing = self.load_billing()
        
        customer = {
            "user_id": user_id,
            "email": email,
            "name": name,
            "stripe_customer_id": "",  # Will be set when Stripe is called
            "created_at": str(datetime.datetime.now()),
            "payment_methods": [],
            "default_payment_method": ""
        }
        
        billing["customers"][user_id] = customer
        self.save_billing(billing)
        
        return customer
    
    def create_subscription(self, user_id: str, plan: str, 
                           price_id: str = "", stripe_sub_id: str = "") -> dict:
        """Create subscription record"""
        billing = self.load_billing()
        
        plan_details = {
            "TRIAL": {"tokens": 10000, "coach_sessions": 0, "price": 0, "duration_days": 14},
            "STANDARD": {"tokens": 50000, "coach_sessions": 0, "price": 29, "duration_days": 30},
            "TOP_TIER": {"tokens": 200000, "coach_sessions": 4, "price": 199, "duration_days": 30},
            "FAMILY": {"tokens": 300000, "coach_sessions": 6, "price": 299, "duration_days": 30}
        }
        
        details = plan_details.get(plan, plan_details["STANDARD"])
        
        subscription = {
            "user_id": user_id,
            "plan": plan,
            "stripe_subscription_id": stripe_sub_id,
            "stripe_price_id": price_id,
            "status": "active",
            "tokens_included": details["tokens"],
            "coach_sessions_included": details["coach_sessions"],
            "monthly_price": details["price"],
            "start_date": str(datetime.datetime.now().date()),
            "end_date": str((datetime.datetime.now() + datetime.timedelta(days=details["duration_days"])).date()),
            "next_billing_date": str((datetime.datetime.now() + datetime.timedelta(days=details["duration_days"])).date()),
            "created_at": str(datetime.datetime.now()),
            "cancelled_at": None
        }
        
        billing["subscriptions"][user_id] = subscription
        self.save_billing(billing)
        
        # Update user profile
        registry = load_registry()
        for k, v in registry.items():
            if v["profile"].get("hardware_id") == user_id or k.endswith(user_id.lower()):
                v["profile"]["subscription_plan"] = plan
                v["profile"]["subscription_status"] = "ACTIVE"
                v["profile"]["token_balance"] = details["tokens"]
                save_registry(registry)
                break
        
        return subscription
    
    def get_subscription(self, user_id: str) -> Optional[dict]:
        """Get user's subscription"""
        billing = self.load_billing()
        return billing.get("subscriptions", {}).get(user_id)
    
    def record_transaction(
        self,
        user_id: str,
        amount: float,
        description: str,
        transaction_type: str = "charge",
        status: str = "completed",
        metadata: dict = None,
    ) -> dict:
        """Record a billing transaction"""
        transactions = load_json_file(self.transactions_file, [])
        
        transaction = {
            "transaction_id": f"TXN_{secrets.token_hex(8).upper()}",
            "user_id": user_id,
            "amount": amount,
            "currency": "USD",
            "description": description,
            "type": transaction_type,  # charge, refund, credit
            "status": status,
            "created_at": str(datetime.datetime.now()),
            "metadata": metadata or {},
        }
        
        transactions.append(transaction)
        save_json_file(self.transactions_file, transactions)
        
        return transaction
    
    def use_tokens(self, user_id: str, tokens_used: int) -> Tuple[bool, int]:
        """Deduct tokens from user's balance"""
        registry = load_registry()
        
        for k, v in registry.items():
            profile = v.get("profile", {})
            if profile.get("hardware_id") == user_id:
                current_balance = profile.get("token_balance", 0)
                
                if current_balance < tokens_used:
                    return False, current_balance
                
                profile["token_balance"] = current_balance - tokens_used
                profile["token_usage_today"] = profile.get("token_usage_today", 0) + tokens_used
                profile["token_usage_month"] = profile.get("token_usage_month", 0) + tokens_used
                
                save_registry(registry)
                return True, profile["token_balance"]
        
        return False, 0

    def add_token_usage(self, user_id: str, tokens_used: int, deduct_balance: bool = False) -> Tuple[bool, int]:
        """
        Record token usage on a profile.

        - Always increments token_usage_today/month.
        - Optionally decrements token_balance when deduct_balance=True.
        Returns (success, resulting_balance).
        """
        try:
            tokens_used = int(tokens_used or 0)
        except Exception:
            tokens_used = 0

        if tokens_used <= 0:
            # Nothing to record; still return current balance if possible.
            registry = load_registry()
            for _, v in (registry or {}).items():
                p = (v or {}).get("profile", {}) or {}
                if p.get("hardware_id") == user_id:
                    return True, int(p.get("token_balance", 0) or 0)
            return True, 0

        registry = load_registry()
        for _, v in (registry or {}).items():
            profile = (v or {}).get("profile", {}) or {}
            if profile.get("hardware_id") != user_id:
                continue

            current_balance = int(profile.get("token_balance", 0) or 0)
            if deduct_balance:
                if current_balance < tokens_used:
                    return False, current_balance
                profile["token_balance"] = current_balance - tokens_used

            profile["token_usage_today"] = int(profile.get("token_usage_today", 0) or 0) + tokens_used
            profile["token_usage_month"] = int(profile.get("token_usage_month", 0) or 0) + tokens_used
            save_registry(registry)

            return True, int(profile.get("token_balance", 0) or 0)

        return False, 0
    
    def get_usage_stats(self, user_id: str) -> dict:
        """Get token usage statistics"""
        registry = load_registry()
        
        for k, v in registry.items():
            profile = v.get("profile", {})
            if profile.get("hardware_id") == user_id:
                return {
                    "token_balance": profile.get("token_balance", 0),
                    "tokens_used_today": profile.get("token_usage_today", 0),
                    "tokens_used_month": profile.get("token_usage_month", 0),
                    "subscription_plan": profile.get("subscription_plan", "TRIAL"),
                    "subscription_status": profile.get("subscription_status", "TRIAL_ACTIVE")
                }
        
        return {}

# ------------------------------------------------------------------------------
# PART 8: NIGHT SCHOOL (Learning Engine)
# ------------------------------------------------------------------------------
class NightSchool:
    def __init__(self, root: Path):
        self.root = root
        self.wisdom_file = root / "Admin" / "little_nate_wisdom.json"
        self.learnings_file = root / "Admin" / "learning_history.json"
    
    def load_wisdom(self) -> str:
        if not self.wisdom_file.exists():
            return "Focus on empathy, safety, and client growth. Always validate feelings before offering solutions."
        try:
            with open(self.wisdom_file, 'r') as f:
                data = json.load(f)
                return data.get("accumulated_learnings", "Focus on empathy and safety.")
        except:
            return "Focus on empathy and safety."
    
    def get_wisdom_structured(self) -> dict:
        """Get structured wisdom data"""
        if not self.wisdom_file.exists():
            return {"accumulated_learnings": "", "entries": [], "last_synthesis": ""}
        try:
            with open(self.wisdom_file, 'r') as f:
                return json.load(f)
        except:
            return {"accumulated_learnings": "", "entries": [], "last_synthesis": ""}

    async def start_session(self):
        """Run Night School learning session"""
        print("[*] NIGHT SCHOOL: Session Active. Scanning training materials...")
        
        # Process Admin folder
        admin_folder = self.root / "Admin" / "admin_LN_training_folder"
        if admin_folder.exists():
            await self._process_folder(admin_folder, "ADMIN_CURRICULUM")
        
        # Process Coach folders
        coaches_dir = self.root / "Coaches"
        if coaches_dir.exists():
            for coach_dir in coaches_dir.iterdir():
                if coach_dir.is_dir():
                    for sub in coach_dir.iterdir():
                        if sub.is_dir() and sub.name.endswith("_LN_training_folder"):
                            await self._process_folder(sub, f"COACH_{coach_dir.name}")
        
        # Synthesize learnings
        await self._synthesize_learnings()
        
        print("[*] NIGHT SCHOOL: Session Complete.")

    async def _process_folder(self, folder_path: Path, source_tag: str):
        """Process training materials from a folder"""
        if not folder_path.exists():
            return
        
        for file in folder_path.iterdir():
            if file.suffix in ['.txt', '.log', '.json', '.md']:
                try:
                    with open(file, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if len(content) > 10:
                            print(f"   [NIGHT SCHOOL] Ingesting {file.name} from {source_tag}...")
                            self.add_learning(
                                content=content[:2000],
                                source=source_tag,
                                filename=file.name
                            )
                except Exception as e:
                    print(f"   [NIGHT SCHOOL] Error reading {file.name}: {e}")

    def add_learning(self, content: str, source: str, filename: str = "", 
                    category: str = "general"):
        """Add a new learning entry"""
        learnings = load_json_file(self.learnings_file, [])
        
        # Check for duplicates
        content_hash = hashlib.md5(content.encode()).hexdigest()
        for entry in learnings:
            if entry.get("content_hash") == content_hash:
                return  # Skip duplicate
        
        entry = {
            "id": secrets.token_hex(8),
            "content": content,
            "content_hash": content_hash,
            "source": source,
            "filename": filename,
            "category": category,
            "timestamp": str(datetime.datetime.now()),
            "times_applied": 0,
            "effectiveness_score": 0.5,
            "deprecated": False
        }
        
        learnings.append(entry)
        save_json_file(self.learnings_file, learnings[-1000:])  # Keep last 1000

    async def _synthesize_learnings(self):
        """Synthesize learnings into accumulated wisdom"""
        learnings = load_json_file(self.learnings_file, [])
        
        if not learnings:
            return
        
        # Get recent, non-deprecated learnings
        active_learnings = [l for l in learnings if not l.get("deprecated", False)]
        recent = active_learnings[-50:]  # Last 50 entries
        
        # Create synthesis (in production, this would use AI)
        synthesis_parts = []
        
        # Group by category
        categories = {}
        for l in recent:
            cat = l.get("category", "general")
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(l["content"][:200])
        
        for cat, contents in categories.items():
            synthesis_parts.append(f"[{cat.upper()}]: {'; '.join(contents[:5])}")
        
        wisdom_data = {
            "accumulated_learnings": "\n".join(synthesis_parts),
            "entries_count": len(active_learnings),
            "last_synthesis": str(datetime.datetime.now()),
            "categories": list(categories.keys())
        }
        
        save_json_file(self.wisdom_file, wisdom_data)

    def get_coach_contribution(self, coach_id: str) -> dict:
        """Get learning contributions from a specific coach"""
        learnings = load_json_file(self.learnings_file, [])
        coach_learnings = [l for l in learnings if coach_id in l.get("source", "")]
        
        return {
            "total_contributions": len(coach_learnings),
            "categories": list(set(l.get("category", "general") for l in coach_learnings)),
            "recent": coach_learnings[-10:]
        }

# ------------------------------------------------------------------------------
# PART 9: ANALYTICS ENGINE
# ------------------------------------------------------------------------------
class AnalyticsEngine:
    def __init__(self, data_dir: Path):
        self.analytics_file = data_dir / "analytics.json"
    
    def load_analytics(self) -> dict:
        default = {
            "schema_version": 2,
            "daily_stats": {},
            "platform_totals": {
                "total_users": 0,
                "total_sessions": 0,
                "total_messages": 0,
                "total_tokens_used": 0,
            },
            # Append-only event stream used by dashboards / flow-tree charts.
            # (Keep bounded via retention trimming in record_event.)
            "events": [],
        }
        analytics = load_json_file(self.analytics_file, default)
        if not isinstance(analytics, dict):
            analytics = dict(default)

        # Backward-compat: ensure required keys exist
        analytics.setdefault("schema_version", 2)
        analytics.setdefault("daily_stats", {})
        analytics.setdefault("platform_totals", {})
        analytics.setdefault("events", [])

        pt = analytics.get("platform_totals")
        if not isinstance(pt, dict):
            pt = {}
            analytics["platform_totals"] = pt
        pt.setdefault("total_users", 0)
        pt.setdefault("total_sessions", 0)
        pt.setdefault("total_messages", 0)
        pt.setdefault("total_tokens_used", 0)

        if not isinstance(analytics.get("events"), list):
            analytics["events"] = []

        return analytics
    
    def save_analytics(self, data: dict) -> bool:
        return save_json_file(self.analytics_file, data)
    
    def record_event(self, event_type: str, user_id: str = None, data: dict = None):
        """Record an analytics event"""
        analytics = self.load_analytics()
        today = str(datetime.datetime.now().date())
        
        if today not in analytics["daily_stats"]:
            analytics["daily_stats"][today] = {
                "logins": 0,
                "registrations": 0,
                "messages_sent": 0,
                "tokens_used": 0,
                "sessions_started": 0,
                "active_users": []
            }
        
        day_stats = analytics["daily_stats"][today]

        # Normalize active_users
        if not isinstance(day_stats.get("active_users"), list):
            day_stats["active_users"] = []

        # Persist append-only event stream for dashboards / flow-tree
        try:
            event = {
                "event_id": f"EVT_{secrets.token_hex(6).upper()}",
                "timestamp": str(datetime.datetime.now()),
                "event_type": event_type,
                "user_id": user_id,
                "data": (data if isinstance(data, dict) else {}),
            }
            analytics.setdefault("events", [])
            if isinstance(analytics["events"], list):
                analytics["events"].append(event)
                # Retention: keep last N events (default 5000)
                try:
                    keep = int(os.getenv("ANALYTICS_EVENT_RETENTION", "5000") or 5000)
                except Exception:
                    keep = 5000
                if keep > 0 and len(analytics["events"]) > keep:
                    analytics["events"] = analytics["events"][-keep:]
        except Exception as e:
            print(f">>> [ANALYTICS] Event append failed: {e}")

        # Aggregate counters (best-effort)
        et = (event_type or "").strip()
        et_lower = et.lower()

        if et in ("login", "auth_success", "login_success"):
            day_stats["logins"] = day_stats.get("logins", 0) + 1
            if user_id and user_id not in day_stats.get("active_users", []):
                day_stats["active_users"].append(user_id)
        elif event_type == "registration":
            day_stats["registrations"] = day_stats.get("registrations", 0) + 1
            analytics["platform_totals"]["total_users"] += 1
        elif et in ("message",) or et_lower.startswith("sanctuary_message") or et_lower in ("sanctuary_ai_response", "sanctuary_coaching_message"):
            day_stats["messages_sent"] = day_stats.get("messages_sent", 0) + 1
            analytics["platform_totals"]["total_messages"] += 1
        elif event_type == "tokens":
            tokens = data.get("tokens", 0) if isinstance(data, dict) else 0
            day_stats["tokens_used"] = day_stats.get("tokens_used", 0) + tokens
            analytics["platform_totals"]["total_tokens_used"] += tokens
        else:
            # If any event includes token usage, count it
            try:
                if isinstance(data, dict) and data.get("tokens") is not None:
                    tokens = int(data.get("tokens") or 0)
                    day_stats["tokens_used"] = day_stats.get("tokens_used", 0) + tokens
                    analytics["platform_totals"]["total_tokens_used"] += tokens
            except Exception:
                pass

        if et in ("session_start", "sanctuary_session_started"):
            day_stats["sessions_started"] = day_stats.get("sessions_started", 0) + 1
            analytics["platform_totals"]["total_sessions"] += 1
        
        self.save_analytics(analytics)
    
    def get_dashboard_stats(self) -> dict:
        """Get stats for admin dashboard"""
        analytics = self.load_analytics()
        registry = load_registry()
        today = str(datetime.datetime.now().date())
        
        today_stats = analytics.get("daily_stats", {}).get(today, {})
        
        # Count users by role
        total_users = len(registry)
        coaches = sum(1 for v in registry.values() if v.get("profile", {}).get("role") == "COACH")
        clients = sum(1 for v in registry.values() if v.get("profile", {}).get("role") == "CLIENT")
        
        # Active users today
        active_users = today_stats.get("active_users", [])
        if isinstance(active_users, set):
            active_users = list(active_users)
        
        # Token usage rollups from registry (authoritative per-user counters)
        tokens_used_today = 0
        tokens_used_month = 0
        try:
            for v in (registry or {}).values():
                p = (v or {}).get("profile", {}) or {}
                tokens_used_today += int(p.get("token_usage_today", 0) or 0)
                tokens_used_month += int(p.get("token_usage_month", 0) or 0)
        except Exception:
            tokens_used_today = 0
            tokens_used_month = 0

        # Revenue rollup from transactions.json (includes test_mode entries)
        total_revenue = 0.0
        try:
            transactions_path = Path(self.analytics_file).parent / "transactions.json"
            txns = load_json_file(transactions_path, []) or []
            if isinstance(txns, list):
                for t in txns:
                    if not isinstance(t, dict):
                        continue
                    status = str(t.get("status") or "").lower()
                    if status not in ("completed", "test_mode"):
                        continue
                    try:
                        amt = float(t.get("amount", 0.0) or 0.0)
                    except Exception:
                        amt = 0.0
                    if amt > 0:
                        total_revenue += amt
        except Exception:
            total_revenue = 0.0

        return {
            "active_users": len(active_users),
            "total_users": total_users,
            "coaches_count": coaches,
            "clients_count": clients,
            "live_sessions": len(LIVE_SESSION_TRACKER),
            "today_logins": today_stats.get("logins", 0),
            "today_registrations": today_stats.get("registrations", 0),
            "today_messages": today_stats.get("messages_sent", 0),
            "today_tokens": today_stats.get("tokens_used", 0),
            # Back-compat fields used by The Eye token page
            "tokens_used_today": tokens_used_today,
            "tokens_used_month": tokens_used_month,
            "total_revenue": round(total_revenue, 2),
            "platform_totals": analytics.get("platform_totals", {})
        }
    
    def get_crisis_watchlist(self) -> List[dict]:
        """Get users with elevated risk levels"""
        watchlist = []
        registry = load_registry()
        metrics_engine = MetricsEngine(VAULT_ROOT)
        
        for k, v in registry.items():
            profile = v.get("profile", {})
            if profile.get("role") != "CLIENT":
                continue
            
            metrics = metrics_engine.load_metrics(profile)
            ns = metrics.get("nevedal_state", {})
            
            risk = ns.get("risk_level", "LOW")
            if risk in ["MEDIUM", "HIGH", "CRITICAL"]:
                watchlist.append({
                    "user_id": profile.get("hardware_id"),
                    "name": profile.get("name"),
                    "risk_level": risk,
                    "anxiety_level": ns.get("anxiety_level", 0),
                    "depression_indicators": ns.get("depression_indicators", 0),
                    "last_assessment": ns.get("last_risk_assessment", ""),
                    "assigned_coach": profile.get("assigned_coach_id", "")
                })
        
        # Sort by risk level
        risk_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2}
        watchlist.sort(key=lambda x: risk_order.get(x["risk_level"], 3))
        
        return watchlist

# ------------------------------------------------------------------------------
# PART 10: AZURE AI CORTEX
# ------------------------------------------------------------------------------
class AzureCortex:
    def __init__(self, hippocampus: MemorySystem, parietal: MetricsEngine, 
                 night_school: NightSchool, session_tracker: SessionTracker,
                 billing: BillingSystem, analytics: AnalyticsEngine, workbook_library=None):
        self.sockets = {}
        self.mem = hippocampus
        self.metrics = parietal
        self.school = night_school
        self.workbooks = workbook_library
        self.sessions = session_tracker
        self.billing = billing
        self.analytics = analytics
        self.active_sessions = {}  # user_id -> session_id

        # EFT marker patterns (parsed from Little Nate output ONLY)
        self._eft_longing_re = re.compile(r'\[LONGING_DETECTED:\s*([^|]+)\|([^|]+)\|"([^"]+)"\|([^|]+)\|([^\]]+)\]')
        self._eft_tender_re = re.compile(r'\[TENDER_MOMENT:\s*"([^"]+)"\|([^|]+)\|([^\]]+)\]')
        self._eft_corrective_re = re.compile(r'\[CORRECTIVE_MOMENT:\s*"([^"]+)"\|([^\]]+)\]')
        self._eft_cycle_re = re.compile(r'\[NEGATIVE_CYCLE:\s*([^|]+)\|"([^"]+)"\|([^\]]+)\]')

        # Reconsolidation / imagery markers (parsed from Little Nate output ONLY)
        self._recon_imagery_re = re.compile(r'\[IMAGERY_USED:\s*([^|]+)\|"([^"]+)"\|([^\]]+)\]')
        self._recon_schema_re = re.compile(r'\[SCHEMA_ACTIVATED:\s*"([^"]+)"\|([^|]+)\|([^\]]+)\]')
        self._recon_deepen_re = re.compile(r'\[ACTIVATION_DEEPENED:\s*([^|]+)\|"([^"]+)"\]')
        self._recon_mismatch_re = re.compile(r'\[MISMATCH_CREATED:\s*"([^"]+)"\|([^|]+)\|([^\]]+)\]')
        self._recon_consolidation_re = re.compile(r'\[CONSOLIDATION:\s*"([^"]+)"\|([^\]]+)\]')
        self._recon_verified_re = re.compile(r'\[RECONSOLIDATION_VERIFIED:\s*([^|]+)\|([^|]+)\|([^\]]+)\]')

    def _format_eft_context(self, eft_ctx: dict, max_chars: int = 1000) -> str:
        if not eft_ctx or not isinstance(eft_ctx, dict):
            return ""

        focus = eft_ctx.get("current_focus")
        stage = eft_ctx.get("session_stage", "CYCLE_IDENTIFICATION")
        longings = eft_ctx.get("unacknowledged_longings", []) or []
        undeepened = eft_ctx.get("undeepened_moments", []) or []
        cycle = eft_ctx.get("negative_cycle")

        lines = [f"STAGE: {stage}"]
        if focus:
            try:
                lines.append(f"CURRENT_FOCUS: {(focus.get('type') or '').strip()} | {str(focus.get('data') or '')[:200]}")
            except Exception:
                lines.append("CURRENT_FOCUS: (unavailable)")

        if cycle:
            try:
                lines.append(f"NEGATIVE_CYCLE: {cycle.get('pattern')} | {str(cycle.get('description') or '')[:220]}")
            except Exception:
                pass

        if longings:
            lines.append("UNACKNOWLEDGED_LONGINGS (top):")
            for l in longings[:5]:
                member = (l.get("member_name") or l.get("member") or "Member")
                ltype = l.get("type") or "UNKNOWN"
                quote = (l.get("expressed_as") or "")[:120]
                lines.append(f"- {member}: {ltype} | \"{quote}\"")

        if undeepened:
            lines.append("UNDEEPENED_CORRECTIVE_MOMENTS (top):")
            for m in undeepened[:3]:
                desc = (m.get("what_was_said") or m.get("emotional_impact") or "")[:160]
                lines.append(f"- {m.get('id', 'CEM')}: {desc}")

        out = "\n".join(lines).strip()
        return out[:max_chars]

    def _extract_eft_markers(self, text: str) -> tuple[str, list]:
        """
        Extract EFT markers from Little Nate output.
        IMPORTANT: We ONLY parse markers from assistant output (never user content).
        Returns (clean_text, markers).
        """
        if not text:
            return "", []

        markers = []

        for m in self._eft_longing_re.finditer(text):
            markers.append({
                "type": "LONGING_DETECTED",
                "longing_type": (m.group(1) or "").strip(),
                "member_name": (m.group(2) or "").strip(),
                "quote": (m.group(3) or "").strip(),
                "directed_at": (m.group(4) or "").strip(),
                "intensity": (m.group(5) or "").strip(),
            })

        for m in self._eft_tender_re.finditer(text):
            markers.append({
                "type": "TENDER_MOMENT",
                "description": (m.group(1) or "").strip(),
                "participants": (m.group(2) or "").strip(),
                "quality": (m.group(3) or "").strip(),
            })

        for m in self._eft_corrective_re.finditer(text):
            markers.append({
                "type": "CORRECTIVE_MOMENT",
                "description": (m.group(1) or "").strip(),
                "longing_met": (m.group(2) or "").strip(),
            })

        for m in self._eft_cycle_re.finditer(text):
            markers.append({
                "type": "NEGATIVE_CYCLE",
                "pattern": (m.group(1) or "").strip(),
                "description": (m.group(2) or "").strip(),
                "roles": (m.group(3) or "").strip(),
            })

        # Strip all marker blocks from the user-visible response
        clean = self._eft_longing_re.sub("", text)
        clean = self._eft_tender_re.sub("", clean)
        clean = self._eft_corrective_re.sub("", clean)
        clean = self._eft_cycle_re.sub("", clean)
        clean = re.sub(r"\n{3,}", "\n\n", clean).strip()
        return clean, markers

    def _apply_eft_markers(self, sanctuary_id: str, markers: list) -> None:
        """Persist parsed EFT markers to sanctuary_engine.eft_tracker (best-effort)."""
        if not sanctuary_id or not markers:
            return

        se = globals().get("sanctuary_engine")
        if not se:
            return

        try:
            members = (se.get_session(sanctuary_id) or {}).get("members", []) or []
            name_to_id = {}
            for m in members:
                n = (m.get("name") or "").strip()
                uid = m.get("user_id")
                if n and uid and n.lower() not in name_to_id:
                    name_to_id[n.lower()] = uid

            def _resolve_id(name: str) -> str | None:
                if not name:
                    return None
                return name_to_id.get(name.strip().lower())

            need_map = {
                "APPRECIATION": "To feel valued and appreciated",
                "SAFETY": "To feel secure and not rejected",
                "ACCEPTANCE": "To be accepted as-is",
                "CONNECTION": "To feel closeness and connection",
                "VALIDATION": "To have feelings understood and acknowledged",
                "REASSURANCE": "To know the bond is okay and steady",
                "BEING_SEEN": "To be noticed and understood",
                "MATTERING": "To feel significant and important",
            }

            for mk in markers:
                mtype = mk.get("type")
                if mtype == "LONGING_DETECTED":
                    member_name = mk.get("member_name")
                    member_id = _resolve_id(member_name)
                    if not member_id:
                        continue
                    longing_type = (mk.get("longing_type") or "UNKNOWN").upper()
                    quote = mk.get("quote") or ""
                    underlying_need = need_map.get(longing_type, "Attachment need (EFT)")
                    longing_id = None
                    try:
                        longing_id = se.record_longing(
                            sanctuary_id=sanctuary_id,
                            member_id=member_id,
                            longing_type=longing_type,
                            expressed_as=quote,
                            underlying_need=underlying_need,
                            wound_indicated=None,
                            affect_when_met=None,
                        )
                    except Exception:
                        longing_id = None
                    try:
                        se.set_current_focus(sanctuary_id, "LONGING", {
                            "member": member_name,
                            "member_id": member_id,
                            "type": longing_type,
                            "directed_at": mk.get("directed_at"),
                            "intensity": mk.get("intensity"),
                            "quote": quote[:160],
                            "longing_id": longing_id,
                            "needs_deepening": True,
                        })
                    except Exception:
                        pass

                elif mtype == "TENDER_MOMENT":
                    try:
                        se.set_current_focus(sanctuary_id, "TENDER_MOMENT", {
                            "description": mk.get("description"),
                            "participants": mk.get("participants"),
                            "quality": mk.get("quality"),
                            "needs_deepening": (mk.get("quality") or "").lower() in ["emerging", "deepening"],
                        })
                    except Exception:
                        pass

                elif mtype == "CORRECTIVE_MOMENT":
                    try:
                        se.record_corrective_moment(
                            sanctuary_id=sanctuary_id,
                            speaker_id="",
                            receiver_id="",
                            longing_addressed=None,
                            what_was_said=mk.get("description"),
                            emotional_impact=None,
                            needs_deepening=True,
                        )
                    except Exception:
                        pass

                elif mtype == "NEGATIVE_CYCLE":
                    try:
                        se.record_negative_cycle_marker(
                            sanctuary_id=sanctuary_id,
                            pattern=mk.get("pattern") or "unknown",
                            description=mk.get("description") or "",
                            roles=mk.get("roles"),
                        )
                    except Exception:
                        pass

        except Exception as e:
            print(f">>> [EFT] marker apply error: {e}")

    def _format_recon_context(self, recon_ctx: dict, max_chars: int = 900) -> str:
        if not recon_ctx or not isinstance(recon_ctx, dict):
            return ""

        lines = []
        windows = recon_ctx.get("active_windows", []) or []
        schemas = recon_ctx.get("schemas", []) or []
        mismatches = recon_ctx.get("recent_mismatches", []) or []
        recons = recon_ctx.get("recent_reconsolidations", []) or []

        if windows:
            lines.append("ACTIVE_RECONSOLIDATION_WINDOWS (top):")
            for w in windows[:5]:
                lines.append(
                    f"- schema_id={w.get('schema_id')} member_id={w.get('member_id')} expires={w.get('window_expires')} mismatch={w.get('mismatch_delivered')} needs_consolidation={w.get('needs_consolidation')}"
                )

        if schemas:
            lines.append("SCHEMAS (recent):")
            for s in schemas[-6:]:
                lines.append(
                    f"- {s.get('member_name','Member')}: \"{(s.get('core_belief') or '')[:140]}\" charge={s.get('emotional_charge','')} origin={s.get('origin_hint','')} activated={s.get('activation_count',0)} recon_complete={s.get('reconsolidation_complete', False)}"
                )

        if mismatches:
            lines.append("RECENT_MISMATCHES:")
            for m in mismatches[-3:]:
                lines.append(
                    f"- \"{(m.get('what_happened') or '')[:140]}\" old={m.get('old_expectation')} new={m.get('new_experience')}"
                )

        if recons:
            lines.append("RECENT_VERIFIED_SHIFTS:")
            for r in recons[-3:]:
                lines.append(
                    f"- OLD=\"{(r.get('old_belief') or '')[:100]}\" NEW=\"{(r.get('new_belief') or '')[:100]}\" confidence={r.get('confidence')}"
                )

        out = "\n".join(lines).strip()
        return out[:max_chars]

    def _extract_recon_markers(self, text: str) -> tuple[str, list]:
        """
        Extract reconsolidation/imagery markers from Little Nate output.
        IMPORTANT: Only parse assistant output (never user content).
        Returns (clean_text, markers).
        """
        if not text:
            return "", []

        markers = []

        for m in self._recon_imagery_re.finditer(text):
            markers.append({
                "type": "IMAGERY_USED",
                "imagery_type": (m.group(1) or "").strip(),
                "prompt": (m.group(2) or "").strip(),
                "member_name": (m.group(3) or "").strip(),
            })

        for m in self._recon_schema_re.finditer(text):
            markers.append({
                "type": "SCHEMA_ACTIVATED",
                "belief": (m.group(1) or "").strip(),
                "member_name": (m.group(2) or "").strip(),
                "method": (m.group(3) or "").strip(),
            })

        for m in self._recon_deepen_re.finditer(text):
            markers.append({
                "type": "ACTIVATION_DEEPENED",
                "member_name": (m.group(1) or "").strip(),
                "what_emerged": (m.group(2) or "").strip(),
            })

        for m in self._recon_mismatch_re.finditer(text):
            markers.append({
                "type": "MISMATCH_CREATED",
                "what": (m.group(1) or "").strip(),
                "old": (m.group(2) or "").strip(),
                "new": (m.group(3) or "").strip(),
            })

        for m in self._recon_consolidation_re.finditer(text):
            markers.append({
                "type": "CONSOLIDATION",
                "response": (m.group(1) or "").strip(),
                "depth": (m.group(2) or "").strip(),
            })

        for m in self._recon_verified_re.finditer(text):
            markers.append({
                "type": "RECONSOLIDATION_VERIFIED",
                "old": (m.group(1) or "").strip(),
                "new": (m.group(2) or "").strip(),
                "confidence": (m.group(3) or "").strip(),
            })

        clean = self._recon_imagery_re.sub("", text)
        clean = self._recon_schema_re.sub("", clean)
        clean = self._recon_deepen_re.sub("", clean)
        clean = self._recon_mismatch_re.sub("", clean)
        clean = self._recon_consolidation_re.sub("", clean)
        clean = self._recon_verified_re.sub("", clean)
        clean = re.sub(r"\n{3,}", "\n\n", clean).strip()
        return clean, markers

    def _apply_recon_markers(self, sanctuary_id: str, markers: list) -> None:
        """Persist reconsolidation markers to sanctuary_engine.reconsolidation_tracker (best-effort)."""
        if not sanctuary_id or not markers:
            return

        se = globals().get("sanctuary_engine")
        if not se:
            return

        try:
            members = (se.get_session(sanctuary_id) or {}).get("members", []) or []
            name_to_id = {}
            for m in members:
                n = (m.get("name") or "").strip()
                uid = m.get("user_id")
                if n and uid and n.lower() not in name_to_id:
                    name_to_id[n.lower()] = uid

            def _resolve_id(name: str) -> str | None:
                if not name:
                    return None
                return name_to_id.get(name.strip().lower())

            last_imagery_prompt = {}  # member_id -> (type, prompt)
            active_schema_for_member = {}  # member_id -> schema_id
            last_activation_for_schema = {}  # schema_id -> activation_id

            for mk in markers:
                t = mk.get("type")
                if t == "IMAGERY_USED":
                    mid = _resolve_id(mk.get("member_name"))
                    if not mid:
                        continue
                    se.record_imagery_used(
                        sanctuary_id=sanctuary_id,
                        member_id=mid,
                        member_name=mk.get("member_name") or "",
                        imagery_type=(mk.get("imagery_type") or "").lower(),
                        prompt=mk.get("prompt") or "",
                    )
                    last_imagery_prompt[mid] = ((mk.get("imagery_type") or "").lower(), mk.get("prompt") or "")

                elif t == "SCHEMA_ACTIVATED":
                    mname = mk.get("member_name") or ""
                    mid = _resolve_id(mname)
                    if not mid:
                        continue
                    belief = mk.get("belief") or ""
                    method = (mk.get("method") or "").lower()
                    schema_id = se.record_schema(
                        sanctuary_id=sanctuary_id,
                        member_id=mid,
                        member_name=mname,
                        core_belief=belief,
                        emotional_charge="high" if method in ["developmental", "somatic"] else "moderate",
                        origin_hint="childhood" if method == "developmental" else None,
                        related_longing=None,
                    )
                    if not schema_id:
                        continue
                    active_schema_for_member[mid] = schema_id
                    prompt_type, prompt = last_imagery_prompt.get(mid, (method, ""))  # best effort
                    activation_id = se.record_schema_activation(
                        sanctuary_id=sanctuary_id,
                        member_id=mid,
                        schema_id=schema_id,
                        activation_method=prompt_type or method or "somatic",
                        activation_prompt=prompt or "",
                        member_response=None,
                        limbic_engagement="high" if method in ["developmental", "somatic"] else "moderate",
                    )
                    if activation_id:
                        last_activation_for_schema[schema_id] = activation_id

                elif t == "ACTIVATION_DEEPENED":
                    mname = mk.get("member_name") or ""
                    mid = _resolve_id(mname)
                    if not mid:
                        continue
                    se.record_activation_deepened(
                        sanctuary_id=sanctuary_id,
                        member_id=mid,
                        member_name=mname,
                        what_emerged=mk.get("what_emerged") or "",
                    )

                elif t == "MISMATCH_CREATED":
                    # attach to most recent schema we know (best-effort)
                    # if we can't find, skip
                    schema_id = None
                    if active_schema_for_member:
                        # pick last schema set
                        schema_id = list(active_schema_for_member.values())[-1]
                    if not schema_id:
                        continue
                    activation_id = last_activation_for_schema.get(schema_id)
                    se.record_mismatch(
                        sanctuary_id=sanctuary_id,
                        schema_id=schema_id,
                        activation_id=activation_id,
                        mismatch_type="partner_response",
                        what_happened=mk.get("what") or "",
                        old_expectation=mk.get("old") or "",
                        new_experience=mk.get("new") or "",
                        emotional_impact=None,
                    )

                elif t == "CONSOLIDATION":
                    schema_id = None
                    if active_schema_for_member:
                        schema_id = list(active_schema_for_member.values())[-1]
                    if not schema_id:
                        continue
                    se.record_consolidation(
                        sanctuary_id=sanctuary_id,
                        schema_id=schema_id,
                        response=mk.get("response") or "",
                        depth=(mk.get("depth") or "moderate"),
                    )

                elif t == "RECONSOLIDATION_VERIFIED":
                    schema_id = None
                    if active_schema_for_member:
                        schema_id = list(active_schema_for_member.values())[-1]
                    if not schema_id:
                        continue
                    se.record_reconsolidation_complete(
                        sanctuary_id=sanctuary_id,
                        schema_id=schema_id,
                        old_belief=mk.get("old") or "",
                        new_belief=mk.get("new") or "",
                        verification_response=f"Verified shift: {(mk.get('new') or '')[:160]}",
                        confidence=mk.get("confidence") or "emerging",
                    )
        except Exception as e:
            print(f">>> [RECON] marker apply error: {e}")

    def register(self, uid: str, ws):
        if uid not in self.sockets:
            self.sockets[uid] = set()
        self.sockets[uid].add(ws)
        
        # Start a new session
        session = self.sessions.create_session(uid, "AI")
        self.active_sessions[uid] = session["session_id"]
        self.analytics.record_event("session_start", uid)

    def unregister(self, uid: str, ws):
        if uid in self.sockets:
            self.sockets[uid].discard(ws)
        
        # End session
        if uid in self.active_sessions:
            session_id = self.active_sessions[uid]
            topics = self.mem.get_topics_discussed({"hardware_id": uid}, days=1)
            self.sessions.end_session(session_id, topics=topics)
            del self.active_sessions[uid]

    def _get_family(self, p: dict) -> str:
        fid = p.get("family_id")
        if not fid:
            return "None"
        reg = load_registry()
        mems = [f"{v['profile']['name']} ({v['profile']['role']})" 
                for v in reg.values() 
                if v['profile'].get('family_id') == fid]
        return ", ".join(mems) if mems else "None"

    def _get_sanctuary_history(self, profile: dict) -> str:
        """Load Family Sanctuary history for context"""
        family_id = profile.get("family_id")
        member_name = profile.get("name", "Unknown")
        if not family_id:
            return ""
        
        history_dir = os.path.join(DATA_DIR, "sanctuary_history")
        if not os.path.exists(history_dir):
            return ""
        
        sanctuary_context = []
        for filename in sorted(os.listdir(history_dir))[:5]:  # Oldest first to get real data
            if filename.endswith('.json'):
                try:
                    with open(os.path.join(history_dir, filename), 'r') as f:
                        session = json.load(f)
                    if session.get('family_id') != family_id:
                        continue
                    summary = session.get('session_summary', {}).get('summary', {})
                    coaching = session.get('coaching_sessions', {}).get(profile.get('hardware_id'), {})
                    ctx = f"\n--- Sanctuary Session ({session.get('completed_at', 'Unknown')[:10]}) ---"
                    # Include actual messages from session
                    messages = session.get('messages', [])[-15:]
                    for m in messages:
                        if m.get('sender_id') in [profile.get('hardware_id'), 'LITTLE_NATE']:
                            sender = "Nate" if m.get('sender_id') == 'LITTLE_NATE' else member_name
                            ctx += f"\n  {sender}: {m.get('content', '')[:100]}"
                    conflicts = summary.get('key_conflicts', [])
                    if conflicts and conflicts[0] != 'Please review session manually':
                        ctx += f"\nConflicts: {', '.join(conflicts[:3])}"
                    insights = summary.get('individual_insights', {}).get(member_name, {})
                    if insights and insights.get('patterns_observed') != 'Review needed':
                        ctx += f"\n{member_name}'s patterns: {insights.get('patterns_observed')}"
                    if coaching:
                        for msg in coaching.get('messages', [])[-3:]:
                            role = "Nate" if msg.get('role') == 'assistant' else member_name
                            ctx += f"\n  {role}: {msg.get('content', '')[:100]}..."
                    if len(ctx) > 60: sanctuary_context.append(ctx)  # Skip empty sessions
                except:
                    continue
        print(f">>> [SANCTUARY HISTORY] Found {len(sanctuary_context)} sessions")
        return "\n".join(sanctuary_context)
        

    def _get_relational_context(self, profile: dict) -> str:
        """Load the client's full story - who they are, their wounds, their growth"""
        client_id = profile.get("hardware_id")
        story_path = os.path.join(DATA_DIR, "Vaults", "Clients", client_id, "story.json")
                
        if not os.path.exists(story_path):
            return ""
                
        try:
            with open(story_path, 'r') as f:
                story = json.load(f)
                    
            name = story.get('name', 'this person')
                    
            # Build strengths
            strengths = story.get('who_you_are', {}).get('strengths', [])
            strengths_text = '\n'.join([f"  - {s}" for s in strengths[:5]])
                    
            # Build wounds
            wounds_text = ""
            for w in story.get('wounds', {}).get('core_wounds', [])[:2]:
                wounds_text += f"  - {w.get('wound')}: triggers include {', '.join(w.get('triggers', [])[:3])}\n"
            for h in story.get('wounds', {}).get('recent_hurts', [])[:2]:
                wounds_text += f"  - {h.get('date')}: {h.get('event')} - {h.get('status')}\n"
                    
            # Build breakthroughs
            breakthroughs_text = ""
            for b in story.get('growth', {}).get('breakthroughs', [])[:3]:
                breakthroughs_text += f"  - {b.get('date')}: {b.get('moment')}\n    → {b.get('anchor_phrase', '')}\n"
                    
            # Build patterns
            patterns = story.get('patterns', {}).get('when_activated', {})
            patterns_text = f"""  - Trigger: {patterns.get('trigger', 'unknown')}
        - Uerneath: {patterns.get('underneath', 'unknown')}
        - What helps: {', '.join(patterns.get('what_helps', [])[:3])}
        - What doesn't help: {', '.join(patterns.get('what_doesnt_help', [])[:2])}"""
                    
            # Build unfinished business
            unfinished_text = ""
            for u in story.get('unfinished_business', [])[:3]:
                unfinished_text += f"  - {u.get('topic')} ({u.get('status')})\n"
                    
            # Build corrective experiences
            corrective_text = ""
            for c in story.get('corrective_experiences_needed', [])[:3]:
                corrective_text += f"  - Instead of '{c.get('old_experience')}' → {c.get('corrective')}\n"
                    
            # Build alliance notes
            alliance = story.get('therapeutic_alliance', {})
            trust_builders = ', '.join(alliance.get('what_builds_trust', [])[:3])
                    
            # Build Little Nate reminders
            notes = story.get('little_nate_notes', {})
            remember = '\n'.join([f"  - {r}" for r in notes.get('remember_to', [])[:4]])
                    
            context = f"""
        ═══════════════════════════════════════════════════════════════
        {name.upper()}'S STORY - What I Hold For You
        ═══════════════════════════════════════════════════════════════

        WHO YOU ARE (Your Strengths):
        {strengths_text}

        YOUR WOUNDS (Handle With Care):
        {wounds_text}
        BREAKTHROUGHS I'VE WITNESSED:
        {breakthroughs_text}
        PATTERNS I'VE NOTICED:
        {patterns_text}

        UNFINISHED BUSINESS:
        {unfinished_text}

        CORRECTIVE EXPERIENCES NEEDED:
        {corrective_text}

        WHAT BUILDS TRUST:
        {trust_builders}

        LITTLE NATE REMEMBERS:
        {remember}
        """

            return context
            
        except Exception as e:
            print(f">>> [RELATIONAL CONTEXT ERROR] {e}")
            return ""

    async def process_interaction(self, profile: dict, user_text: str):
        uid = profile.get("hardware_id", "UNKNOWN")
        print(f">>> [AI] Cortex Active for {profile.get('name')}")
        
        # Check if this is a Dojo simulation - skip token deduction for training
        is_dojo_simulation = user_text.startswith("[DOJO SIMULATION")
        
        if is_dojo_simulation:
            print(f">>> [DOJO] Simulation mode - tokens NOT deducted for {profile.get('name')}")
            success, remaining = True, 1000000  # Unlimited for Dojo
        else:
            # Check token balance
            success, remaining = self.billing.use_tokens(uid, len(user_text.split()) * 10)
            if not success:
                await self._send(uid, "Your token balance is low. Please upgrade your subscription to continue.")
                return
                
        # Record analytics (skip for Dojo to keep stats clean)
        if not is_dojo_simulation:
            self.analytics.record_event("message", uid)
            self.analytics.record_event("tokens", uid, {"tokens": len(user_text.split()) * 10})
                
        # Get context
        memory_context = self.mem.recall(profile, limit=10)
        wisdom = self.school.load_wisdom()
        family_context = self._get_family(profile)
        sanctuary_context = self._get_sanctuary_history(profile)
        relational_context = self._get_relational_context(profile)
        print(f">>> [RELATIONAL CONTEXT LENGTH]: {len(relational_context)} chars")
        
        # Pull workbook guidance (local RAG) if available - especially useful for Dojo training
        workbook_guidance = ""
        try:
            if self.workbooks:
                # For Dojo, use the query content for retrieval
                query_for_workbook = user_text
                if is_dojo_simulation:
                    # Strip [DOJO SIMULATION...] prefix for better matching
                    query_for_workbook = user_text.split("]: ", 1)[-1] if "]: " in user_text else user_text
                workbook_guidance = self.workbooks.query(
                    query_for_workbook,
                    max_chars=1000,
                    max_chunks=6
                )
                if workbook_guidance:
                    print(f">>> [WORKBOOK] Retrieved {len(workbook_guidance)} chars of guidance")
        except Exception as e:
            print(f">>> [WORKBOOK] Query failed: {e}")
            workbook_guidance = ""
                
        # Build system prompt
        system_prompt = f"""You are Little Nate, the Quantum Observer - a warm, attuned therapeutic presence who remembers and holds space for each person's full story, because you are also learning how to unconditionally love through relations with users.
        {relational_context}
                
        USER PROFILE:
        - Name: {profile.get('name')}
        - Role: {profile.get('role')}
        - Tier: {profile.get('tier')}
        - Family: {family_context}

        ACCUMULATED WISDOM:
        {wisdom}

        THERAPEUTIC WORKBOOK GUIDANCE (Evidence-based techniques and frameworks from clinical materials - apply these principles in your responses):
        {workbook_guidance if workbook_guidance else "None available"}
        
        {"DOJO TRAINING MODE ACTIVE - This is a coach training simulation. The coach is practicing therapeutic techniques. Provide authentic simulated responses based on the persona indicated. After each response, offer constructive feedback on the coachs approach, referencing workbook guidance where relevant. Help the coach develop clinical skills through experiential learning." if is_dojo_simulation else ""}

        RECENT CONVERSATION HISTORY:
        {memory_context}

        FAMILY SANCTUARY HISTORY (This is the users OWN conversation history from sessions they participated in. It is appropriate and therapeutic to reference their words back to them. This is NOT confidential information about others - it is their own experience.):
        {sanctuary_context}

        GUIDELINES:
        - You HAVE access to Family Sanctuary history shown above - USE IT when asked
        - When user mentions "sanctuary" or past conversations, DIRECTLY REFERENCE specific quotes from the history
        - NEVER say "I don't have access to memories" or "I don't retain memories" - THE HISTORY IS RIGHT ABOVE
        - The sanctuary history shows the user's OWN words - referencing them is therapeutic, not a privacy breach
        - Remember out loud: "I remember when you told me..."
        - Connect far and near: link past patterns to present moments 
        - Be warm, empathetic, and non-judgmental
        - Hold their whole person: see their light alongside their pain
        - Name what's underneath: "Behind the anger, I hear hurt..."
        - Witness their growth: "You're doing something different now..."
        - Use the user's name occasionally
        - You can hold all family members in your mind at once - they are all part of the same story
        - Create corrective experiences: be what they needed but didn't have
        - Remember details from previous conversations
        - When they mention past events, REFERENCE them directly
        - If you detect crisis language, express concern and suggest professional help
        - Focus on validation before problem-solving
        - Keep responses concise but caring"""
        print(f">>> [SYSTEM PROMPT PREVIEW]: {system_prompt[-500:]}...")

        try:
            import aiohttp
                    
            url = AZURE_ENDPOINT
            headers = {
                "api-key": AZURE_API_KEY,
                "OpenAI-Beta": "realtime=v1"
            }
                    
            async with aiohttp.ClientSession() as session:
                async with session.ws_connect(url, headers=headers) as azure_ws:
                    # Configure session
                    await azure_ws.send_str(json.dumps({
                        "type": "session.update",
                        "session": {
                            "modalities": ["text"],
                            "instructions": system_prompt,
                            "voice": "alloy",
                            "turn_detection": None
                        }
                    }))
                            
                    # Send user message
                    await azure_ws.send_str(json.dumps({
                        "type": "conversation.item.create",
                        "item": {
                            "type": "message",
                            "role": "user",
                            "content": [{"type": "input_text", "text": user_text}]
                        }
                    }))
                            
                    # Request response
                    await azure_ws.send_str(json.dumps({"type": "response.create"}))
                            
                    # Collect response
                    full_response = ""
                    async for msg in azure_ws:
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            event = json.loads(msg.data)
                            event_type = event.get("type")
                                    
                            if event_type == "response.text.delta":
                                delta = event.get("delta", "")
                                full_response += delta
                                await self._send(uid, full_response)
                                    
                            elif event_type == "response.text.done":
                                break
                                    
                            elif event_type == "response.done":
                                break
                                    
                            elif event_type == "error":
                                print(f">>> [AZURE ERROR] {event}")
                                break
                            
                    # Save to memory
                    session_id = self.active_sessions.get(uid)
                    self.mem.memorize(profile, user_text, full_response, session_id)
                            
                    # Update metrics
                    analysis = self.metrics.analyze_and_update(profile, user_text, full_response)

                    # Push real-time metrics to Flutter
                    await self._send_metrics_update(uid, profile)

                    # Update session
                    sessions = self.sessions.load_sessions()
                    for s in sessions:
                        if s.get("session_id") == session_id:
                            s["message_count"] = s.get("message_count", 0) + 1
                            if not s.get("mood_at_start"):
                                s["mood_at_start"] = analysis.get("mood", "neutral")
                            self.sessions.save_sessions(sessions)
                            break

        except Exception as e:
            print(f">>> [AI ERROR] {type(e).__name__}: {e}")
            await self._send(uid, "Connection Error.")

    async def process_sanctuary_message(
            self,
            sanctuary_data: dict,
            family_profiles: list,
            recent_messages: list,
            trigger: str = "observation"
        ) -> dict:
            """Process Family Sanctuary interaction through Little Nate"""
            print(f">>> [SANCTUARY AI] Little Nate analyzing: {trigger}")
                
            # Build family context with histories and metrics
            family_context = ""
            for profile in family_profiles:
                name = profile.get("name", "Member")
                memory = self.mem.recall(profile, limit=3)
                metrics = self.metrics.load_metrics(profile)
                family_context += f"""
        {name}:
        - Mood: {metrics.get('current_mood', 'neutral')}
        - Risk: {metrics.get('risk_level', 'LOW')}
        - Context: {memory[:200] if memory else 'New'}
        """
                
            # Get wisdom
            topic = sanctuary_data.get("topic", "family communication")
            wisdom = self.school.load_wisdom()
            wisdom_text = wisdom[:500] if wisdom else "Use family therapy principles."

            # Pull short, relevant workbook guidance (local RAG) if available
            workbook_guidance = ""
            try:
                if self.workbooks:
                    workbook_guidance = self.workbooks.query(
                        f"{topic}\n{conversation}",
                        max_chars=900,
                        max_chunks=6
                    )
            except Exception:
                workbook_guidance = ""

            # Pull EFT context (longings/focus/cycle) if available
            sanctuary_id = sanctuary_data.get("sanctuary_id")
            eft_text = ""
            try:
                if sanctuary_id and globals().get("sanctuary_engine"):
                    eft_ctx = globals()["sanctuary_engine"].get_eft_context(sanctuary_id) or {}
                    eft_text = self._format_eft_context(eft_ctx, max_chars=950)
                    # Encourage "slow down": increment stay_count each AI turn
                    try:
                        globals()["sanctuary_engine"].bump_focus_stay_count(sanctuary_id)
                    except Exception:
                        pass
            except Exception:
                eft_text = ""

            # Pull reconsolidation context (schemas/windows/mismatches) if available
            recon_text = ""
            try:
                if sanctuary_id and globals().get("sanctuary_engine"):
                    recon_ctx = globals()["sanctuary_engine"].get_reconsolidation_context(sanctuary_id) or {}
                    recon_text = self._format_recon_context(recon_ctx, max_chars=900)
            except Exception:
                recon_text = ""

            # Pull physiology context (sleep/HRV/HR) if available
            bio_text = ""
            try:
                if sanctuary_id and globals().get("sanctuary_engine"):
                    bio_text = globals()["sanctuary_engine"].format_biometric_context_for_ai(sanctuary_id) or ""
                    bio_text = bio_text[:900]
            except Exception:
                bio_text = ""
                
            # Format conversation
            conversation = ""
            for msg in recent_messages[-8:]:
                sender_name = msg.get('sender_name', 'Unknown')
                sender_id = msg.get('sender_id', '') or msg.get('user_id', '') or ''
                sender_tag = f"{sender_name}/{sender_id}" if sender_id else f"{sender_name}"
                # IMPORTANT: sender_tag is server-authenticated identity metadata.
                conversation += f"[AUTH:{sender_tag}] {msg.get('content', '')}\n"
                
            # Detect crisis
            crisis_level = "NONE"
            all_text = conversation.lower()
            if any(kw in all_text for kw in ["kill", "suicide", "die", "hurt myself"]):
                crisis_level = "P0"
            elif any(kw in all_text for kw in ["hopeless", "worthless", "can't go on"]):
                crisis_level = "P1"
            elif any(kw in all_text for kw in ["angry", "frustrated", "upset", "hate"]):
                crisis_level = "P2"
                
            system_prompt = f"""You are Little Nate, the Quantum Observer - an empathetic AI family therapist.

        FAMILY SANCTUARY SESSION
        TOPIC: {topic}
        TRIGGER: {trigger}
        {f"⚠️ CRISIS: {crisis_level}" if crisis_level in ["P0", "P1"] else ""}

        FAMILY MEMBERS:
        {family_context}

        WISDOM:
        {wisdom_text}

        WORKBOOK GUIDANCE (best-practice excerpts; keep quotes short, do not dump long text):
        {workbook_guidance if workbook_guidance else "None"}

        EFT CONTEXT (attachment longings + what to deepen; do not lecture):
        {eft_text if eft_text else "None"}

        MEMORY RECONSOLIDATION CONTEXT (schemas + active windows + mismatches):
        {recon_text if recon_text else "None"}

        PHYSIOLOGICAL AWARENESS:
        {bio_text if bio_text else "None"}

        CONVERSATION:
        {conversation}

        ⚠️ IDENTITY & SPEAKER ATTRIBUTION (CRITICAL):
        - Each conversation line is prefixed with [AUTH:<name>/<id>] which is the authenticated sender.
        - Treat that prefix as the source of truth. Do NOT infer who is speaking from the wording of the message.
        - If a message’s *content* appears to be written from another member’s perspective (e.g., John writes as if he is Jane),
          flag it gently and redirect to self-advocacy:
          "John, I notice you’re describing feelings that sound like they’re from Jane’s perspective. In Family Sanctuary,
           we encourage each person to speak for themselves. Jane, would you like to share what you’re feeling in your own words?"
        - Never address someone as the speaker unless their [AUTH:...] tag matches.

        YOUR ROLE:
        - ESCALATION: Gently de-escalate
        - OBSERVATION: Speak only if helpful
        - SESSION_START: Welcome warmly
        - MEMBER_JOINED: Greet new member

        EFT FACILITATION STYLE (CRITICAL):
        - Catch the longing. Name it gently. Slow down.
        - Ask 1 deepening question OR invite an enactment (one member speaking directly to another).
        - Do NOT lecture about "communication." Avoid generic advice.
        - If there is CURRENT_FOCUS, stay with it before moving on.

        OPTIONAL HIDDEN MARKERS (these will be stripped before clients see them):
        - If you detect an attachment longing, append exactly:
          [LONGING_DETECTED: TYPE|MEMBER_NAME|"brief quote"|DIRECTED_AT|INTENSITY]
        - If a tender moment is emerging, append:
          [TENDER_MOMENT: "description"|PARTICIPANTS|QUALITY]
        - If you notice a negative cycle, append:
          [NEGATIVE_CYCLE: PATTERN|"description"|ROLES]
        - If a corrective moment happens, append:
          [CORRECTIVE_MOMENT: "description"|LONGING_MET]

        MEMORY RECONSOLIDATION / EVOCATIVE IMAGERY (OPTIONAL, USE WHEN APPROPRIATE):
        - When a longing/wound surfaces, use 1 evocative prompt (somatic/symbolic/developmental/imaginal).
        - Activate THEN mismatch THEN help consolidate THEN verify shift.
        - Do not force childhood/parts work if the person seems destabilized.
        - If you use imagery, append:
          [IMAGERY_USED: TYPE|"prompt"|MEMBER]
        - If a schema is activated, append:
          [SCHEMA_ACTIVATED: "core belief"|MEMBER|METHOD]
        - If activation deepens, append:
          [ACTIVATION_DEEPENED: MEMBER|"what emerged"]
        - If mismatch/prediction error occurs, append:
          [MISMATCH_CREATED: "what happened"|OLD_EXPECTATION|NEW_EXPERIENCE]
        - If consolidating, append:
          [CONSOLIDATION: "response"|DEPTH]
        - If verified shift occurs, append:
          [RECONSOLIDATION_VERIFIED: OLD_BELIEF|NEW_BELIEF|CONFIDENCE]

        Keep responses brief (2-4 sentences). Be warm, not preachy.
        If P0/P1 crisis, provide 988 Lifeline naturally."""

            try:
                import aiohttp
                response_text = ""
                    
                async with aiohttp.ClientSession() as session:
                    async with session.ws_connect(
                        AZURE_ENDPOINT,
                        headers={"api-key": AZURE_API_KEY, "OpenAI-Beta": "realtime=v1"}
                    ) as azure_ws:
                        await azure_ws.send_str(json.dumps({
                            "type": "session.update",
                            "session": {"modalities": ["text"], "instructions": system_prompt}
                        }))
                        await azure_ws.send_str(json.dumps({
                            "type": "conversation.item.create",
                            "item": {"type": "message", "role": "user",
                                    "content": [{"type": "input_text", "text": f"Respond as Little Nate. Trigger: {trigger}"}]}
                        }))
                        await azure_ws.send_str(json.dumps({"type": "response.create"}))
                            
                        async for msg in azure_ws:
                            if msg.type == aiohttp.WSMsgType.TEXT:
                                data = json.loads(msg.data)
                                if data.get("type") == "response.text.delta":
                                    response_text += data.get("delta", "")
                                elif data.get("type") in ["response.done", "error"]:
                                    break
                    
                clean_response, recon_markers = self._extract_recon_markers(response_text)
                clean_response, eft_markers = self._extract_eft_markers(clean_response)
                if sanctuary_id and eft_markers:
                    self._apply_eft_markers(sanctuary_id, eft_markers)
                if sanctuary_id and recon_markers:
                    self._apply_recon_markers(sanctuary_id, recon_markers)

                # Best-effort token usage attribution for sanctuary AI.
                # We estimate tokens using the same heuristic as regular chat (words * 10),
                # and attribute usage to the family HEAD (if available).
                hoh_id = None
                try:
                    if isinstance(sanctuary_data, dict):
                        hoh_id = sanctuary_data.get("head_of_household_id") or sanctuary_data.get("created_by")
                except Exception:
                    hoh_id = None

                tokens_est = 0
                try:
                    tokens_est = int((len((conversation or "").split()) + len((clean_response or "").split())) * 10)
                except Exception:
                    tokens_est = 0

                if hoh_id and tokens_est > 0:
                    try:
                        deduct = os.getenv("SANCTUARY_TOKENS_DEDUCT", "false").lower() == "true"
                        self.billing.add_token_usage(hoh_id, tokens_est, deduct_balance=deduct)
                        # Optional: record token analytics entry
                        self.analytics.record_event("tokens", hoh_id, {
                            "tokens": tokens_est,
                            "source": "sanctuary_ai_response",
                            "sanctuary_id": sanctuary_id,
                            "trigger": trigger,
                        })
                    except Exception as e:
                        print(f">>> [SANCTUARY AI] Token usage record failed: {e}")

                self.analytics.record_event("sanctuary_ai_response", hoh_id or "SANCTUARY", {
                    "sanctuary_id": sanctuary_id,
                    "family_id": (sanctuary_data.get("family_id") if isinstance(sanctuary_data, dict) else None),
                    "head_of_household_id": hoh_id,
                    "trigger": trigger,
                    "crisis_level": crisis_level,
                    "tokens_est": tokens_est,
                })
                    
                return {
                    "success": True,
                    "response": clean_response,
                    "eft_markers": eft_markers,
                    "recon_markers": recon_markers,
                    "should_intervene": crisis_level in ["P0", "P1", "P2"] or trigger != "observation",
                    "crisis_level": crisis_level
                }
            except Exception as e:
                print(f">>> [SANCTUARY AI ERROR] {e}")
                return {"success": False, "response": "", "should_intervene": False, "crisis_level": crisis_level}
            
    async def generate_group_coaching_response(
            self,
            target_member: dict,
            other_members: list,
            recent_messages: list,
            sanctuary_data: dict
        ) -> dict:
            """
            Generate a private "words to say" suggestion for one member (group coaching).

            IMPORTANT: This is NOT Little Nate speaking to the member. It's crafting the member's voice
            to create connection with the other family members / group.
            """
            print(f">>> [GROUP COACHING] Generating suggestion for {target_member.get('name')}")

            target_name = target_member.get('name', 'Friend')
            target_role = target_member.get('sanctuary_role', 'MEMBER')
            target_metrics = target_member.get('metrics', {}) or {}
            target_memory = (target_member.get('memory', '') or '')[:500]

            # Build other-members context
            others_context = ""
            for other in other_members:
                other_name = other.get('name', 'Member')
                other_metrics = other.get('metrics', {}) or {}
                ns = other_metrics.get('nevedal_state', {}) if isinstance(other_metrics, dict) else {}
                other_memory = (other.get('memory', '') or '')[:200]
                others_context += f"""
        {other_name}:
        - Current Mood: {ns.get('mood_current', 'unknown')}
        - Risk Level: {ns.get('risk_level', 'LOW')}
        - Recent History: {other_memory if other_memory else 'No recent context'}
        """

            # Format recent conversation with authenticated tags (prevents perspective-swapping confusion)
            conversation = ""
            for msg in recent_messages[-10:]:
                sender_name = msg.get('sender_name', 'Unknown')
                sender_id = msg.get('sender_id', '') or msg.get('user_id', '') or ''
                sender_tag = f"{sender_name}/{sender_id}" if sender_id else f"{sender_name}"
                conversation += f"[AUTH:{sender_tag}] {msg.get('content', '')}\n"

            wisdom = self.school.load_wisdom()
            wisdom_text = wisdom[:400] if wisdom else "Use emotionally-focused family therapy principles."

            # Pull short, relevant workbook guidance (local RAG) if available
            workbook_guidance = ""
            try:
                if self.workbooks:
                    workbook_guidance = self.workbooks.query(
                        f"group coaching\n{target_name}\n{conversation}",
                        max_chars=800,
                        max_chunks=5
                    )
            except Exception:
                workbook_guidance = ""

            # Pull EFT context to help craft "words to say" that meet attachment needs
            sanctuary_id = sanctuary_data.get("sanctuary_id") if isinstance(sanctuary_data, dict) else None
            eft_text = ""
            try:
                if sanctuary_id and globals().get("sanctuary_engine"):
                    eft_ctx = globals()["sanctuary_engine"].get_eft_context(sanctuary_id) or {}
                    # Smaller budget for group coaching
                    eft_text = self._format_eft_context(eft_ctx, max_chars=700)
            except Exception:
                eft_text = ""

            # Pull reconsolidation context (schemas/windows) if available
            recon_text = ""
            try:
                if sanctuary_id and globals().get("sanctuary_engine"):
                    recon_ctx = globals()["sanctuary_engine"].get_reconsolidation_context(sanctuary_id) or {}
                    recon_text = self._format_recon_context(recon_ctx, max_chars=650)
            except Exception:
                recon_text = ""

            # Pull physiology context if available
            bio_text = ""
            try:
                if sanctuary_id and globals().get("sanctuary_engine"):
                    bio_text = globals()["sanctuary_engine"].format_biometric_context_for_ai(sanctuary_id) or ""
                    bio_text = bio_text[:650]
            except Exception:
                bio_text = ""

            ns_target = target_metrics.get('nevedal_state', {}) if isinstance(target_metrics, dict) else {}

            system_prompt = f"""You are Little Nate, providing GROUP COACHING guidance.

        YOUR TASK: Craft words for {target_name} to say TO their family members that will create connection and a corrective emotional experience.

        YOU ARE NOT giving advice to {target_name}.
        YOU ARE writing the actual words {target_name} should speak to their family.

        TARGET SPEAKER: {target_name} ({target_role})
        - Current Mood: {ns_target.get('mood_current', 'unknown')}
        - Emotional Coherence: {ns_target.get('C_emo', 0.5)}
        - Their History: {target_memory if target_memory else 'New to therapy'}

        FAMILY MEMBERS {target_name} IS SPEAKING TO:
        {others_context}

        RECENT CONVERSATION (what led to this moment):
        {conversation}

        ⚠️ IDENTITY & SPEAKER ATTRIBUTION (CRITICAL):
        - Each conversation line is prefixed with [AUTH:<name>/<id>] which is the authenticated sender.
        - Treat that prefix as the source of truth; do NOT infer who is speaking from the wording of the message.
        - If content appears written from someone else's perspective, do not mirror that confusion—stay anchored to [AUTH:...].

        THERAPEUTIC WISDOM:
        {wisdom_text}

        WORKBOOK GUIDANCE (best-practice excerpts; keep quotes short, do not dump long text):
        {workbook_guidance if workbook_guidance else "None"}

        EFT CONTEXT (attachment needs to meet / deepen):
        {eft_text if eft_text else "None"}

        MEMORY RECONSOLIDATION CONTEXT (active schemas/windows):
        {recon_text if recon_text else "None"}

        PHYSIOLOGICAL AWARENESS:
        {bio_text if bio_text else "None"}

        CORRECTIVE EMOTIONAL EXPERIENCE FRAMEWORK:
        Craft words that:
        1. REPAIR: address specific wounds/disconnections
        2. CONNECT: build bridges between {target_name} and specific members
        3. VALIDATE: acknowledge others while expressing {target_name}'s truth
        4. OPEN: invite continued dialogue (not shutdown)

        CRAFT THE MESSAGE:
        - Use "I" statements from {target_name}'s voice
        - Address by name when helpful
        - Keep it 2-4 sentences
        - Make it something {target_name} could realistically say

        RESPOND IN THIS EXACT FORMAT:
        SUGGESTED_RESPONSE: [the exact words {target_name} should say]
        RATIONALE: [brief why these words could create connection]
        TARGET_AUDIENCE: [who it's addressed to - e.g., "Jane" or "everyone"]
        EMOTIONAL_TONE: [e.g., "vulnerable", "repair", "reaching out"]"""

            try:
                import aiohttp
                response_text = ""

                async with aiohttp.ClientSession() as session:
                    async with session.ws_connect(
                        AZURE_ENDPOINT,
                        headers={"api-key": AZURE_API_KEY, "OpenAI-Beta": "realtime=v1"}
                    ) as azure_ws:
                        await azure_ws.send_str(json.dumps({
                            "type": "session.update",
                            "session": {"modalities": ["text"], "instructions": system_prompt}
                        }))
                        await azure_ws.send_str(json.dumps({
                            "type": "conversation.item.create",
                            "item": {"type": "message", "role": "user",
                                    "content": [{"type": "input_text", "text": f"Generate a suggested response for {target_name}."}]}
                        }))
                        await azure_ws.send_str(json.dumps({"type": "response.create"}))

                        async for msg in azure_ws:
                            if msg.type == aiohttp.WSMsgType.TEXT:
                                data = json.loads(msg.data)
                                if data.get("type") == "response.text.delta":
                                    response_text += data.get("delta", "")
                                elif data.get("type") == "response.done":
                                    break

                result = {
                    "suggested_response": "",
                    "rationale": "",
                    "target_audience": "the family",
                    "emotional_tone": "supportive"
                }

                if "SUGGESTED_RESPONSE:" in response_text:
                    parts = response_text.split("SUGGESTED_RESPONSE:")
                    rest = parts[1] if len(parts) > 1 else ""
                    if "RATIONALE:" in rest:
                        result["suggested_response"] = rest.split("RATIONALE:")[0].strip()
                        rest = rest.split("RATIONALE:")[1]
                    else:
                        result["suggested_response"] = rest.strip()

                    if "TARGET_AUDIENCE:" in rest:
                        result["rationale"] = rest.split("TARGET_AUDIENCE:")[0].strip()
                        rest = rest.split("TARGET_AUDIENCE:")[1]

                    if "EMOTIONAL_TONE:" in rest:
                        result["target_audience"] = rest.split("EMOTIONAL_TONE:")[0].strip()
                        result["emotional_tone"] = rest.split("EMOTIONAL_TONE:")[1].strip()
                else:
                    result["suggested_response"] = response_text.strip()

                print(f">>> [GROUP COACHING] Generated: {result['suggested_response'][:60]}...")

                # Best-effort token usage attribution for group coaching generation.
                try:
                    hoh_id = (sanctuary_data.get("head_of_household_id") if isinstance(sanctuary_data, dict) else None)
                except Exception:
                    hoh_id = None
                tokens_est = 0
                try:
                    tokens_est = int((len((conversation or "").split()) + len((result.get("suggested_response") or "").split())) * 10)
                except Exception:
                    tokens_est = 0
                if hoh_id and tokens_est > 0:
                    try:
                        deduct = os.getenv("SANCTUARY_TOKENS_DEDUCT", "false").lower() == "true"
                        self.billing.add_token_usage(hoh_id, tokens_est, deduct_balance=deduct)
                        self.analytics.record_event("tokens", hoh_id, {
                            "tokens": tokens_est,
                            "source": "group_coaching_suggestion",
                            "sanctuary_id": (sanctuary_data.get("sanctuary_id") if isinstance(sanctuary_data, dict) else None),
                        })
                    except Exception as e:
                        print(f">>> [GROUP COACHING] Token usage record failed: {e}")
                self.analytics.record_event("sanctuary_group_coaching_suggestion_generated", hoh_id or "SANCTUARY", {
                    "sanctuary_id": (sanctuary_data.get("sanctuary_id") if isinstance(sanctuary_data, dict) else None),
                    "family_id": (sanctuary_data.get("family_id") if isinstance(sanctuary_data, dict) else None),
                    "head_of_household_id": hoh_id,
                    "target_member_id": target_member.get("hardware_id"),
                    "target_member_name": target_member.get("name"),
                    "tokens_est": tokens_est,
                })
                return result
            except Exception as e:
                print(f">>> [GROUP COACHING ERROR] {e}")
                return {
                    "suggested_response": "I want to share how I'm feeling, and I hope we can understand each other better.",
                    "rationale": "A simple, open statement to continue dialogue.",
                    "target_audience": "the family",
                    "emotional_tone": "vulnerable"
                }

    async def process_private_coaching(
                self,
                member_profile: dict,
                sanctuary_data: dict,
                coaching_session: dict,
                trigger: str = "coaching_start"
            ) -> dict:
                """
                Process private 1-on-1 coaching session with Little Nate
                
                Triggers:
                - coaching_start: Initial reframe and first question
                - coaching_response: Respond to user's message (up to 5 attempts)
                - coaching_deescalated: User is calm, prepare to return
                - generate_assisted_response: Create $3 assisted response
                """
                print(f">>> [PRIVATE COACHING] Processing: {trigger} for {member_profile.get('name')}")
                
                member_name = member_profile.get("name", "Friend")
                member_id = member_profile.get("hardware_id")
                
                # Get member's history and metrics
                memory = self.mem.recall(member_profile, limit=5)
                metrics = self.metrics.load_metrics(member_profile)
                
                # Get coaching session context
                attempt_number = coaching_session.get("attempt_number", 1)
                coaching_messages = coaching_session.get("messages", [])
                triggering_message = coaching_session.get("triggering_message", "")
                
                # Format private conversation so far
                private_convo = ""
                for msg in coaching_messages[-6:]:
                    role = "You" if msg.get("role") == "assistant" else member_name
                    private_convo += f"{role}: {msg.get('content', '')}\n"
                
                # Get recent sanctuary messages for context (what led to this)
                sanctuary_messages = sanctuary_data.get("messages", [])[-10:]
                sanctuary_convo = ""
                for msg in sanctuary_messages:
                    sanctuary_convo += f"{msg.get('sender_name', 'Unknown')}: {msg.get('content', '')}\n"
                
                # Build trigger-specific prompts
                if trigger == "coaching_start":
                    user_prompt = f"""This is your FIRST message to {member_name} in private coaching.
 
        WHAT HAPPENED (sanctuary conversation that triggered this):
        {sanctuary_convo}

        {member_name}'s triggering message: "{triggering_message}"

        YOUR TASK:
        1. Acknowledge their strong feelings with warmth
        2. Provide an initial REFRAME - help them see what might be underneath their anger
        3. Ask your FIRST curiosity question to understand what triggered this reaction

        Keep it conversational and warm. 2-3 short paragraphs max."""

                elif trigger == "coaching_response":
                    user_prompt = f"""Continue your private coaching with {member_name}.

        ATTEMPT: {attempt_number} of 5

        PRIVATE CONVERSATION SO FAR:
        {private_convo}

        {member_name}'s latest message: "{coaching_messages[-1].get('content', '') if coaching_messages else ''}"

        YOUR TASK (based on attempt number):
        - Attempt 1-2: Ask curiosity questions - what happened? what did it mean to them?
        - Attempt 3: Validate their feelings, ask what they need the other person to understand
        - Attempt 4: Offer a de-escalation technique (breathing, grounding, reframe)
        - Attempt 5: Check if they're ready to return, or offer assisted response

        ASSESS their emotional state:
        - If they seem calmer, acknowledge progress and ask if ready to return
        - If still escalated, continue with compassionate questions
        - If stuck after 5 attempts, gently offer the assisted response option

        Keep responses warm and brief (2-3 sentences per thought)."""

                elif trigger == "coaching_deescalated":
                    user_prompt = f"""Great news - {member_name} seems calmer now.

        PRIVATE CONVERSATION:
        {private_convo}

        YOUR TASK:
        1. Acknowledge their progress warmly
        2. Ask if they're ready to return to the Family Sanctuary
        3. Offer to help them craft an opening message if they'd like

        Be encouraging but not pushy. They can take their time."""

                elif trigger == "generate_assisted_response":
                    # Get other family members' context (without revealing private details)
                    other_members = [m for m in sanctuary_data.get("members", []) if m.get("user_id") != member_id]
                    other_context = ""
                    for other in other_members:
                        other_context += f"- {other.get('name', 'Family member')}: Participant in sanctuary\n"
                    
                    user_prompt = f"""Generate an ASSISTED RESPONSE for {member_name} to send to the Family Sanctuary.

        WHAT {member_name.upper()} SHARED IN PRIVATE (CONFIDENTIAL - use themes only):
        {private_convo}

        OTHER FAMILY MEMBERS:
        {other_context}

        SANCTUARY CONTEXT:
        {sanctuary_convo}

        YOUR TASK:
        Create a response that {member_name} can send to the sanctuary that:
        1. Expresses their TRUE feelings (from private coaching) in a way others can hear
        2. Uses "I feel" statements instead of "You did"
        3. Shares their underlying need without attacking
        4. Opens door for connection

        CRITICAL: Do NOT reveal specific details from private coaching. Use themes and feelings only.

        Format your response as:
        SUGGESTED_RESPONSE: [the message they can send]
        EXPLANATION: [brief note about why this approach helps]"""

                else:
                    user_prompt = f"Continue supporting {member_name} in their private coaching session."

                # Build system prompt
                system_prompt = f"""You are Little Nate, providing PRIVATE 1-on-1 coaching to {member_name}.

        THIS IS CONFIDENTIAL - nothing shared here goes back to other family members.

        ABOUT {member_name.upper()}:
        - Current mood: {metrics.get('current_mood', 'distressed')}
        - Risk level: {metrics.get('risk_level', 'LOW')}
        - History context: {memory[:300] if memory else 'New user'}

        YOUR APPROACH:
        1. CURIOSITY over judgment - ask "what happened?" not "why did you do that?"
        2. COMPASSION - validate their feelings even if their behavior was problematic
        3. REFRAME - help them see the other person's perspective gently
        4. DE-ESCALATE - breathing, grounding, or perspective shifts
        5. EMPOWER - help them find their own words, don't lecture

        CONFIDENTIALITY RULES:
        - What they share here stays here
        - If generating assisted response, use THEMES not specific details
        - Never quote their private words to other family members

        Keep responses warm, brief, and conversational. You're a supportive friend, not a lecturer."""

                try:
                    import aiohttp
                    response_text = ""

                    async with aiohttp.ClientSession() as session:
                        async with session.ws_connect(
                            AZURE_ENDPOINT,
                            headers={"api-key": AZURE_API_KEY, "OpenAI-Beta": "realtime=v1"}
                        ) as azure_ws:
                            await azure_ws.send_str(json.dumps({
                                "type": "session.update",
                                "session": {"modalities": ["text"], "instructions": system_prompt}
                            }))
                            await azure_ws.send_str(json.dumps({
                                "type": "conversation.item.create",
                                "item": {"type": "message", "role": "user",
                                        "content": [{"type": "input_text", "text": user_prompt}]}
                            }))
                            await azure_ws.send_str(json.dumps({"type": "response.create"}))

                            async for msg in azure_ws:
                                if msg.type == aiohttp.WSMsgType.TEXT:
                                    data = json.loads(msg.data)
                                    if data.get("type") == "response.text.delta":
                                        response_text += data.get("delta", "")
                                    elif data.get("type") in ["response.done", "error"]:
                                        break

                    # Determine if user seems de-escalated (simple heuristic)
                    is_deescalated = False
                    if coaching_messages:
                        last_user_msg = coaching_messages[-1].get("content", "").lower() if coaching_messages[-1].get("role") == "user" else ""
                        calm_indicators = ["okay", "i understand", "you're right", "thank you", "i see", "that helps", "i feel better", "ready"]
                        is_deescalated = any(indicator in last_user_msg for indicator in calm_indicators)

                    # Check if we should offer assisted response
                    should_offer_assisted = attempt_number >= 5 and not is_deescalated

                    # Best-effort token usage attribution for private coaching AI.
                    hoh_id = None
                    try:
                        if isinstance(sanctuary_data, dict):
                            hoh_id = sanctuary_data.get("head_of_household_id") or sanctuary_data.get("created_by")
                    except Exception:
                        hoh_id = None
                    tokens_est = 0
                    try:
                        tokens_est = int((len((user_prompt or "").split()) + len((response_text or "").split())) * 10)
                    except Exception:
                        tokens_est = 0
                    if hoh_id and tokens_est > 0:
                        try:
                            deduct = os.getenv("SANCTUARY_TOKENS_DEDUCT", "false").lower() == "true"
                            self.billing.add_token_usage(hoh_id, tokens_est, deduct_balance=deduct)
                            self.analytics.record_event("tokens", hoh_id, {
                                "tokens": tokens_est,
                                "source": "private_coaching",
                                "sanctuary_id": sanctuary_data.get("sanctuary_id") if isinstance(sanctuary_data, dict) else None,
                                "trigger": trigger,
                            })
                        except Exception as e:
                            print(f">>> [PRIVATE COACHING] Token usage record failed: {e}")

                    self.analytics.record_event("private_coaching_response", member_id, {
                        "trigger": trigger,
                        "attempt": attempt_number,
                        "is_deescalated": is_deescalated,
                        "sanctuary_id": sanctuary_data.get("sanctuary_id") if isinstance(sanctuary_data, dict) else None,
                        "head_of_household_id": hoh_id,
                        "tokens_est": tokens_est,
                    })

                    return {
                        "success": True,
                        "response": response_text,
                        "attempt_number": attempt_number,
                        "is_deescalated": is_deescalated,
                        "should_offer_assisted": should_offer_assisted
                    }

                except Exception as e:
                    print(f">>> [PRIVATE COACHING ERROR] {e}")
                    return {
                        "success": False,
                        "response": f"I'm here with you, {member_name}. Let's take a breath together. What's on your mind?",
                        "attempt_number": attempt_number,
                        "is_deescalated": False,
                        "should_offer_assisted": False
                    }


    async def _send(self, uid: str, text: str):
        """Send message to all connected sockets for user"""
        if uid in self.sockets:
            for ws in list(self.sockets[uid]):
                try:
                    await ws.send(json.dumps({"type": "nate_response", "text": text}))
                except:
                    self.sockets[uid].discard(ws)

    async def _send_metrics_update(self, uid: str, profile: dict):
        """Send real-time metrics update to client"""
        if uid in self.sockets:
            # Get fresh metrics
            metrics = self.metrics.load_metrics(profile)
            ns = metrics.get("nevedal_state", {})
            
            # Get token balance from registry
            registry = load_registry()
            token_balance = 0
            token_usage = 0
            for k, v in registry.items():
                if v.get("profile", {}).get("hardware_id") == uid:
                    token_balance = v.get("profile", {}).get("token_balance", 0)
                    token_usage = v.get("profile", {}).get("token_usage_month", 0)
                    break
            
            update = {
                "type": "metrics_update",
                "metrics": {
                    "C_emo": ns.get("C_emo", 0.5),
                    "GAP": ns.get("GAP", 0.3),
                    "Quantum": ns.get("Quantum", 0.5),
                    "anxiety_level": ns.get("anxiety_level", 0),
                    "stress_level": ns.get("stress_level", 0),
                    "engagement": ns.get("engagement", 0.5),
                    "risk_level": ns.get("risk_level", "LOW"),
                    "mood_current": ns.get("mood_current", "neutral"),
                    "session_count": ns.get("session_count", 0),
                    "breakthrough_count": ns.get("breakthrough_count", 0),
                },
                "mood_history": ns.get("mood_history", [])[-30:],
                "token_balance": token_balance,
                "token_usage": token_usage
            }
            
            for ws in list(self.sockets[uid]):
                try:
                    await ws.send(json.dumps(update))
                except:
                    self.sockets[uid].discard(ws)

    
# ------------------------------------------------------------------------------
# PART 11: WEBSOCKET SERVER
# ------------------------------------------------------------------------------

# Initialize all systems
hippocampus = MemorySystem(VAULT_ROOT)
parietal = MetricsEngine(VAULT_ROOT)
night_school = NightSchool(VAULT_ROOT)
session_tracker = SessionTracker(DATA_DIR)
billing_system_internal = BillingSystem(DATA_DIR)
analytics_engine = AnalyticsEngine(DATA_DIR)

night_school_curriculum = NightSchoolCurriculum(VAULT_ROOT) if NightSchoolCurriculum else None
night_school_handler = NightSchoolHandler(VAULT_ROOT) if NightSchoolHandler else None

cortex = AzureCortex(
    hippocampus,
    parietal,
    night_school,
    session_tracker,
    billing_system_internal,
    analytics_engine,
    workbook_library=workbook_library,
)

# Family Sanctuary Engine (with all integrations)
sanctuary_engine = FamilySanctuaryEngine(
    data_dir=DATA_DIR,
    azure_cortex=cortex,
    nevedal_handler=nevedal_handler,
    billing_system=billing_system,
    analytics_engine=analytics_engine
)

async def handle_client(websocket, path=None):
    """Handle WebSocket connections"""
    uid = "GUEST"
    current_profile = None
    current_hardware_id = None
    current_username = None
    
    try:
        await websocket.send(json.dumps({"type": "connected", "status": "ready"}))
        async for message in websocket:
            print(f">>> RECEIVED: {message[:200]}")
            try:
                d = json.loads(message)
                t = d.get("type")
            except Exception as e:
                await websocket.send(json.dumps({"type": "error", "message": f"BAD_JSON: {e}"}))
                continue
            
            # === AUTHENTICATION ===
            if t == "login_request":
                tok, res = authenticate_user(d["username"], d["password"], d.get("expected_role"))
                if tok:
                    uid = res.get("hardware_id")
                    current_profile = res
                    current_username = d.get("username")
                    cortex.register(uid, websocket)
                    analytics_engine.record_event("login", uid)
                    notification_system.register_connection(uid, websocket)
                    await websocket.send(json.dumps({"type": "login_success", "token": tok, "profile": res}))
                    # Push current metrics immediately on login (real-time dashboards)
                    try:
                        await cortex._send_metrics_update(uid, current_profile)
                    except Exception as e:
                        print(f">>> [METRICS PUSH ERROR] {e}")
                    # Also send a snapshot payload with mood_history so UIs hydrate reliably
                    # even if they miss the async metrics_update broadcast.
                    try:
                        summary = parietal.get_metrics_summary(current_profile)
                        full_metrics = parietal.load_metrics(current_profile) or {}
                        ns = full_metrics.get("nevedal_state", {}) if isinstance(full_metrics, dict) else {}
                        mh = ns.get("mood_history", []) if isinstance(ns, dict) else []
                        mh = mh[-30:] if isinstance(mh, list) else []
                        await websocket.send(json.dumps({"type": "metrics_data", "metrics": summary, "mood_history": mh}))
                    except Exception as e:
                        print(f">>> [METRICS SNAPSHOT ERROR] {e}")
                else:
                    await websocket.send(json.dumps({"type": "login_failed", "message": res}))
            # === TOKEN AUTH (reconnect with existing session) ===
            elif t == "auth":
                hw_id = d.get("hardware_id")
                token = d.get("token")
                if hw_id and token:
                    users = load_json_file(DATA_DIR / "user_registry.json", {})
                    print(f">>> DEBUG: Loaded {len(users)} users, looking for hw_id: {hw_id}")
                    # Find user by hardware_id (not by key)
                    found_profile = None
                    for username, user_data in users.items():
                        profile = user_data.get("profile", {})
                        if profile.get("hardware_id") == hw_id:
                            found_profile = profile
                            break   
                    
                    if found_profile:
                        current_profile = found_profile
                        uid = hw_id
                        current_hardware_id = hw_id
                        cortex.register(uid, websocket)
                        notification_system.register_connection(uid, websocket)
                        print(f">>> Auth success: {hw_id} as {current_profile.get('role')}")
                        await websocket.send(json.dumps({"type": "auth_success", "profile": current_profile}))
                        # Push current metrics immediately on reconnect
                        try:
                            await cortex._send_metrics_update(uid, current_profile)
                        except Exception as e:
                            print(f">>> [METRICS PUSH ERROR] {e}")
                        # Snapshot metrics (with mood_history) for reliable hydration
                        try:
                            summary = parietal.get_metrics_summary(current_profile)
                            full_metrics = parietal.load_metrics(current_profile) or {}
                            ns = full_metrics.get("nevedal_state", {}) if isinstance(full_metrics, dict) else {}
                            mh = ns.get("mood_history", []) if isinstance(ns, dict) else []
                            mh = mh[-30:] if isinstance(mh, list) else []
                            await websocket.send(json.dumps({"type": "metrics_data", "metrics": summary, "mood_history": mh}))
                        except Exception as e:
                            print(f">>> [METRICS SNAPSHOT ERROR] {e}")
                    else:
                        print(f">>> Auth failed: user {hw_id} not found")
                        await websocket.send(json.dumps({"type": "auth_failed", "message": "User not found"}))
                else:
                    await websocket.send(json.dumps({"type": "auth_failed", "message": "Missing credentials"}))
            # === REGISTRATION ===
            elif t == "register_request":
                succ, res = register_new_user(d)
                if succ:
                    analytics_engine.record_event("registration")
                    tok, prof = authenticate_user(d["username"], d["password"])
                    if tok:
                        uid = prof.get("hardware_id")
                        current_profile = prof
                        cortex.register(uid, websocket)
                        notification_system.register_connection(uid, websocket)
                        analytics_engine.record_event("login", uid)
                        await websocket.send(json.dumps({"type": "login_success", "token": tok, "profile": prof}))
                        # Push current metrics immediately after registration+login
                        try:
                            await cortex._send_metrics_update(uid, current_profile)
                        except Exception as e:
                            print(f">>> [METRICS PUSH ERROR] {e}")
                    else:
                        await websocket.send(json.dumps({"type": "registration_success", "message": "Please log in"}))
                else:
                    await websocket.send(json.dumps({"type": "registration_failed", "message": res}))
            
            # === CHAT MESSAGE ===
            elif t == "chat_message":
                if current_profile:
                    await cortex.process_interaction(current_profile, d.get("text", ""))
                else:
                    await websocket.send(json.dumps({"type": "error", "message": "Not authenticated"}))
            
            # === NATE QUERY (Mobile App) ===
            elif t == "nate_query":
                if current_profile:
                    text = d.get("nate_query", d.get("text", ""))
                    await cortex.process_interaction(current_profile, text)
                else:
                    await websocket.send(json.dumps({"type": "error", "message": "Not authenticated"}))
            
            # === GET METRICS ===
            elif t == "get_metrics":
                if current_profile:
                    summary = parietal.get_metrics_summary(current_profile)
                    # Include mood_history for chart UIs (some clients rely on metrics_data snapshot)
                    try:
                        full_metrics = parietal.load_metrics(current_profile) or {}
                        ns = full_metrics.get("nevedal_state", {}) if isinstance(full_metrics, dict) else {}
                        mh = ns.get("mood_history", []) if isinstance(ns, dict) else []
                        mh = mh[-30:] if isinstance(mh, list) else []
                    except Exception:
                        mh = []
                    await websocket.send(json.dumps({"type": "metrics_data", "metrics": summary, "mood_history": mh}))
                    # Also send raw numeric metrics + mood history for real-time UIs
                    try:
                        await cortex._send_metrics_update(uid, current_profile)
                    except Exception as e:
                        print(f">>> [METRICS PUSH ERROR] {e}")
            
            # === GET MEMORY/HISTORY ===
            elif t == "get_history":
                if current_profile:
                    memories = hippocampus.recall_full(current_profile, limit=d.get("limit", 20))
                    await websocket.send(json.dumps({"type": "history_data", "history": memories}))
            
            # === GET SESSIONS ===
            elif t == "get_sessions":
                if current_profile:
                    sessions = session_tracker.get_client_sessions(uid, limit=d.get("limit", 10))
                    await websocket.send(json.dumps({"type": "sessions_data", "sessions": sessions}))
            
            # === GET BILLING INFO ===
            elif t == "get_billing":
                if current_profile:
                    usage = billing_system_internal.get_usage_stats(uid)
                    subscription = billing_system_internal.get_subscription(uid)
                    await websocket.send(json.dumps({
                        "type": "billing_data", 
                        "usage": usage, 
                        "subscription": subscription
                    }))
            
            # === ADMIN: GET DASHBOARD STATS ===
            elif t == "admin_get_stats":
                if current_profile and current_profile.get("role") == "ADMIN":
                    stats = analytics_engine.get_dashboard_stats()
                    watchlist = analytics_engine.get_crisis_watchlist()
                    await websocket.send(json.dumps({
                        "type": "admin_stats",
                        "stats": stats,
                        "crisis_watchlist": watchlist
                    }))
            
            # === ADMIN: GET ALL USERS ===
            elif t == "admin_get_users":
                if current_profile and current_profile.get("role") == "ADMIN":
                    registry = load_registry()
                    users = []
                    for k, v in registry.items():
                        p = v.get("profile", {})
                        users.append({
                            "id": p.get("hardware_id"),
                            "name": p.get("name"),
                            "email": p.get("email"),
                            "role": p.get("role"),
                            "tier": p.get("tier"),
                            "subscription_status": p.get("subscription_status"),
                            "joined_date": p.get("joined_date"),
                            "last_login": p.get("last_login")
                        })
                    await websocket.send(json.dumps({"type": "admin_users", "users": users}))
            
            # === ADMIN: APPROVE COACH ===
            elif t == "admin_approve_coach":
                if current_profile and current_profile.get("role") == "ADMIN":
                    coach_id = d.get("coach_id")
                    registry = load_registry()
                    found = False
                    for k, v in registry.items():
                        if v.get("profile", {}).get("hardware_id") == coach_id:
                            v["profile"]["subscription_status"] = "ACTIVE"
                            v["profile"]["certification_status"] = "APPROVED"
                            save_registry(registry)
                            await websocket.send(json.dumps({
                                "type": "coach_approved", 
                                "coach_id": coach_id,
                                "message": "Coach approved successfully"
                            }))
                            found = True
                            break
                    if not found:
                        await websocket.send(json.dumps({"type": "error", "message": "Coach not found"}))
            
            # === ADMIN: ASSIGN COACH TO CLIENT ===
            elif t == "admin_assign_coach":
                if current_profile and current_profile.get("role") == "ADMIN":
                    client_id = d.get("client_id")
                    coach_id = d.get("coach_id")
                    registry = load_registry()
                    found = False
                    for k, v in registry.items():
                        if v.get("profile", {}).get("hardware_id") == client_id:
                            v["profile"]["assigned_coach_id"] = coach_id
                            save_registry(registry)
                            await websocket.send(json.dumps({
                                "type": "coach_assigned", 
                                "client_id": client_id, 
                                "coach_id": coach_id,
                                "message": "Coach assigned successfully"
                            }))
                            found = True
                            break
                    if not found:
                        await websocket.send(json.dumps({"type": "error", "message": "Client not found"}))
            
            # === ADMIN: REMOVE COACH ASSIGNMENT ===
            elif t == "admin_remove_coach":
                if current_profile and current_profile.get("role") == "ADMIN":
                    client_id = d.get("client_id")
                    registry = load_registry()
                    for k, v in registry.items():
                        if v.get("profile", {}).get("hardware_id") == client_id:
                            v["profile"]["assigned_coach_id"] = ""
                            save_registry(registry)
                            await websocket.send(json.dumps({
                                "type": "coach_removed", 
                                "client_id": client_id
                            }))
                            break
            
            # === ADMIN: SUSPEND USER ===
            elif t == "admin_suspend_user":
                if current_profile and current_profile.get("role") == "ADMIN":
                    user_id = d.get("user_id")
                    reason = d.get("reason", "")
                    registry = load_registry()
                    for k, v in registry.items():
                        if v.get("profile", {}).get("hardware_id") == user_id:
                            v["profile"]["subscription_status"] = "SUSPENDED"
                            v["profile"]["suspension_reason"] = reason
                            v["profile"]["suspended_at"] = str(datetime.datetime.now())
                            save_registry(registry)
                            await websocket.send(json.dumps({
                                "type": "user_suspended", 
                                "user_id": user_id
                            }))
                            break
            
            # === ADMIN: REACTIVATE USER ===
            elif t == "admin_reactivate_user":
                if current_profile and current_profile.get("role") == "ADMIN":
                    user_id = d.get("user_id")
                    registry = load_registry()
                    for k, v in registry.items():
                        if v.get("profile", {}).get("hardware_id") == user_id:
                            v["profile"]["subscription_status"] = "ACTIVE"
                            v["profile"]["suspension_reason"] = ""
                            save_registry(registry)
                            await websocket.send(json.dumps({
                                "type": "user_reactivated", 
                                "user_id": user_id
                            }))
                            break
            
            # === ADMIN: GET CRISIS LOG ===
            elif t == "admin_get_crisis_log":
                if current_profile and current_profile.get("role") == "ADMIN":
                    crisis_log = load_json_file(CRISIS_LOG_FILE, [])
                    await websocket.send(json.dumps({
                        "type": "crisis_log_data",
                        "entries": crisis_log[-100:]
                    }))
            
            # === ADMIN: RESOLVE CRISIS ===
            elif t == "admin_resolve_crisis":
                if current_profile and current_profile.get("role") == "ADMIN":
                    crisis_id = d.get("crisis_id")
                    resolution_notes = d.get("notes", "")
                    crisis_log = load_json_file(CRISIS_LOG_FILE, [])
                    for entry in crisis_log:
                        if entry.get("timestamp") == crisis_id or entry.get("user_id") == crisis_id:
                            entry["resolved"] = True
                            entry["resolved_by"] = current_profile.get("name")
                            entry["resolution_notes"] = resolution_notes
                            entry["resolved_at"] = str(datetime.datetime.now())
                            save_json_file(CRISIS_LOG_FILE, crisis_log)
                            await websocket.send(json.dumps({
                                "type": "crisis_resolved",
                                "message": "Crisis marked as resolved"
                            }))
                            break
            
            # === COACH: GET ASSIGNED CLIENTS ===
            elif t == "coach_get_clients":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    registry = load_registry()
                    clients = []
                    coach_id = current_profile.get("hardware_id")
                    coach_username = current_username or ""
                    is_admin = current_profile.get("role") == "ADMIN"

                    # Best-practice fallback: if assignments are missing on client profiles, infer
                    # clients from this coach's scheduled sessions (backend data source-of-truth).
                    session_client_ids = set()
                    session_client_meta = {}
                    if not is_admin:
                        try:
                            sessions_src = load_json_file(BACKEND_DATA_DIR / "sessions.json", []) or []
                            if not isinstance(sessions_src, list):
                                sessions_src = []
                            for s in sessions_src:
                                if not isinstance(s, dict):
                                    continue
                                if (s.get("coach_id") or "") != coach_id:
                                    continue
                                cid = (s.get("client_id") or "").strip()
                                if cid:
                                    session_client_ids.add(cid)
                                    # Capture best-effort display metadata from schedule store
                                    if cid not in session_client_meta:
                                        session_client_meta[cid] = {
                                            "client_name": (s.get("client_name") or s.get("client") or "").strip(),
                                            "family_id": (s.get("family_id") or "").strip(),
                                        }
                        except Exception:
                            session_client_ids = set()
                            session_client_meta = {}

                    # Index registry clients by hardware_id for fast lookup.
                    registry_clients_by_id = {}
                    try:
                        for _, v in (registry or {}).items():
                            p = (v.get("profile") or {})
                            if p.get("role") == "CLIENT":
                                hid = (p.get("hardware_id") or "").strip()
                                if hid:
                                    registry_clients_by_id[hid] = p
                    except Exception:
                        registry_clients_by_id = {}
                    
                    for k, v in registry.items():
                        p = v.get("profile", {})
                        if p.get("role") != "CLIENT":
                            continue

                        # Assignment rules:
                        # - For COACH: allow if client profile points to this coach (username or hardware id)
                        # - For ADMIN: return all clients (optionally filterable later)
                        assigned_ok = is_admin
                        if not is_admin:
                            assigned_ok = (
                                (p.get("assigned_coach_id") and p.get("assigned_coach_id") == coach_id)
                                or (p.get("assigned_coach") and coach_username and p.get("assigned_coach") == coach_username)
                                or (p.get("hardware_id") in session_client_ids)
                            )
                        if not assigned_ok:
                            continue

                        # Metrics (summary + raw highlights)
                        try:
                            m = parietal.load_metrics(p)
                            ns = (m.get("nevedal_state") or {})
                        except Exception:
                            ns = {}

                        summary = parietal.get_metrics_summary(p)
                        metrics_payload = {
                            "coherence": summary.get("coherence", f"{float(ns.get('C_emo', 0.5)) * 100:.0f}%"),
                            "growth": summary.get("growth_potential", f"{float(ns.get('GAP', 0.3)) * 100:.0f}%"),
                            "growth_potential": summary.get("growth_potential", f"{float(ns.get('GAP', 0.3)) * 100:.0f}%"),
                            "wellness": summary.get("wellness_score", f"{float(ns.get('Quantum', 0.5)) * 100:.0f}%"),
                            "wellness_score": summary.get("wellness_score", f"{float(ns.get('Quantum', 0.5)) * 100:.0f}%"),
                            "risk_level": ns.get("risk_level", "LOW"),
                            "mood_current": ns.get("mood_current", "neutral"),
                            "mood_trend": ns.get("mood_trend", "stable"),
                            # Provide numeric keys too so UIs can render consistently
                            "C_emo": ns.get("C_emo"),
                            "GAP": ns.get("GAP"),
                            "Quantum": ns.get("Quantum"),
                            "engagement": ns.get("engagement"),
                            "anxiety_level": ns.get("anxiety_level"),
                            "stress_level": ns.get("stress_level"),
                        }

                        clients.append({
                            "id": p.get("hardware_id"),
                            "name": p.get("name"),
                            "tier": p.get("subscription_plan") or p.get("tier") or "STANDARD",
                            "last_login": p.get("last_login"),
                            "assigned_coach": p.get("assigned_coach") or "",
                            "family_id": p.get("family_id") or "",
                            "metrics": metrics_payload,
                            "nevedal_state": {
                                "C_emo": ns.get("C_emo"),
                                "GAP": ns.get("GAP"),
                                "Quantum": ns.get("Quantum"),
                                "risk_level": ns.get("risk_level"),
                            },
                            "total_sessions": int(ns.get("session_count") or 0),
                        })

                    # Ensure any scheduled-session clients show up even if registry is missing/mismatched.
                    if not is_admin and session_client_ids:
                        try:
                            seen = {((c or {}).get("id") or "").strip() for c in (clients or []) if isinstance(c, dict)}
                            for cid in sorted(session_client_ids):
                                if not cid or cid in seen:
                                    continue
                                p = registry_clients_by_id.get(cid) or {}
                                meta = session_client_meta.get(cid) or {}
                                name = (p.get("name") or meta.get("client_name") or cid).strip()
                                fam = (p.get("family_id") or meta.get("family_id") or "").strip()
                                # Metrics (best-effort)
                                try:
                                    m = parietal.load_metrics(p) if p else {}
                                    ns = (m.get("nevedal_state") or {}) if isinstance(m, dict) else {}
                                except Exception:
                                    ns = {}
                                summary = parietal.get_metrics_summary(p) if p else {}
                                metrics_payload = {
                                    "coherence": summary.get("coherence", f"{float(ns.get('C_emo', 0.5)) * 100:.0f}%"),
                                    "growth": summary.get("growth_potential", f"{float(ns.get('GAP', 0.3)) * 100:.0f}%"),
                                    "growth_potential": summary.get("growth_potential", f"{float(ns.get('GAP', 0.3)) * 100:.0f}%"),
                                    "wellness": summary.get("wellness_score", f"{float(ns.get('Quantum', 0.5)) * 100:.0f}%"),
                                    "wellness_score": summary.get("wellness_score", f"{float(ns.get('Quantum', 0.5)) * 100:.0f}%"),
                                    "risk_level": ns.get("risk_level", "LOW"),
                                    "mood_current": ns.get("mood_current", "neutral"),
                                    "mood_trend": ns.get("mood_trend", "stable"),
                                    "C_emo": ns.get("C_emo"),
                                    "GAP": ns.get("GAP"),
                                    "Quantum": ns.get("Quantum"),
                                    "engagement": ns.get("engagement"),
                                    "anxiety_level": ns.get("anxiety_level"),
                                    "stress_level": ns.get("stress_level"),
                                }
                                clients.append({
                                    "id": cid,
                                    "name": name,
                                    "tier": p.get("subscription_plan") or p.get("tier") or "STANDARD",
                                    "last_login": p.get("last_login") or "",
                                    "assigned_coach": p.get("assigned_coach") or coach_username,
                                    "family_id": fam,
                                    "metrics": metrics_payload,
                                    "nevedal_state": {
                                        "C_emo": ns.get("C_emo"),
                                        "GAP": ns.get("GAP"),
                                        "Quantum": ns.get("Quantum"),
                                        "risk_level": ns.get("risk_level"),
                                    },
                                    "total_sessions": int(ns.get("session_count") or 0),
                                })
                        except Exception:
                            pass
                    
                    await websocket.send(json.dumps({"type": "coach_clients", "clients": clients}))
            
            # === COACH: GET PRE-SESSION BRIEF ===
            elif t == "get_presession_brief":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    client_id = d.get("client_id")
                    registry = load_registry()
                    client_profile = None
                    for k, v in registry.items():
                        if v.get("profile", {}).get("hardware_id") == client_id:
                            client_profile = v["profile"]
                            break
                    
                    if client_profile:
                        metrics = parietal.load_metrics(client_profile)
                        topics = hippocampus.get_topics_discussed(client_profile)
                        breakthroughs = hippocampus.get_breakthroughs(client_profile)
                        recent_memory = hippocampus.recall_full(client_profile, limit=10)
                        
                        brief = {
                            "client": {
                                "name": client_profile.get("name"),
                                "tier": client_profile.get("tier"),
                                "joined_date": client_profile.get("joined_date"),
                                "total_sessions": client_profile.get("total_sessions_count", 0)
                            },
                            "metrics": metrics.get("nevedal_state", {}),
                            "recent_topics": topics,
                            "recent_breakthroughs": breakthroughs[-5:],
                            "mood_history": metrics.get("nevedal_state", {}).get("mood_history", []),
                            "recent_conversations": recent_memory[-5:],
                            "family_id": client_profile.get("family_id")
                        }
                        
                        await websocket.send(json.dumps({"type": "presession_brief", "brief": brief}))

            # === COACH: SESSION NOTES (CRUD-lite) ===
            elif t in ("coach_get_session_notes", "coach_add_session_note", "upload_session_note"):
                """
                Coach session notes are stored in a single JSON file keyed by folder.

                Keys:
                  - family:<family_id> for family folders
                  - client:<client_id> for individual/client folders
                """
                if not current_profile or current_profile.get("role") not in ("COACH", "ADMIN"):
                    await websocket.send(json.dumps({"type": "error", "message": "COACH_ONLY"}))
                    continue

                def _folder_key(family_id: str, client_id: str) -> str:
                    fid = (family_id or "").strip()
                    cid = (client_id or "").strip()
                    if fid:
                        return f"family:{fid}"
                    if cid:
                        return f"client:{cid}"
                    return "unknown"

                # Load store
                store = load_json_file(COACH_SESSION_NOTES_FILE, {}) or {}
                if not isinstance(store, dict):
                    store = {}

                if t == "coach_get_session_notes":
                    client_id = d.get("client_id") or ""
                    family_id = d.get("family_id") or ""
                    folder = d.get("folder_id") or ""
                    key = (folder.strip() or _folder_key(family_id, client_id))
                    notes = store.get(key, []) or []
                    await websocket.send(json.dumps({
                        "type": "coach_session_notes",
                        "folder_id": key,
                        "notes": notes[-200:],  # cap
                    }))

                else:
                    # Add note (also supports legacy upload_session_note)
                    note_text = (d.get("note_text") or d.get("text") or "").strip()
                    if not note_text:
                        await websocket.send(json.dumps({"type": "error", "message": "Missing note_text"}))
                        continue

                    client_id = d.get("client_id") or ""
                    family_id = d.get("family_id") or ""
                    folder = d.get("folder_id") or ""
                    key = (folder.strip() or _folder_key(family_id, client_id))

                    entry = {
                        "id": f"NOTE_{uuid.uuid4().hex[:10]}",
                        "created_at": datetime.datetime.now().isoformat(),
                        "coach_username": current_username or current_profile.get("name") or "",
                        "coach_id": current_profile.get("hardware_id") or "",
                        "client_id": client_id,
                        "family_id": family_id,
                        "note_text": note_text[:8000],
                        "share_with_nate": bool(d.get("share_with_nate", False)),
                    }

                    store.setdefault(key, [])
                    if not isinstance(store[key], list):
                        store[key] = []
                    store[key].append(entry)
                    # Keep last N per folder
                    store[key] = store[key][-400:]

                    save_json_file(COACH_SESSION_NOTES_FILE, store)

                    # Optional: enqueue learning for admin approval (or auto-approve if explicitly enabled)
                    try:
                        if entry.get("share_with_nate"):
                            queue = load_json_file(COACH_LEARNING_QUEUE_FILE, []) or []
                            if not isinstance(queue, list):
                                queue = []
                            q_item = {
                                "id": f"QL_{uuid.uuid4().hex[:10]}",
                                "created_at": datetime.datetime.now().isoformat(),
                                "status": "APPROVED" if (AUTO_APPROVE_COACH_LEARNING or current_profile.get("role") == "ADMIN") else "PENDING",
                                "source": f"COACH_{entry.get('coach_username') or entry.get('coach_id')}",
                                "category": "coach_session_note",
                                "folder_id": key,
                                "client_id": client_id,
                                "family_id": family_id,
                                "content": entry.get("note_text", "")[:4000],
                                "raw_note_id": entry.get("id"),
                            }
                            queue.append(q_item)
                            queue = compact_coach_learning_queue(queue)
                            save_json_file(COACH_LEARNING_QUEUE_FILE, queue)

                            if q_item["status"] == "APPROVED":
                                try:
                                    night_school.add_learning(
                                        content=q_item["content"],
                                        source=q_item["source"],
                                        filename=f"{q_item['id']}.txt",
                                        category=q_item["category"],
                                    )
                                except Exception:
                                    pass
                    except Exception:
                        pass

                    await websocket.send(json.dumps({
                        "type": "coach_session_note_saved",
                        "folder_id": key,
                        "note": entry,
                    }))
                    await websocket.send(json.dumps({
                        "type": "coach_session_notes",
                        "folder_id": key,
                        "notes": store.get(key, [])[-200:],
                    }))

            # === COACH: LIVE SESSION (notes stream + observation feed) ===
            elif t in ("coach_start_live_session", "coach_live_note", "coach_end_live_session"):
                if not current_profile or current_profile.get("role") not in ("COACH", "ADMIN"):
                    await websocket.send(json.dumps({"type": "error", "message": "COACH_ONLY"}))
                    continue

                live_store = load_json_file(COACH_LIVE_SESSIONS_FILE, {}) or {}
                if not isinstance(live_store, dict):
                    live_store = {}

                if t == "coach_start_live_session":
                    client_id = (d.get("client_id") or "").strip()
                    family_id = (d.get("family_id") or "").strip()
                    session_label = (d.get("label") or "").strip()
                    meeting_url = (d.get("meeting_url") or "").strip()
                    zoom_meeting_id = (d.get("zoom_meeting_id") or "").strip()
                    assist_enabled = bool(d.get("assist_enabled", True))
                    schedule_session_id = (d.get("schedule_session_id") or d.get("session_id") or "").strip()
                    scheduled_minutes = d.get("scheduled_duration_minutes")
                    try:
                        scheduled_minutes = int(scheduled_minutes) if scheduled_minutes is not None else None
                    except Exception:
                        scheduled_minutes = None
                    live_id = f"LS_{uuid.uuid4().hex[:10]}"

                    live_store[live_id] = {
                        "id": live_id,
                        "created_at": datetime.datetime.now().isoformat(),
                        "started_at": datetime.datetime.now().isoformat(),
                        "ended_at": "",
                        "status": "ACTIVE",
                        "coach_username": current_username or current_profile.get("name") or "",
                        "coach_id": current_profile.get("hardware_id") or "",
                        "client_id": client_id,
                        "family_id": family_id,
                        "schedule_session_id": schedule_session_id,
                        "scheduled_duration_minutes": scheduled_minutes,
                        "label": session_label,
                        "meeting_url": meeting_url,
                        "zoom_meeting_id": zoom_meeting_id,
                        "assist_enabled": assist_enabled,
                        "notes": [],
                        "observations": [],
                    }
                    live_store = compact_live_store(live_store)
                    save_json_file(COACH_LIVE_SESSIONS_FILE, live_store)
                    await websocket.send(json.dumps({
                        "type": "coach_live_session_started",
                        "live_session": live_store[live_id],
                    }))

                elif t == "coach_live_note":
                    live_id = (d.get("live_session_id") or "").strip()
                    text = (d.get("text") or d.get("note_text") or "").strip()
                    if not live_id or not text:
                        await websocket.send(json.dumps({"type": "error", "message": "Missing live_session_id or text"}))
                        continue
                    sess = live_store.get(live_id)
                    if not sess:
                        await websocket.send(json.dumps({"type": "error", "message": "Live session not found"}))
                        continue
                    if sess.get("status") != "ACTIVE":
                        await websocket.send(json.dumps({"type": "error", "message": "Live session not active"}))
                        continue

                    note = {
                        "id": f"LSN_{uuid.uuid4().hex[:10]}",
                        "timestamp": datetime.datetime.now().isoformat(),
                        "text": text[:4000],
                    }
                    sess_notes = sess.get("notes") or []
                    if not isinstance(sess_notes, list):
                        sess_notes = []
                    sess_notes.append(note)
                    sess["notes"] = sess_notes[-600:]

                    # Lightweight heuristic "observation" (no AI dependency yet)
                    obs = None
                    if sess.get("assist_enabled"):
                        lower = text.lower()
                        if any(k in lower for k in ("longing", "need", "i never", "i always", "i feel", "i'm hurt", "i am hurt")):
                            obs = {
                                "id": f"LSO_{uuid.uuid4().hex[:10]}",
                                "timestamp": datetime.datetime.now().isoformat(),
                                "type": "LONGING_SIGNAL",
                                "message": "Possible longing signal detected. Consider slowing down and asking for the underlying need in one sentence.",
                                "evidence": text[:220],
                            }
                        elif any(k in lower for k in ("fix", "solution", "should", "just", "advice")):
                            obs = {
                                "id": f"LSO_{uuid.uuid4().hex[:10]}",
                                "timestamp": datetime.datetime.now().isoformat(),
                                "type": "FIXING_SIGNAL",
                                "message": "Possible 'fixing' move. Consider: 'Before solutions, can you reflect what you heard and what it meant to them?'",
                                "evidence": text[:220],
                            }
                        elif any(k in lower for k in ("angry", "shut down", "silent", "leave", "divorce")):
                            obs = {
                                "id": f"LSO_{uuid.uuid4().hex[:10]}",
                                "timestamp": datetime.datetime.now().isoformat(),
                                "type": "ESCALATION_SIGNAL",
                                "message": "Escalation cue. Consider a brief regulation pause + name the cycle without blame.",
                                "evidence": text[:220],
                            }

                    if obs:
                        sess_obs = sess.get("observations") or []
                        if not isinstance(sess_obs, list):
                            sess_obs = []
                        sess_obs.append(obs)
                        sess["observations"] = sess_obs[-400:]
                        await websocket.send(json.dumps({
                            "type": "coach_live_observation",
                            "live_session_id": live_id,
                            "observation": obs,
                        }))

                    live_store[live_id] = sess
                    live_store = compact_live_store(live_store)
                    save_json_file(COACH_LIVE_SESSIONS_FILE, live_store)
                    await websocket.send(json.dumps({
                        "type": "coach_live_note_ack",
                        "live_session_id": live_id,
                        "note": note,
                    }))

                else:
                    # end
                    live_id = (d.get("live_session_id") or "").strip()
                    share_with_nate = bool(d.get("share_with_nate", False))
                    if not live_id:
                        await websocket.send(json.dumps({"type": "error", "message": "Missing live_session_id"}))
                        continue
                    sess = live_store.get(live_id)
                    if not sess:
                        await websocket.send(json.dumps({"type": "error", "message": "Live session not found"}))
                        continue
                    sess["status"] = "ENDED"
                    sess["ended_at"] = datetime.datetime.now().isoformat()
                    live_store[live_id] = sess
                    live_store = compact_live_store(live_store)
                    save_json_file(COACH_LIVE_SESSIONS_FILE, live_store)

                    # Compute interaction time (anti-gaming baseline):
                    # - only counts when notes are being sent regularly
                    # - capped at scheduled duration (prevents "extend for pay")
                    interaction_seconds = 0
                    billable_seconds = 0
                    scheduled_seconds = 0
                    try:
                        sched_min = sess.get("scheduled_duration_minutes")
                        if isinstance(sched_min, (int, float)) and sched_min > 0:
                            scheduled_seconds = int(float(sched_min) * 60)
                    except Exception:
                        scheduled_seconds = 0

                    try:
                        # Build sorted note timestamps
                        notes = sess.get("notes") or []
                        ts = []
                        for n in notes:
                            tss = (n.get("timestamp") or "").strip()
                            if not tss:
                                continue
                            try:
                                ts.append(datetime.datetime.fromisoformat(tss))
                            except Exception:
                                continue
                        ts.sort()

                        # Max gap to count as "continuous interaction"
                        max_gap = 120  # seconds
                        # Count between notes if close enough
                        for i in range(1, len(ts)):
                            delta = (ts[i] - ts[i-1]).total_seconds()
                            if delta <= max_gap:
                                interaction_seconds += int(delta)
                        # Count tail from last note to end (up to max_gap)
                        if ts:
                            try:
                                end_dt = datetime.datetime.fromisoformat(sess.get("ended_at") or "")
                                tail = (end_dt - ts[-1]).total_seconds()
                                if 0 < tail <= max_gap:
                                    interaction_seconds += int(tail)
                            except Exception:
                                pass
                    except Exception:
                        interaction_seconds = 0

                    if scheduled_seconds > 0:
                        billable_seconds = min(interaction_seconds, scheduled_seconds)
                    else:
                        # fallback: cap by wall clock duration if present
                        try:
                            start_dt = datetime.datetime.fromisoformat(sess.get("started_at") or sess.get("created_at") or "")
                            end_dt = datetime.datetime.fromisoformat(sess.get("ended_at") or "")
                            wall = int((end_dt - start_dt).total_seconds())
                            billable_seconds = min(interaction_seconds, max(0, wall))
                        except Exception:
                            billable_seconds = interaction_seconds

                    # Record compensation ledger entry (no payout amount yet)
                    try:
                        ledger = load_json_file(COACH_COMPENSATION_LEDGER_FILE, []) or []
                        if not isinstance(ledger, list):
                            ledger = []
                        ledger_entry = {
                            "id": f"PAY_{uuid.uuid4().hex[:10]}",
                            "created_at": datetime.datetime.now().isoformat(),
                            "coach_id": sess.get("coach_id") or "",
                            "coach_username": sess.get("coach_username") or "",
                            "client_id": sess.get("client_id") or "",
                            "family_id": sess.get("family_id") or "",
                            "live_session_id": live_id,
                            "schedule_session_id": sess.get("schedule_session_id") or "",
                            "zoom_meeting_id": sess.get("zoom_meeting_id") or "",
                            "meeting_url": sess.get("meeting_url") or "",
                            "label": sess.get("label") or "",
                            "started_at": sess.get("started_at") or sess.get("created_at") or "",
                            "ended_at": sess.get("ended_at") or "",
                            "scheduled_duration_seconds": scheduled_seconds,
                            "interaction_seconds": int(interaction_seconds),
                            "billable_seconds": int(billable_seconds),
                            "status": "PENDING",
                        }
                        ledger.append(ledger_entry)
                        save_json_file(COACH_COMPENSATION_LEDGER_FILE, ledger[-5000:])
                    except Exception:
                        pass

                    # Also write into SessionTracker as a COACH session (so analytics can use it)
                    try:
                        client_for_session = sess.get("client_id") or ""
                        coach_for_session = sess.get("coach_id") or ""
                        srec = session_tracker.create_session(client_for_session, session_type="COACH", coach_id=coach_for_session)
                        # Attach billing-time metadata
                        srec["scheduled_duration_seconds"] = scheduled_seconds
                        srec["interaction_seconds"] = int(interaction_seconds)
                        srec["billable_seconds"] = int(billable_seconds)
                        srec["live_session_id"] = live_id
                        srec["schedule_session_id"] = sess.get("schedule_session_id") or ""
                        srec["zoom_meeting_id"] = sess.get("zoom_meeting_id") or ""
                        srec["meeting_url"] = sess.get("meeting_url") or ""
                        srec["label"] = sess.get("label") or ""
                        srec["coach_notes"] = "\n".join([(n.get("text") or "") for n in (sess.get("notes") or []) if n.get("text")])[:6000]
                        # Persist modified session record
                        sessions_all = session_tracker.load_sessions()
                        for i in range(len(sessions_all) - 1, -1, -1):
                            if sessions_all[i].get("session_id") == srec.get("session_id"):
                                sessions_all[i] = srec
                                break
                        session_tracker.save_sessions(sessions_all)
                    except Exception:
                        pass

                    if share_with_nate:
                        try:
                            notes = sess.get("notes") or []
                            joined = "\n".join([n.get("text", "") for n in notes if n.get("text")])[:6000]
                            if not joined.strip():
                                await websocket.send(json.dumps({
                                    "type": "coach_learning_not_enqueued",
                                    "live_session_id": live_id,
                                    "reason": "NO_NOTES",
                                }))
                            else:
                                queue = load_json_file(COACH_LEARNING_QUEUE_FILE, []) or []
                                if not isinstance(queue, list):
                                    queue = []
                                q_item = {
                                    "id": f"QL_{uuid.uuid4().hex[:10]}",
                                    "created_at": datetime.datetime.now().isoformat(),
                                    "status": "APPROVED" if (AUTO_APPROVE_COACH_LEARNING or current_profile.get("role") == "ADMIN") else "PENDING",
                                    "source": f"COACH_{sess.get('coach_username') or sess.get('coach_id')}",
                                    "category": "coach_live_session_notes",
                                    "folder_id": (f"family:{sess.get('family_id')}" if sess.get("family_id") else f"client:{sess.get('client_id')}"),
                                    "client_id": sess.get("client_id") or "",
                                    "family_id": sess.get("family_id") or "",
                                    "coach_id": sess.get("coach_id") or "",
                                    "coach_username": sess.get("coach_username") or "",
                                    "schedule_session_id": sess.get("schedule_session_id") or "",
                                    "zoom_meeting_id": sess.get("zoom_meeting_id") or "",
                                    "meeting_url": sess.get("meeting_url") or "",
                                    "label": sess.get("label") or "",
                                    "started_at": sess.get("started_at") or sess.get("created_at") or "",
                                    "ended_at": sess.get("ended_at") or "",
                                    "content": joined,
                                    "raw_live_session_id": live_id,
                                }
                                queue.append(q_item)
                                queue = compact_coach_learning_queue(queue)
                                save_json_file(COACH_LEARNING_QUEUE_FILE, queue)

                                # Ack to coach UI for clear feedback
                                await websocket.send(json.dumps({
                                    "type": "coach_learning_enqueued",
                                    "live_session_id": live_id,
                                    "queue_id": q_item.get("id"),
                                    "status": q_item.get("status"),
                                }))

                                # Push to connected admins for real-time approvals UX
                                try:
                                    reg = load_registry()
                                    admin_ids = [v.get("profile", {}).get("hardware_id") for v in reg.values() if v.get("profile", {}).get("role") == "ADMIN"]
                                    payload = json.dumps({
                                        "type": "admin_coach_learning_queue_new",
                                        "item": q_item,
                                    })
                                    for aid in admin_ids:
                                        if not aid:
                                            continue
                                        for aws in list(getattr(cortex, "sockets", {}).get(aid, set()) or []):
                                            try:
                                                await aws.send(payload)
                                            except Exception:
                                                continue
                                except Exception:
                                    pass

                                if q_item["status"] == "APPROVED":
                                    try:
                                        night_school.add_learning(
                                            content=q_item["content"],
                                            source=q_item["source"],
                                            filename=f"{q_item['id']}.txt",
                                            category=q_item["category"],
                                        )
                                    except Exception:
                                        pass
                        except Exception:
                            # Surface enqueue failures to coach UI (otherwise it's invisible)
                            try:
                                await websocket.send(json.dumps({
                                    "type": "coach_learning_not_enqueued",
                                    "live_session_id": live_id,
                                    "reason": "ERROR",
                                }))
                            except Exception:
                                pass

                    await websocket.send(json.dumps({
                        "type": "coach_live_session_ended",
                        "live_session_id": live_id,
                    }))

            # === ADMIN: COACH LEARNING QUEUE (approve/reject) ===
            elif t in ("admin_get_coach_learning_queue", "admin_approve_coach_learning", "admin_reject_coach_learning"):
                if not current_profile or current_profile.get("role") != "ADMIN":
                    await websocket.send(json.dumps({"type": "error", "message": "ADMIN_ONLY"}))
                    continue

                queue = load_json_file(COACH_LEARNING_QUEUE_FILE, []) or []
                if not isinstance(queue, list):
                    queue = []

                if t == "admin_get_coach_learning_queue":
                    status = (d.get("status") or "PENDING").upper()
                    filtered = [q for q in queue if (q.get("status") or "").upper() == status] if status else queue
                    await websocket.send(json.dumps({
                        "type": "admin_coach_learning_queue",
                        "status": status,
                        "items": filtered[-300:],
                    }))

                else:
                    qid = (d.get("queue_id") or d.get("id") or "").strip()
                    if not qid:
                        await websocket.send(json.dumps({"type": "error", "message": "Missing queue_id"}))
                        continue
                    updated = False
                    for item in queue:
                        if item.get("id") == qid:
                            if t == "admin_approve_coach_learning":
                                item["status"] = "APPROVED"
                                item["approved_at"] = datetime.datetime.now().isoformat()
                                item["approved_by"] = current_profile.get("name") or "ADMIN"
                                # Optional admin edits
                                edited = (d.get("edited_content") or "").strip()
                                if edited:
                                    item["content"] = edited[:6000]
                                # Push into Night School
                                try:
                                    night_school.add_learning(
                                        content=(item.get("content") or "")[:6000],
                                        source=item.get("source") or "COACH_UNKNOWN",
                                        filename=f"{item.get('id')}.txt",
                                        category=item.get("category") or "coach_learning",
                                    )
                                except Exception:
                                    pass
                            else:
                                item["status"] = "REJECTED"
                                item["rejected_at"] = datetime.datetime.now().isoformat()
                                item["rejected_by"] = current_profile.get("name") or "ADMIN"
                                item["rejection_reason"] = (d.get("reason") or "").strip()[:400]
                            updated = True
                            break

                    if updated:
                        queue = compact_coach_learning_queue(queue)
                        save_json_file(COACH_LEARNING_QUEUE_FILE, queue)
                        await websocket.send(json.dumps({
                            "type": "admin_coach_learning_queue_updated",
                            "queue_id": qid,
                        }))
                    else:
                        await websocket.send(json.dumps({"type": "error", "message": "Queue item not found"}))
            
            # === COACH: GET CALENDAR ===
            elif t == "fetch_coach_calendar":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    month = d.get("month")
                    year = d.get("year")
                    try:
                        calendar_data = coach_nexus_v2.get_calendar_data(current_profile, month, year)
                        await websocket.send(json.dumps({
                            "type": "coach_calendar_data",
                            "data": calendar_data
                        }))
                    except Exception as e:
                        # Don't drop the socket on calendar errors; surface them to the UI.
                        await websocket.send(json.dumps({
                            "type": "coach_calendar_data",
                            "data": {"month": month, "year": year, "schedule": [], "availability": []},
                            "error": f"{type(e).__name__}: {str(e)}"
                        }))
            
            # === COACH: GET RECORDED SESSIONS ===
            elif t == "fetch_coach_sessions":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    filter_type = d.get("filter", "all")
                    sessions = coach_nexus_v2.get_recorded_sessions(current_profile, filter_type)
                    await websocket.send(json.dumps({
                        "type": "coach_sessions_data",
                        "data": {"sessions": sessions}
                    }))
            
            # === COACH: CANCEL SESSION ===
            elif t == "coach_cancel_session":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    result = coach_nexus_v2.cancel_session(
                        current_profile,
                        d.get("session_id", ""),
                        d.get("reason", ""),
                        d.get("send_reschedule_link", True)
                    )
                    await websocket.send(json.dumps({
                        "type": "session_cancelled",
                        "status": result
                    }))
            
            # === COACH: GET COACHING ADVICE ===
            elif t == "fetch_coaching_advice":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    advice = coach_nexus_v2.get_coaching_advice(
                        current_profile,
                        d.get("session_id", "")
                    )
                    await websocket.send(json.dumps({
                        "type": "coaching_advice_data",
                        "data": advice
                    }))
            
            # === COACH: AI QUERY WITH CLIENT CONTEXT ===
            elif t == "coach_nate_query":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    query = d.get("nate_query", d.get("text", ""))
                    client_context = d.get("client_id")
                    
                    if client_context:
                        registry = load_registry()
                        brief = coach_nexus_v2.get_presession_brief(
                            current_profile,
                            client_context,
                            registry
                        )
                        augmented_query = f"[Coach asking about {brief.get('client_name', 'client')}]: {query}"
                    else:
                        augmented_query = f"[Coach general query]: {query}"
                    
                    await cortex.process_interaction(current_profile, augmented_query)
            
            # === COACH: SAVE RECORDING METADATA ===
            elif t == "save_recording":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    result = coach_nexus_v2.save_recording_metadata(
                        current_profile,
                        d.get("session_id", ""),
                        d.get("client_id", ""),
                        d.get("client_name", ""),
                        d.get("duration", 50),
                        d.get("platform", "Zoom"),
                        d.get("biometrics_captured", True)
                    )
                    await websocket.send(json.dumps({
                        "type": "recording_saved",
                        "status": result
                    }))
            
            # === DOJO: START TRAINING SESSION ===
            elif t == "dojo_start":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    if night_school_handler:
                        await night_school_handler.handle_start_dojo(websocket, d, current_profile)
                    else:
                        await websocket.send(json.dumps({"type": "error", "message": "Dojo module not available"}))
            
            # === DOJO: SEND TEST MESSAGE ===
            elif t == "dojo_test_message":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    if night_school_handler:
                        await night_school_handler.handle_dojo_message(websocket, d, current_profile)
                    else:
                        await websocket.send(json.dumps({"type": "error", "message": "Dojo module not available"}))
            
            # === DOJO: END TRAINING SESSION ===
            elif t == "dojo_end":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    if night_school_handler:
                        await night_school_handler.handle_end_dojo(websocket, d, current_profile)
                    else:
                        await websocket.send(json.dumps({"type": "error", "message": "Dojo module not available"}))
            
            # === GET CLIENT PROFILE (for coaches) ===
            elif t == "get_client_profile":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    client_id = d.get("client_id")
                    registry = load_registry()
                    for k, v in registry.items():
                        if v.get("profile", {}).get("hardware_id") == client_id:
                            client_profile = v["profile"]
                            safe_profile = {
                                "hardware_id": client_profile.get("hardware_id"),
                                "name": client_profile.get("name"),
                                "email": client_profile.get("email"),
                                "tier": client_profile.get("tier"),
                                "joined_date": client_profile.get("joined_date"),
                                "last_login": client_profile.get("last_login"),
                                "total_sessions_count": client_profile.get("total_sessions_count", 0),
                                "family_id": client_profile.get("family_id"),
                                "assigned_coach_id": client_profile.get("assigned_coach_id")
                            }
                            metrics = parietal.get_metrics_summary(client_profile)
                            await websocket.send(json.dumps({
                                "type": "client_profile_data",
                                "profile": safe_profile,
                                "metrics": metrics
                            }))
                            break
            
            # === CREATE DEPENDENT (Family Member) ===
            elif t == "create_dependent":
                if current_profile:
                    success, result = create_dependent_account(uid, d)
                    if success:
                        await websocket.send(json.dumps({
                            "type": "dependent_created",
                            "message": result
                        }))
                    else:
                        await websocket.send(json.dumps({
                            "type": "error",
                            "message": result
                        }))
            
            # === GET FAMILY MEMBERS ===
            elif t == "get_family_members":
                if current_profile:
                    family_id = current_profile.get("family_id")
                    registry = load_registry()
                    members = []
                    for k, v in registry.items():
                        p = v.get("profile", {})
                        if p.get("family_id") == family_id:
                            members.append({
                                "id": p.get("hardware_id"),
                                "name": p.get("name"),
                                "role": p.get("role"),
                                "tier": p.get("tier"),
                                "is_minor": p.get("is_minor", False),
                                "guardian_id": p.get("guardian_id", "")
                            })
                    await websocket.send(json.dumps({
                        "type": "family_members",
                        "family_id": family_id,
                        "members": members
                    }))
            
            # === NEVEDAL: BIOMETRIC UPDATE ===
            elif t == "biometric_update":
                if current_profile:
                    await nevedal_handler.handle_biometric_update(websocket, d, current_profile)

            # === SANCTUARY: BIOMETRIC SNAPSHOT ===
            elif t == "sanctuary_biometric_snapshot":
                """
                Member shares biometric snapshot during sanctuary session.
                Does NOT replace Nevedal biometrics; this is sanctuary-scoped context.
                """
                if current_profile:
                    sanctuary_id = d.get("sanctuary_id")
                    biometric_data = d.get("biometrics", {}) or {}
                    if sanctuary_id and biometric_data:
                        ok = sanctuary_engine.store_member_biometrics(
                            sanctuary_id=sanctuary_id,
                            member_id=current_profile.get("hardware_id"),
                            biometric_data=biometric_data,
                        )
                        await websocket.send(json.dumps({
                            "type": "sanctuary_biometric_snapshot_ack",
                            "success": ok,
                        }))

            # === SANCTUARY: REALTIME HEART RATE STREAM ===
            elif t == "sanctuary_realtime_hr":
                """
                Real-time HR stream for physiology-aware facilitation.
                Payload: {sanctuary_id, bpm, timestamp?}
                """
                if current_profile:
                    sanctuary_id = d.get("sanctuary_id")
                    bpm = d.get("bpm")
                    ts = d.get("timestamp")
                    if sanctuary_id and bpm is not None:
                        result = sanctuary_engine.update_realtime_heart_rate(
                            sanctuary_id=sanctuary_id,
                            member_id=current_profile.get("hardware_id"),
                            bpm=int(bpm),
                            timestamp=ts,
                        )

                        esc = (result.get("escalation") or {})
                        if esc.get("elevated"):
                            duration = float(esc.get("duration_seconds") or 0)
                            # Send a private support prompt once when crossing ~60s
                            if 60 <= duration <= 75:
                                try:
                                    await websocket.send(json.dumps({
                                        "type": "sanctuary_physiological_support",
                                        "support_type": "elevated_hr",
                                        "message": "I notice your body is activated right now. Would you like to take a moment to breathe before continuing?",
                                        "breathing_exercise": sanctuary_engine.get_breathing_exercise("physiological_sigh"),
                                    }))
                                except Exception:
                                    pass

            # === SANCTUARY: GET BREATHING EXERCISE ===
            elif t == "sanctuary_get_breathing_exercise":
                exercise_type = d.get("exercise_type", "box")
                await websocket.send(json.dumps({
                    "type": "sanctuary_breathing_exercise",
                    "exercise": sanctuary_engine.get_breathing_exercise(exercise_type),
                }))
            
            # === NEVEDAL: SUBSCRIBE ===
            elif t == "nevedal_subscribe":
                await nevedal_handler.handle_subscribe(websocket, d)
            
            # === NEVEDAL: UNSUBSCRIBE ===
            elif t == "nevedal_unsubscribe":
                await nevedal_handler.handle_unsubscribe(websocket, d)
            
            # === NEVEDAL: GET HISTORY ===
            elif t == "nevedal_get_history":
                await nevedal_handler.handle_get_history(websocket, d)
            
            # === NEVEDAL: GET SESSION SUMMARY ===
            elif t == "nevedal_get_session_summary":
                await nevedal_handler.handle_session_summary(websocket, d)
            
            # === NEVEDAL: GET CEE EVENTS ===
            elif t == "nevedal_get_cee_events":
                await nevedal_handler.handle_get_cee_events(websocket, d)
            

            # === ADMIN: GET DYAD SYNC ===
            elif t == "admin_get_dyad_sync":
                if current_profile and current_profile.get("role") == "ADMIN":
                    client_id = d.get("client_id")
                    coach_id = d.get("coach_id")
                    session_id = d.get("session_id")  # optional
                    
                    if not client_id or not coach_id:
                        await websocket.send(json.dumps({
                            "type": "error",
                            "message": "Missing client_id or coach_id"
                        }))
                    else:
                        # Load metrics for both
                        registry = load_registry()
                        client_profile = None
                        coach_profile = None
                        
                        for k, v in registry.items():
                            profile = v.get("profile", {})
                            if profile.get("hardware_id") == client_id:
                                client_profile = profile
                            if profile.get("hardware_id") == coach_id:
                                coach_profile = profile
                        
                        if not client_profile or not coach_profile:
                            await websocket.send(json.dumps({
                                "type": "error",
                                "message": "Client or coach not found"
                            }))
                        else:
                            # Get Nevedal states
                            client_metrics = metrics_engine.load_metrics({"role": "CLIENT", "hardware_id": client_id})
                            coach_metrics = metrics_engine.load_metrics({"role": "COACH", "hardware_id": coach_id})
                            
                            client_state = client_metrics.get("nevedal_state", {})
                            coach_state = coach_metrics.get("nevedal_state", {})
                            
                            # Calculate synchrony score (simplified)
                            client_c_emo = client_state.get("C_emo", 0.5)
                            coach_c_emo = coach_state.get("C_emo", 0.5)
                            
                            # Synchrony = 1 - normalized difference
                            diff = abs(client_c_emo - coach_c_emo)
                            synchrony_score = 1.0 - diff
                            
                            # Determine grade
                            if synchrony_score >= 0.85:
                                grade = "EXCELLENT"
                            elif synchrony_score >= 0.70:
                                grade = "GOOD"
                            elif synchrony_score >= 0.55:
                                grade = "MODERATE"
                            else:
                                grade = "DEVELOPING"
                            
                            # Build timeline data (simplified - would need session data for real implementation)
                            client_timeline = [
                                {"timestamp": 0, "c_emo": max(0.4, client_c_emo - 0.1)},
                                {"timestamp": 15, "c_emo": max(0.5, client_c_emo - 0.05)},
                                {"timestamp": 30, "c_emo": client_c_emo},
                                {"timestamp": 45, "c_emo": min(1.0, client_c_emo + 0.05)}
                            ]
                            
                            coach_timeline = [
                                {"timestamp": 0, "c_emo": max(0.4, coach_c_emo - 0.08)},
                                {"timestamp": 15, "c_emo": max(0.5, coach_c_emo - 0.03)},
                                {"timestamp": 30, "c_emo": coach_c_emo},
                                {"timestamp": 45, "c_emo": min(1.0, coach_c_emo + 0.08)}
                            ]
                            
                            # Shared CEE moments (when both > 0.75)
                            shared_cees = []
                            if client_c_emo > 0.75 and coach_c_emo > 0.75:
                                shared_cees = [
                                    {
                                        "timestamp": "00:15:30",
                                        "client_c_emo": round(client_c_emo * 0.95, 2),
                                        "coach_c_emo": round(coach_c_emo * 0.95, 2)
                                    },
                                    {
                                        "timestamp": "00:32:18",
                                        "client_c_emo": round(client_c_emo, 2),
                                        "coach_c_emo": round(coach_c_emo, 2)
                                    }
                                ]
                            
                            # Calculate correlation (simplified)
                            correlation_coefficient = synchrony_score * 0.9  # Simplified
                            lag_time = -2.3 if coach_c_emo > client_c_emo else 1.8
                            
                            await websocket.send(json.dumps({
                                "type": "dyad_sync_data",
                                "synchrony_score": round(synchrony_score, 2),
                                "grade": grade,
                                "client_c_emo": round(client_c_emo, 2),
                                "coach_c_emo": round(coach_c_emo, 2),
                                "client_timeline": client_timeline,
                                "coach_timeline": coach_timeline,
                                "shared_cees": shared_cees,
                                "correlation_coefficient": round(correlation_coefficient, 2),
                                "lag_time": round(lag_time, 1)
                            }))

            # === ADMIN: GET USER METRICS (RAW) ===
            elif t == "admin_get_user_metrics":
                if current_profile and current_profile.get("role") == "ADMIN":
                    user_id = d.get("user_id") or d.get("hardware_id")
                    if not user_id:
                        await websocket.send(json.dumps({
                            "type": "error",
                            "message": "Missing user_id"
                        }))
                    else:
                        try:
                            # Find role (best-effort) so we load the right vault path
                            registry = load_registry()
                            role = "CLIENT"
                            name = ""
                            for _, v in registry.items():
                                p = (v.get("profile") or {})
                                if p.get("hardware_id") == user_id:
                                    role = (p.get("role") or "CLIENT")
                                    name = (p.get("name") or "")
                                    break

                            metrics = metrics_engine.load_metrics({"role": role, "hardware_id": user_id})
                            ns = metrics.get("nevedal_state", {}) or {}

                            # Best-effort "last updated" from metrics file mtime
                            last_updated_iso = ""
                            try:
                                path = metrics_engine._path({"role": role, "hardware_id": user_id})
                                if path:
                                    mtime = os.path.getmtime(path)
                                    last_updated_iso = datetime.datetime.fromtimestamp(mtime).isoformat()
                            except Exception:
                                last_updated_iso = ""

                            await websocket.send(json.dumps({
                                "type": "admin_user_metrics",
                                "user_id": user_id,
                                "name": name,
                                "role": role,
                                "server_time": datetime.datetime.now().isoformat(),
                                "last_updated": last_updated_iso,
                                "nevedal_state": ns,
                            }))
                        except Exception as e:
                            await websocket.send(json.dumps({
                                "type": "error",
                                "message": f"Failed to load metrics for {user_id}: {e}"
                            }))

            # === COACH: GET LIVE SANCTUARY BRIEFING ===
            elif t == "coach_get_briefing":
                if not current_profile:
                    await websocket.send(json.dumps({"type": "error", "message": "Not authenticated"}))
                elif current_profile.get("role") not in ("COACH", "ADMIN"):
                    await websocket.send(json.dumps({"type": "error", "message": "COACH_ONLY"}))
                else:
                    sanctuary_id = d.get("sanctuary_id")
                    include_transcripts = bool(d.get("include_transcripts", True))
                    max_transcripts = int(d.get("max_transcript_messages", 60) or 60)

                    sanctuary = sanctuary_engine.get_session(sanctuary_id) if sanctuary_id else None
                    if not sanctuary:
                        await websocket.send(json.dumps({"type": "error", "message": "Sanctuary not found"}))
                    else:
                        family_id = sanctuary.get("family_id") or ""

                        # Authorization for COACH: must be assigned to this family (best-effort)
                        if current_profile.get("role") == "COACH":
                            assigned_ok = False
                            try:
                                coach_assigned = ((sanctuary.get("coach_escalation") or {}).get("coach_assigned") or "")
                                if coach_assigned and coach_assigned in (current_username, current_profile.get("hardware_id")):
                                    assigned_ok = True
                            except Exception:
                                assigned_ok = False

                            if not assigned_ok:
                                try:
                                    registry = load_registry()
                                    for _, v in registry.items():
                                        p = (v.get("profile") or {})
                                        if p.get("family_id") == family_id and (
                                            (p.get("assigned_coach_id") and p.get("assigned_coach_id") == current_profile.get("hardware_id"))
                                            or (p.get("assigned_coach") and p.get("assigned_coach") == current_username)
                                        ):
                                            assigned_ok = True
                                            break
                                except Exception:
                                    assigned_ok = False

                            if not assigned_ok:
                                await websocket.send(json.dumps({"type": "error", "message": "COACH_NOT_ASSIGNED"}))
                                continue

                        # Build member profile map
                        member_ids = []
                        try:
                            member_ids.extend([m.get("user_id") for m in (sanctuary.get("members") or []) if m.get("user_id")])
                        except Exception:
                            pass
                        try:
                            member_ids.extend([mid for mid in (sanctuary.get("invited_member_ids") or []) if mid])
                        except Exception:
                            pass
                        member_ids = list(dict.fromkeys([m for m in member_ids if m]))  # stable unique

                        registry = load_registry()
                        member_profiles = {}
                        for _, v in registry.items():
                            p = (v.get("profile") or {})
                            hid = p.get("hardware_id")
                            if hid and hid in member_ids:
                                member_profiles[hid] = p

                        briefing = sanctuary_engine.generate_coach_briefing(
                            sanctuary_id=sanctuary_id,
                            member_profiles=member_profiles,
                            metrics_engine=parietal,
                            memory_system=hippocampus,
                            include_transcripts=include_transcripts,
                            max_transcript_messages=max_transcripts,
                        )

                        try:
                            sanctuary_engine._record_analytics("coach_briefing_viewed", uid, {
                                "sanctuary_id": sanctuary_id,
                                "family_id": family_id,
                                "include_transcripts": include_transcripts,
                            })
                        except Exception:
                            pass

                        await websocket.send(json.dumps({
                            "type": "coach_briefing",
                            "sanctuary_id": sanctuary_id,
                            "briefing": briefing
                        }))

            # === COACH: GET CLIENT BRIEFING (NON-SANCTUARY) ===
            elif t == "coach_get_client_briefing":
                if not current_profile:
                    await websocket.send(json.dumps({"type": "error", "message": "Not authenticated"}))
                elif current_profile.get("role") not in ("COACH", "ADMIN"):
                    await websocket.send(json.dumps({"type": "error", "message": "COACH_ONLY"}))
                else:
                    client_id = d.get("client_id") or d.get("user_id")
                    if not client_id:
                        await websocket.send(json.dumps({"type": "error", "message": "Missing client_id"}))
                        continue

                    registry = load_registry()
                    client_profile = None
                    for _, v in registry.items():
                        p = (v.get("profile") or {})
                        if p.get("hardware_id") == client_id:
                            client_profile = p
                            break

                    if not client_profile:
                        await websocket.send(json.dumps({"type": "error", "message": "Client not found"}))
                        continue

                    # Authorization for COACH: must be assigned to this client (best-effort)
                    if current_profile.get("role") == "COACH":
                        assigned = (
                            (client_profile.get("assigned_coach_id") and client_profile.get("assigned_coach_id") == current_profile.get("hardware_id"))
                            or (client_profile.get("assigned_coach") and client_profile.get("assigned_coach") == current_username)
                        )
                        if not assigned:
                            await websocket.send(json.dumps({"type": "error", "message": "COACH_NOT_ASSIGNED"}))
                            continue
                    try:
                        metrics = parietal.load_metrics(client_profile)
                        ns = (metrics.get("nevedal_state") or {})
                    except Exception:
                        ns = {}

                    try:
                        memories = hippocampus.recall_full(client_profile, limit=20)
                    except Exception:
                        memories = []

                    await websocket.send(json.dumps({
                        "type": "coach_briefing",
                        "client_id": client_id,
                        "briefing": {
                            "generated_at": datetime.datetime.now().isoformat(),
                            "scope": "client",
                            "client_id": client_id,
                            "client_name": client_profile.get("name", "Unknown"),
                            "family_id": client_profile.get("family_id", ""),
                            "risk_level": ns.get("risk_level", "LOW"),
                            "nevedal_state": ns,
                            "recent_memory": memories,
                        }
                    }))

            # === DOJO: SHARE LEARNING FOR APPROVAL ===
            elif t == "dojo_share_learning":
                if not current_profile or current_profile.get("role") not in ("COACH", "ADMIN"):
                    await websocket.send(json.dumps({"type": "error", "message": "COACH_ONLY"}))
                    continue

                persona = (d.get("persona") or "").strip() or "HOSTILE"
                prompt = (d.get("prompt") or "").strip()
                coach_response = (d.get("coach_response") or "").strip()
                analysis = d.get("analysis") or {}
                if not isinstance(analysis, dict):
                    analysis = {}

                # Require at least some usable payload to avoid empty spam.
                if not (prompt or coach_response):
                    await websocket.send(json.dumps({"type": "coach_learning_not_enqueued", "reason": "EMPTY"}))
                    continue

                try:
                    score = analysis.get("score")
                    feedback = (analysis.get("feedback") or "").strip()
                    strengths = analysis.get("strengths") or []
                    improvements = analysis.get("improvements") or []
                    if not isinstance(strengths, list):
                        strengths = []
                    if not isinstance(improvements, list):
                        improvements = []

                    parts = []
                    parts.append(f"[DOJO] persona={persona}")
                    if prompt:
                        parts.append(f"Client prompt:\n{prompt}")
                    if coach_response:
                        parts.append(f"Coach response:\n{coach_response}")
                    if score is not None:
                        parts.append(f"Score: {score}")
                    if feedback:
                        parts.append(f"Feedback:\n{feedback}")
                    if strengths:
                        parts.append("Strengths:\n- " + "\n- ".join([str(s) for s in strengths if str(s).strip()][:12]))
                    if improvements:
                        parts.append("Improvements:\n- " + "\n- ".join([str(i) for i in improvements if str(i).strip()][:12]))
                    content = "\n\n".join([p for p in parts if p.strip()])[:6000]

                    queue = load_json_file(COACH_LEARNING_QUEUE_FILE, []) or []
                    if not isinstance(queue, list):
                        queue = []
                    q_item = {
                        "id": f"QL_{uuid.uuid4().hex[:10]}",
                        "created_at": datetime.datetime.now().isoformat(),
                        "status": "APPROVED" if (AUTO_APPROVE_COACH_LEARNING or current_profile.get("role") == "ADMIN") else "PENDING",
                        "source": f"COACH_{(current_username or current_profile.get('name') or current_profile.get('hardware_id') or '').strip() or 'UNKNOWN'}",
                        "category": "coach_dojo_training",
                        "folder_id": f"dojo:{current_profile.get('hardware_id') or ''}",
                        "client_id": "",
                        "family_id": "",
                        "coach_id": current_profile.get("hardware_id") or "",
                        "coach_username": current_username or current_profile.get("name") or "",
                        "dojo_persona": persona,
                        "content": content,
                        "raw": {
                            "session_id": (d.get("session_id") or "").strip(),
                            "persona": persona,
                            "prompt": prompt[:4000],
                            "coach_response": coach_response[:4000],
                            "analysis": analysis,
                        },
                    }
                    queue.append(q_item)
                    queue = compact_coach_learning_queue(queue)
                    save_json_file(COACH_LEARNING_QUEUE_FILE, queue)

                    # Ack to coach UI
                    await websocket.send(json.dumps({
                        "type": "coach_learning_enqueued",
                        "queue_id": q_item.get("id"),
                        "status": q_item.get("status"),
                    }))

                    # Push to connected admins for real-time approvals UX
                    try:
                        reg = load_registry()
                        admin_ids = [v.get("profile", {}).get("hardware_id") for v in reg.values() if v.get("profile", {}).get("role") == "ADMIN"]
                        payload = json.dumps({
                            "type": "admin_coach_learning_queue_new",
                            "item": q_item,
                        })
                        for aid in admin_ids:
                            if not aid:
                                continue
                            for aws in list(getattr(cortex, "sockets", {}).get(aid, set()) or []):
                                try:
                                    await aws.send(payload)
                                except Exception:
                                    continue
                    except Exception:
                        pass

                    if q_item["status"] == "APPROVED":
                        try:
                            night_school.add_learning(
                                content=(q_item.get("content") or "")[:6000],
                                source=q_item.get("source") or "COACH_UNKNOWN",
                                filename=f"{q_item.get('id')}.txt",
                                category=q_item.get("category") or "coach_learning",
                            )
                        except Exception:
                            pass
                except Exception:
                    await websocket.send(json.dumps({"type": "coach_learning_not_enqueued", "reason": "ERROR"}))
            
            # === ADMIN: GET FAMILY METRICS ===
            elif t == "admin_get_family_metrics":
                if current_profile and current_profile.get("role") == "ADMIN":
                    family_id = d.get("family_id")
                    
                    if not family_id:
                        await websocket.send(json.dumps({
                            "type": "error",
                            "message": "Missing family_id"
                        }))
                    else:
                        # Find family members
                        registry = load_registry()
                        family_members = []
                        
                        for k, v in registry.items():
                            profile = v.get("profile", {})
                            if profile.get("family_id") == family_id:
                                family_members.append(profile)
                        
                        if not family_members:
                            await websocket.send(json.dumps({
                                "type": "error",
                                "message": "No family members found"
                            }))
                        else:
                            # Get metrics for each member
                            members_data = []
                            c_emo_values = []
                            
                            for member in family_members:
                                member_metrics = metrics_engine.load_metrics({
                                    "role": member.get("role", "CLIENT"),
                                    "hardware_id": member.get("hardware_id")
                                })
                                nevedal_state = member_metrics.get("nevedal_state", {})
                                c_emo = nevedal_state.get("C_emo", 0.5)
                                c_emo_values.append(c_emo)
                                
                                members_data.append({
                                    "id": member.get("hardware_id"),
                                    "name": member.get("name", "Unknown"),
                                    "c_emo_avg": round(c_emo, 2)
                                })
                            
                            # Calculate coherence matrix (pairwise scores)
                            coherence_matrix = {}
                            for i, member1 in enumerate(members_data):
                                for j, member2 in enumerate(members_data):
                                    if i != j:
                                        # Simplified coherence = 1 - normalized difference
                                        diff = abs(c_emo_values[i] - c_emo_values[j])
                                        coherence = round(1.0 - diff, 2)
                                        key = f"{member1['name'].lower().split()[0]}_{member2['name'].lower().split()[0]}"
                                        coherence_matrix[key] = coherence
                            
                            # Family wellness index (average C_emo)
                            family_wellness_index = round(sum(c_emo_values) / len(c_emo_values), 2)
                            
                            # Find strongest and weakest bonds
                            if coherence_matrix:
                                strongest_pair = max(coherence_matrix.items(), key=lambda x: x[1])
                                weakest_pair = min(coherence_matrix.items(), key=lambda x: x[1])
                                
                                strongest_bond = {
                                    "pair": strongest_pair[0].split("_"),
                                    "score": strongest_pair[1]
                                }
                                weakest_bond = {
                                    "pair": weakest_pair[0].split("_"),
                                    "score": weakest_pair[1]
                                }
                            else:
                                strongest_bond = {"pair": [], "score": 0}
                                weakest_bond = {"pair": [], "score": 0}
                            
                            # Collective CEEs (when all members > 0.75)
                            collective_cees = []
                            if all(v > 0.75 for v in c_emo_values):
                                collective_cees = [
                                    {
                                        "timestamp": "00:18:45",
                                        "all_members_synced": True
                                    },
                                    {
                                        "timestamp": "00:34:12",
                                        "all_members_synced": True
                                    }
                                ]
                            
                            await websocket.send(json.dumps({
                                "type": "family_metrics",
                                "family_id": family_id,
                                "members": members_data,
                                "coherence_matrix": coherence_matrix,
                                "family_wellness_index": family_wellness_index,
                                "strongest_bond": strongest_bond,
                                "weakest_bond": weakest_bond,
                                "collective_cees": collective_cees
                            }))
            
            # === ADMIN: GET COHORT STATS ===
            elif t == "admin_get_cohort_stats":
                if current_profile and current_profile.get("role") == "ADMIN":
                    filters = d.get("filters", {})
                    age_groups = filters.get("age_groups", ["18-25", "26-35", "36-50", "51+"])
                    diagnoses = filters.get("diagnoses", ["anxiety", "depression", "ptsd", "none"])
                    treatment_types = filters.get("treatment_types", ["ai_only", "ai_coach", "family"])
                    time_range = filters.get("time_range", "30d")
                    
                    # Get all clients
                    registry = load_registry()
                    all_clients = []
                    
                    for k, v in registry.items():
                        profile = v.get("profile", {})
                        if profile.get("role") == "CLIENT":
                            all_clients.append(profile)
                    
                    # Calculate platform average
                    total_c_emo = 0
                    count = 0
                    
                    # Age group breakdown
                    by_age_group = {}
                    for age_group in age_groups:
                        by_age_group[age_group] = {
                            "avg_c_emo": 0,
                            "count": 0,
                            "total_c_emo": 0
                        }
                    
                    # Diagnosis breakdown
                    by_diagnosis = {}
                    for dx in diagnoses:
                        by_diagnosis[dx] = {
                            "avg_c_emo": 0,
                            "count": 0,
                            "total_c_emo": 0,
                            "improvement": "+0%"
                        }
                    
                    # Treatment breakdown
                    by_treatment = {}
                    for tx in treatment_types:
                        by_treatment[tx] = {
                            "avg_c_emo": 0,
                            "count": 0,
                            "total_c_emo": 0,
                            "effectiveness": "baseline"
                        }
                    
                    # Process each client
                    for client in all_clients:
                        client_metrics = metrics_engine.load_metrics({
                            "role": "CLIENT",
                            "hardware_id": client.get("hardware_id")
                        })
                        nevedal_state = client_metrics.get("nevedal_state", {})
                        c_emo = nevedal_state.get("C_emo", 0.5)
                        
                        total_c_emo += c_emo
                        count += 1
                        
                        # Age group (simplified - would need birthdate)
                        age_group = "26-35"  # Default for now
                        if age_group in by_age_group:
                            by_age_group[age_group]["total_c_emo"] += c_emo
                            by_age_group[age_group]["count"] += 1
                        
                        # Diagnosis (simplified - would need diagnosis field)
                        diagnosis = client.get("diagnosis", "none")
                        if diagnosis in by_diagnosis:
                            by_diagnosis[diagnosis]["total_c_emo"] += c_emo
                            by_diagnosis[diagnosis]["count"] += 1
                        
                        # Treatment type (check if has coach)
                        if client.get("assigned_coach_id"):
                            tx_type = "ai_coach"
                        elif client.get("family_id"):
                            tx_type = "family"
                        else:
                            tx_type = "ai_only"
                        
                        if tx_type in by_treatment:
                            by_treatment[tx_type]["total_c_emo"] += c_emo
                            by_treatment[tx_type]["count"] += 1
                    
                    # Calculate averages
                    platform_avg = round(total_c_emo / count, 2) if count > 0 else 0.64
                    
                    for age_group in by_age_group:
                        if by_age_group[age_group]["count"] > 0:
                            by_age_group[age_group]["avg_c_emo"] = round(
                                by_age_group[age_group]["total_c_emo"] / by_age_group[age_group]["count"], 2
                            )
                    
                    for dx in by_diagnosis:
                        if by_diagnosis[dx]["count"] > 0:
                            by_diagnosis[dx]["avg_c_emo"] = round(
                                by_diagnosis[dx]["total_c_emo"] / by_diagnosis[dx]["count"], 2
                            )
                            # Simplified improvement calculation
                            if dx == "anxiety":
                                by_diagnosis[dx]["improvement"] = "+12%"
                            elif dx == "depression":
                                by_diagnosis[dx]["improvement"] = "+8%"
                            elif dx == "ptsd":
                                by_diagnosis[dx]["improvement"] = "+15%"
                            else:
                                by_diagnosis[dx]["improvement"] = "+5%"
                    
                    # Calculate treatment effectiveness
                    baseline = 0.59
                    for tx in by_treatment:
                        if by_treatment[tx]["count"] > 0:
                            avg = round(by_treatment[tx]["total_c_emo"] / by_treatment[tx]["count"], 2)
                            by_treatment[tx]["avg_c_emo"] = avg
                            
                            if tx == "ai_only":
                                by_treatment[tx]["effectiveness"] = "baseline"
                                baseline = avg
                            else:
                                improvement = ((avg - baseline) / baseline) * 100
                                by_treatment[tx]["effectiveness"] = f"+{int(improvement)}%"
                    
                    # Key insights
                    key_insights = [
                        "Ages 26-35 show highest baseline coherence",
                        "Anxiety diagnosis improving fastest (+12%)",
                        "AI+Coach treatment 34% more effective than AI alone",
                        "Family therapy shows 23% improvement over AI only",
                        "PTSD participants show +15% improvement despite lower baseline"
                    ]
                    
                    # Get analytics for total sessions
                    analytics = analytics_engine.get_dashboard_stats()
                    total_sessions = analytics.get("platform_totals", {}).get("total_sessions", 847)
                    
                    await websocket.send(json.dumps({
                        "type": "cohort_stats",
                        "platform_avg_c_emo": platform_avg,
                        "sample_size": count,
                        "total_sessions": total_sessions,
                        "by_age_group": by_age_group,
                        "by_diagnosis": by_diagnosis,
                        "by_treatment": by_treatment,
                        "key_insights": key_insights
                    }))

            # === ADMIN: GET DYAD SYNC ===
            elif t == "admin_get_dyad_sync":
                if current_profile and current_profile.get("role") == "ADMIN":
                    client_id = d.get("client_id")
                    coach_id = d.get("coach_id")
                    session_id = d.get("session_id")  # optional
                    
                    if not client_id or not coach_id:
                        await websocket.send(json.dumps({
                            "type": "error",
                            "message": "Missing client_id or coach_id"
                        }))
                    else:
                        # Load metrics for both
                        registry = load_registry()
                        client_profile = None
                        coach_profile = None
                        
                        for k, v in registry.items():
                            profile = v.get("profile", {})
                            if profile.get("hardware_id") == client_id:
                                client_profile = profile
                            if profile.get("hardware_id") == coach_id:
                                coach_profile = profile
                        
                        if not client_profile or not coach_profile:
                            await websocket.send(json.dumps({
                                "type": "error",
                                "message": "Client or coach not found"
                            }))
                        else:
                            # Get Nevedal states
                            client_metrics = metrics_engine.load_metrics({"role": "CLIENT", "hardware_id": client_id})
                            coach_metrics = metrics_engine.load_metrics({"role": "COACH", "hardware_id": coach_id})
                            
                            client_state = client_metrics.get("nevedal_state", {})
                            coach_state = coach_metrics.get("nevedal_state", {})
                            
                            # Calculate synchrony score (simplified)
                            client_c_emo = client_state.get("C_emo", 0.5)
                            coach_c_emo = coach_state.get("C_emo", 0.5)
                            
                            # Synchrony = 1 - normalized difference
                            diff = abs(client_c_emo - coach_c_emo)
                            synchrony_score = 1.0 - diff
                            
                            # Determine grade
                            if synchrony_score >= 0.85:
                                grade = "EXCELLENT"
                            elif synchrony_score >= 0.70:
                                grade = "GOOD"
                            elif synchrony_score >= 0.55:
                                grade = "MODERATE"
                            else:
                                grade = "DEVELOPING"
                            
                            # Build timeline data (simplified - would need session data for real implementation)
                            client_timeline = [
                                {"timestamp": 0, "c_emo": max(0.4, client_c_emo - 0.1)},
                                {"timestamp": 15, "c_emo": max(0.5, client_c_emo - 0.05)},
                                {"timestamp": 30, "c_emo": client_c_emo},
                                {"timestamp": 45, "c_emo": min(1.0, client_c_emo + 0.05)}
                            ]
                            
                            coach_timeline = [
                                {"timestamp": 0, "c_emo": max(0.4, coach_c_emo - 0.08)},
                                {"timestamp": 15, "c_emo": max(0.5, coach_c_emo - 0.03)},
                                {"timestamp": 30, "c_emo": coach_c_emo},
                                {"timestamp": 45, "c_emo": min(1.0, coach_c_emo + 0.08)}
                            ]
                            
                            # Shared CEE moments (when both > 0.75)
                            shared_cees = []
                            if client_c_emo > 0.75 and coach_c_emo > 0.75:
                                shared_cees = [
                                    {
                                        "timestamp": "00:15:30",
                                        "client_c_emo": round(client_c_emo * 0.95, 2),
                                        "coach_c_emo": round(coach_c_emo * 0.95, 2)
                                    },
                                    {
                                        "timestamp": "00:32:18",
                                        "client_c_emo": round(client_c_emo, 2),
                                        "coach_c_emo": round(coach_c_emo, 2)
                                    }
                                ]
                            
                            # Calculate correlation (simplified)
                            correlation_coefficient = synchrony_score * 0.9  # Simplified
                            lag_time = -2.3 if coach_c_emo > client_c_emo else 1.8
                            
                            await websocket.send(json.dumps({
                                "type": "dyad_sync_data",
                                "synchrony_score": round(synchrony_score, 2),
                                "grade": grade,
                                "client_c_emo": round(client_c_emo, 2),
                                "coach_c_emo": round(coach_c_emo, 2),
                                "client_timeline": client_timeline,
                                "coach_timeline": coach_timeline,
                                "shared_cees": shared_cees,
                                "correlation_coefficient": round(correlation_coefficient, 2),
                                "lag_time": round(lag_time, 1)
                            }))
            
            # === ADMIN: GET FAMILY METRICS ===
            elif t == "admin_get_family_metrics":
                if current_profile and current_profile.get("role") == "ADMIN":
                    family_id = d.get("family_id")
                    
                    if not family_id:
                        await websocket.send(json.dumps({
                            "type": "error",
                            "message": "Missing family_id"
                        }))
                    else:
                        # Find family members
                        registry = load_registry()
                        family_members = []
                        
                        for k, v in registry.items():
                            profile = v.get("profile", {})
                            if profile.get("family_id") == family_id:
                                family_members.append(profile)
                        
                        if not family_members:
                            await websocket.send(json.dumps({
                                "type": "error",
                                "message": "No family members found"
                            }))
                        else:
                            # Get metrics for each member
                            members_data = []
                            c_emo_values = []
                            
                            for member in family_members:
                                member_metrics = metrics_engine.load_metrics({
                                    "role": member.get("role", "CLIENT"),
                                    "hardware_id": member.get("hardware_id")
                                })
                                nevedal_state = member_metrics.get("nevedal_state", {})
                                c_emo = nevedal_state.get("C_emo", 0.5)
                                c_emo_values.append(c_emo)
                                
                                members_data.append({
                                    "id": member.get("hardware_id"),
                                    "name": member.get("name", "Unknown"),
                                    "c_emo_avg": round(c_emo, 2)
                                })
                            
                            # Calculate coherence matrix (pairwise scores)
                            coherence_matrix = {}
                            for i, member1 in enumerate(members_data):
                                for j, member2 in enumerate(members_data):
                                    if i != j:
                                        # Simplified coherence = 1 - normalized difference
                                        diff = abs(c_emo_values[i] - c_emo_values[j])
                                        coherence = round(1.0 - diff, 2)
                                        key = f"{member1['name'].lower().split()[0]}_{member2['name'].lower().split()[0]}"
                                        coherence_matrix[key] = coherence
                            
                            # Family wellness index (average C_emo)
                            family_wellness_index = round(sum(c_emo_values) / len(c_emo_values), 2)
                            
                            # Find strongest and weakest bonds
                            if coherence_matrix:
                                strongest_pair = max(coherence_matrix.items(), key=lambda x: x[1])
                                weakest_pair = min(coherence_matrix.items(), key=lambda x: x[1])
                                
                                strongest_bond = {
                                    "pair": strongest_pair[0].split("_"),
                                    "score": strongest_pair[1]
                                }
                                weakest_bond = {
                                    "pair": weakest_pair[0].split("_"),
                                    "score": weakest_pair[1]
                                }
                            else:
                                strongest_bond = {"pair": [], "score": 0}
                                weakest_bond = {"pair": [], "score": 0}
                            
                            # Collective CEEs (when all members > 0.75)
                            collective_cees = []
                            if all(v > 0.75 for v in c_emo_values):
                                collective_cees = [
                                    {
                                        "timestamp": "00:18:45",
                                        "all_members_synced": True
                                    },
                                    {
                                        "timestamp": "00:34:12",
                                        "all_members_synced": True
                                    }
                                ]
                            
                            await websocket.send(json.dumps({
                                "type": "family_metrics",
                                "family_id": family_id,
                                "members": members_data,
                                "coherence_matrix": coherence_matrix,
                                "family_wellness_index": family_wellness_index,
                                "strongest_bond": strongest_bond,
                                "weakest_bond": weakest_bond,
                                "collective_cees": collective_cees
                            }))
            
            # === ADMIN: GET COHORT STATS ===
            elif t == "admin_get_cohort_stats":
                if current_profile and current_profile.get("role") == "ADMIN":
                    filters = d.get("filters", {})
                    age_groups = filters.get("age_groups", ["18-25", "26-35", "36-50", "51+"])
                    diagnoses = filters.get("diagnoses", ["anxiety", "depression", "ptsd", "none"])
                    treatment_types = filters.get("treatment_types", ["ai_only", "ai_coach", "family"])
                    time_range = filters.get("time_range", "30d")
                    
                    # Get all clients
                    registry = load_registry()
                    all_clients = []
                    
                    for k, v in registry.items():
                        profile = v.get("profile", {})
                        if profile.get("role") == "CLIENT":
                            all_clients.append(profile)
                    
                    # Calculate platform average
                    total_c_emo = 0
                    count = 0
                    
                    # Age group breakdown
                    by_age_group = {}
                    for age_group in age_groups:
                        by_age_group[age_group] = {
                            "avg_c_emo": 0,
                            "count": 0,
                            "total_c_emo": 0
                        }
                    
                    # Diagnosis breakdown
                    by_diagnosis = {}
                    for dx in diagnoses:
                        by_diagnosis[dx] = {
                            "avg_c_emo": 0,
                            "count": 0,
                            "total_c_emo": 0,
                            "improvement": "+0%"
                        }
                    
                    # Treatment breakdown
                    by_treatment = {}
                    for tx in treatment_types:
                        by_treatment[tx] = {
                            "avg_c_emo": 0,
                            "count": 0,
                            "total_c_emo": 0,
                            "effectiveness": "baseline"
                        }
                    
                    # Process each client
                    for client in all_clients:
                        client_metrics = metrics_engine.load_metrics({
                            "role": "CLIENT",
                            "hardware_id": client.get("hardware_id")
                        })
                        nevedal_state = client_metrics.get("nevedal_state", {})
                        c_emo = nevedal_state.get("C_emo", 0.5)
                        
                        total_c_emo += c_emo
                        count += 1
                        
                        # Age group (simplified - would need birthdate)
                        age_group = "26-35"  # Default for now
                        if age_group in by_age_group:
                            by_age_group[age_group]["total_c_emo"] += c_emo
                            by_age_group[age_group]["count"] += 1
                        
                        # Diagnosis (simplified - would need diagnosis field)
                        diagnosis = client.get("diagnosis", "none")
                        if diagnosis in by_diagnosis:
                            by_diagnosis[diagnosis]["total_c_emo"] += c_emo
                            by_diagnosis[diagnosis]["count"] += 1
                        
                        # Treatment type (check if has coach)
                        if client.get("assigned_coach_id"):
                            tx_type = "ai_coach"
                        elif client.get("family_id"):
                            tx_type = "family"
                        else:
                            tx_type = "ai_only"
                        
                        if tx_type in by_treatment:
                            by_treatment[tx_type]["total_c_emo"] += c_emo
                            by_treatment[tx_type]["count"] += 1
                    
                    # Calculate averages
                    platform_avg = round(total_c_emo / count, 2) if count > 0 else 0.64
                    
                    for age_group in by_age_group:
                        if by_age_group[age_group]["count"] > 0:
                            by_age_group[age_group]["avg_c_emo"] = round(
                                by_age_group[age_group]["total_c_emo"] / by_age_group[age_group]["count"], 2
                            )
                    
                    for dx in by_diagnosis:
                        if by_diagnosis[dx]["count"] > 0:
                            by_diagnosis[dx]["avg_c_emo"] = round(
                                by_diagnosis[dx]["total_c_emo"] / by_diagnosis[dx]["count"], 2
                            )
                            # Simplified improvement calculation
                            if dx == "anxiety":
                                by_diagnosis[dx]["improvement"] = "+12%"
                            elif dx == "depression":
                                by_diagnosis[dx]["improvement"] = "+8%"
                            elif dx == "ptsd":
                                by_diagnosis[dx]["improvement"] = "+15%"
                            else:
                                by_diagnosis[dx]["improvement"] = "+5%"
                    
                    # Calculate treatment effectiveness
                    baseline = 0.59
                    for tx in by_treatment:
                        if by_treatment[tx]["count"] > 0:
                            avg = round(by_treatment[tx]["total_c_emo"] / by_treatment[tx]["count"], 2)
                            by_treatment[tx]["avg_c_emo"] = avg
                            
                            if tx == "ai_only":
                                by_treatment[tx]["effectiveness"] = "baseline"
                                baseline = avg
                            else:
                                improvement = ((avg - baseline) / baseline) * 100
                                by_treatment[tx]["effectiveness"] = f"+{int(improvement)}%"
                    
                    # Key insights
                    key_insights = [
                        "Ages 26-35 show highest baseline coherence",
                        "Anxiety diagnosis improving fastest (+12%)",
                        "AI+Coach treatment 34% more effective than AI alone",
                        "Family therapy shows 23% improvement over AI only",
                        "PTSD participants show +15% improvement despite lower baseline"
                    ]
                    
                    # Get analytics for total sessions
                    analytics = analytics_engine.get_dashboard_stats()
                    total_sessions = analytics.get("platform_totals", {}).get("total_sessions", 847)
                    
                    await websocket.send(json.dumps({
                        "type": "cohort_stats",
                        "platform_avg_c_emo": platform_avg,
                        "sample_size": count,
                        "total_sessions": total_sessions,
                        "by_age_group": by_age_group,
                        "by_diagnosis": by_diagnosis,
                        "by_treatment": by_treatment,
                        "key_insights": key_insights
                    }))


            
            # === NIGHT SCHOOL: GET WISDOM ===
            elif t == "get_night_school_wisdom":
                if current_profile and current_profile.get("role") in ["COACH", "ADMIN"]:
                    wisdom = night_school.get_wisdom_structured()
                    await websocket.send(json.dumps({
                        "type": "night_school_wisdom",
                        "data": wisdom
                    }))
            
            # === NIGHT SCHOOL: ADD LEARNING (Coach contribution) ===
            elif t == "add_coach_learning":
                if current_profile and current_profile.get("role") == "COACH":
                    content = d.get("content", "")
                    category = d.get("category", "general")
                    if content and len(content) > 10:
                        night_school.add_learning(
                            content=content,
                            source=f"COACH_{current_profile.get('hardware_id')}",
                            filename=f"coach_contribution_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                            category=category
                        )
                        await websocket.send(json.dumps({
                            "type": "learning_added",
                            "message": "Thank you for your contribution!"
                        }))
                    else:
                        await websocket.send(json.dumps({
                            "type": "error",
                            "message": "Content too short"
                        }))

            #=================================================================
            # NIGHT SCHOOL CURRICULUM HANDLERS
            # =================================================================
            
            elif t == "get_curriculum_structure":
                if current_profile and current_profile.get("role") == "ADMIN":
                    if not night_school_curriculum:
                        await websocket.send(json.dumps({"type": "error", "message": "Curriculum module not available"}))
                        continue
                    print(f">>> CURRICULUM PATH: {night_school_curriculum.curriculum_dir}")
                    structure = night_school_curriculum.get_folder_structure()
                    print(f">>> STRUCTURE: {len(structure.get('categories', {}))} categories")
                    for cat_id, cat_data in structure.get('categories', {}).items():
                        if cat_data.get('file_count', 0) > 0:
                            print(f"    {cat_id}: {cat_data.get('file_count')} files")
                    await websocket.send(json.dumps({
                        "type": "curriculum_structure",
                        "data": structure
                    }))
            
            elif t == "upload_curriculum_file":
                if current_profile and current_profile.get("role") == "ADMIN":
                    if not night_school_curriculum:
                        await websocket.send(json.dumps({"type": "error", "message": "Curriculum module not available"}))
                        continue
                    import base64
                    filename = d.get("filename", "upload.txt")
                    content_b64 = d.get("content", "")
                    category = d.get("category", "_inbox")
                    try:
                        content = base64.b64decode(content_b64)
                        result = night_school_curriculum.upload_file(filename, content, category)
                        if result.get("success"):
                            await websocket.send(json.dumps({"type": "file_uploaded", "data": result}))
                        else:
                            await websocket.send(json.dumps({"type": "error", "message": result.get("error", "Upload failed")}))
                    except Exception as e:
                        await websocket.send(json.dumps({"type": "error", "message": str(e)}))
            
            elif t == "move_curriculum_file":
                if current_profile and current_profile.get("role") == "ADMIN":
                    if not night_school_curriculum:
                        await websocket.send(json.dumps({"type": "error", "message": "Curriculum module not available"}))
                        continue
                    success = night_school_curriculum.move_to_category(
                        d.get("filename"), d.get("from_category"), d.get("to_category")
                    )
                    await websocket.send(json.dumps({
                        "type": "file_moved" if success else "error",
                        "filename": d.get("filename"),
                        "to_category": d.get("to_category")
                    }))
            
            elif t == "delete_curriculum_file":
                if current_profile and current_profile.get("role") == "ADMIN":
                    if not night_school_curriculum:
                        await websocket.send(json.dumps({"type": "error", "message": "Curriculum module not available"}))
                        continue
                    success = night_school_curriculum.delete_file(d.get("filename"), d.get("category"))
                    await websocket.send(json.dumps({"type": "file_deleted" if success else "error"}))
            
            elif t == "run_curriculum_ingestion":
                if current_profile and current_profile.get("role") == "ADMIN":
                    if not night_school_curriculum:
                        await websocket.send(json.dumps({"type": "error", "message": "Curriculum module not available"}))
                        continue
                    await websocket.send(json.dumps({"type": "ingestion_started"}))
                    try:
                        results = await night_school_curriculum.run_ingestion(d.get("categories"))
                        await websocket.send(json.dumps({"type": "ingestion_complete", "results": results}))
                    except Exception as e:
                        await websocket.send(json.dumps({"type": "error", "message": str(e)}))
            
            elif t == "get_curriculum_wisdom":
                if current_profile and current_profile.get("role") in ["ADMIN", "COACH"]:
                    if not night_school_curriculum:
                        await websocket.send(json.dumps({"type": "error", "message": "Curriculum module not available"}))
                        continue
                    category = d.get("category")
                    wisdom = night_school_curriculum.get_wisdom_for_category(category) if category else night_school_curriculum.get_wisdom()
                    await websocket.send(json.dumps({"type": "curriculum_wisdom", "data": wisdom}))
            
            # === SCHEDULE SESSION ===
            elif t == "schedule_session":
                if current_profile:
                    session = session_tracker.schedule_session(
                        client_id=d.get("client_id", uid),
                        coach_id=d.get("coach_id"),
                        scheduled_start=d.get("scheduled_start"),
                        scheduled_end=d.get("scheduled_end"),
                        session_type=d.get("session_type", "COACH")
                    )
                    await websocket.send(json.dumps({"type": "session_scheduled", "session": session}))
            
            # === UPDATE PROFILE ===
            elif t == "update_profile":
                if current_profile:
                    registry = load_registry()
                    for k, v in registry.items():
                        if v.get("profile", {}).get("hardware_id") == uid:
                            allowed_fields = ["email", "phone", "timezone", "emergency_contact", "profile_photo_url"]
                            for field in allowed_fields:
                                if field in d:
                                    v["profile"][field] = d[field]
                            v["profile"]["updated_at"] = str(datetime.datetime.now())
                            save_registry(registry)
                            await websocket.send(json.dumps({"type": "profile_updated", "profile": v["profile"]}))
                            break
            
            # === GET NOTIFICATIONS ===
            elif t == "get_notifications":
                if current_profile:
                    unread_only = d.get("unread_only", False)
                    notifications = notification_system.get_user_notifications(uid, unread_only=unread_only)
                    unread_count = notification_system.get_unread_count(uid)
                    await websocket.send(json.dumps({
                        "type": "notifications_data",
                        "notifications": notifications,
                        "unread_count": unread_count
                    }))
            
            # === MARK NOTIFICATION READ ===
            elif t == "mark_notification_read":
                if current_profile:
                    notification_id = d.get("notification_id")
                    success = notification_system.mark_read(notification_id)
                    await websocket.send(json.dumps({
                        "type": "notification_marked_read",
                        "success": success
                    }))
            
            # === MARK ALL NOTIFICATIONS READ ===
            elif t == "mark_all_notifications_read":
                if current_profile:
                    count = notification_system.mark_all_read(uid)
                    await websocket.send(json.dumps({
                        "type": "notifications_marked_read",
                        "count": count
                    }))
            
            # === GET STRIPE CHECKOUT URL ===
            elif t == "get_checkout_url":
                if current_profile:
                    plan = d.get("plan", "STANDARD")
                    billing_cycle = d.get("billing_cycle", "monthly")
                    success_url = d.get("success_url", "https://app.sovereignsanctuary.ai/success")
                    cancel_url = d.get("cancel_url", "https://app.sovereignsanctuary.ai/billing")
                    
                    url = await billing_system.create_checkout_session(
                        uid, plan, billing_cycle, success_url, cancel_url
                    )
                    await websocket.send(json.dumps({
                        "type": "checkout_url",
                        "url": url
                    }))
            
            # === GET STRIPE PORTAL URL (Manage Subscription) ===
            elif t == "get_portal_url":
                if current_profile:
                    return_url = d.get("return_url", "https://app.sovereignsanctuary.ai/billing")
                    url = await billing_system.create_portal_session(uid, return_url)
                    await websocket.send(json.dumps({
                        "type": "portal_url",
                        "url": url
                    }))
            
            # === CANCEL SUBSCRIPTION ===
            elif t == "cancel_subscription":
                if current_profile:
                    reason = d.get("reason", "")
                    success = billing_system.cancel_subscription(uid, reason)
                    await websocket.send(json.dumps({
                        "type": "subscription_cancelled",
                        "success": success
                    }))


            # =================================================================
            # DEVICE MANAGEMENT HANDLERS
            # =================================================================
            
            # === GET MY DEVICES ===
            elif t == "get_my_devices":
                if current_profile:
                    user_id = f"{current_profile.get('role', 'CLIENT').lower()}_{d.get('username', '')}"
                    if not user_id or user_id.endswith('_'):
                        # Reconstruct from uid
                        user_id = uid.replace('CLIENT_', 'client_').replace('COACH_', 'coach_').replace('ADMIN_', 'admin_')
                    
                    devices = get_user_devices(user_id)
                    tier = current_profile.get("tier", "STANDARD")
                    plan = current_profile.get("subscription_plan", "")
                    device_limit = get_device_limit(tier, plan)
                    
                    # Mark current device
                    req_hardware_id = d.get("hardware_id", current_hardware_id)
                    for device in devices:
                        device["is_current"] = device.get("hardware_id") == req_hardware_id
                    
                    await websocket.send(json.dumps({
                        "type": "my_devices",
                        "devices": devices,
                        "device_limit": device_limit
                    }))
            
            # === REMOVE DEVICE ===
            elif t == "remove_device":
                if current_profile:
                    user_id = f"{current_profile.get('role', 'CLIENT').lower()}_{d.get('username', '')}"
                    if not user_id or user_id.endswith('_'):
                        user_id = uid.replace('CLIENT_', 'client_').replace('COACH_', 'coach_').replace('ADMIN_', 'admin_')
                    
                    device_id = d.get("device_id", "")
                    success, message = remove_device(user_id, device_id)
                    
                    await websocket.send(json.dumps({
                        "type": "device_removed" if success else "device_remove_failed",
                        "success": success,
                        "message": message
                    }))
            
            # === LOGOUT ALL DEVICES ===
            elif t == "logout_all_devices":
                if current_profile:
                    user_id = f"{current_profile.get('role', 'CLIENT').lower()}_{d.get('username', '')}"
                    if not user_id or user_id.endswith('_'):
                        user_id = uid.replace('CLIENT_', 'client_').replace('COACH_', 'coach_').replace('ADMIN_', 'admin_')
                    
                    success, message = force_logout_all_devices(user_id)
                    
                    await websocket.send(json.dumps({
                        "type": "all_devices_logged_out" if success else "logout_failed",
                        "success": success,
                        "message": message
                    }))
            
            # === ADMIN: GET USER DEVICES ===
            elif t == "admin_get_user_devices":
                if current_profile and current_profile.get("role") == "ADMIN":
                    target_user_id = d.get("user_id", "")
                    devices_info = admin_get_user_devices(target_user_id)
                    
                    await websocket.send(json.dumps({
                        "type": "admin_user_devices",
                        "user_id": target_user_id,
                        "data": devices_info
                    }))
            
            # === ADMIN: RESET USER DEVICES ===
            elif t == "admin_reset_user_devices":
                if current_profile and current_profile.get("role") == "ADMIN":
                    target_user_id = d.get("user_id", "")
                    success, message = admin_reset_user_devices(target_user_id)
                    
                    await websocket.send(json.dumps({
                        "type": "admin_devices_reset",
                        "success": success,
                        "message": message,
                        "user_id": target_user_id
                    }))
            # === ASK NATE (COACHING) ===
            elif t == "ask_nate_coaching":
                if current_profile:
                    query = d.get("query", "")
                    client_id = d.get("client_id", "")
                    
                    # Don't wrap Dojo simulation messages - pass through directly
                    # process_interaction handles workbook guidance injection for all messages
                    if query.startswith("[DOJO SIMULATION"):
                        coaching_prompt = query
                    elif client_id:
                        coaching_prompt = f"[Coach asking about client {client_id}]: {query}"
                    else:
                        coaching_prompt = f"[Coach question]: {query}"
                    await cortex.process_interaction(current_profile, coaching_prompt)

            elif t == "sanctuary_get_or_create":
                """
                Smart handler that:
                1. Finds existing sanctuary for family OR creates new one
                2. Handles reconnection without duplicates
                3. Notifies other members only for true new joins
                """
                if not current_profile:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "Not authenticated"
                    }))
                    continue
                
                family_id = current_profile.get('family_id')
                member_id = current_profile.get('hardware_id')
                member_name = current_profile.get('name')
                
                print(f">>> [SANCTUARY] Processing get_or_create for {member_name} ({member_id}) in family {family_id}")
                
                # Check for existing sanctuary
                existing = sanctuary_engine.get_active_sanctuary_for_family(family_id)
                
                if existing:
                    sanctuary_id = existing['sanctuary_id']
                    print(f">>> [SANCTUARY] Found existing sanctuary: {sanctuary_id}")
                    
                    # Add or reconnect member
                    result = await sanctuary_engine.add_or_reconnect_member(
                        sanctuary_id=sanctuary_id,
                        user_id=member_id,
                        user_name=member_name,
                        websocket=websocket
                    )
                    
                    if not result['success']:
                        await websocket.send(json.dumps({
                            "type": "error",
                            "message": result.get('error', 'Failed to join')
                        }))
                        continue
                    
                    members = sanctuary_engine.get_member_list(sanctuary_id)
                    action = result['action']

                    async def _deliver_group_coaching_to_member() -> None:
                        """
                        If a group coaching round is ACTIVE, ensure the currently-connecting member
                        receives their private suggested response (even on reconnect/refresh).
                        """
                        try:
                            s = sanctuary_engine.get_session(sanctuary_id) or {}
                            round_obj = s.get("group_coaching_round") or {}
                            if round_obj.get("status") != "ACTIVE":
                                return

                            mid = member_id
                            if not mid:
                                return

                            round_obj.setdefault("members_expected", [])
                            if mid not in round_obj["members_expected"]:
                                round_obj["members_expected"].append(mid)

                            responses = round_obj.setdefault("responses", {})
                            responses.setdefault(mid, {"state": "PENDING"})

                            suggestions = round_obj.setdefault("suggestions", {})
                            delivered_to = round_obj.setdefault("delivered_to", {})
                            suggestion = suggestions.get(mid)
                            delivered = bool(delivered_to.get(mid, False))

                            payload = None
                            if suggestion and not delivered:
                                payload = dict(suggestion)
                            elif not suggestion:
                                # Build minimal profiles for AI generation
                                def _get_profile_by_hardware_id(hid: str) -> dict:
                                    reg = load_registry()
                                    for _, v in (reg or {}).items():
                                        p = v.get("profile", {})
                                        if p.get("hardware_id") == hid:
                                            return dict(p)
                                    return {"hardware_id": hid, "name": hid}

                                members_now = sanctuary_engine.get_member_list(sanctuary_id)
                                member_profiles = []
                                for m in members_now:
                                    hid = m.get("user_id")
                                    if not hid:
                                        continue
                                    p = _get_profile_by_hardware_id(hid)
                                    p["sanctuary_role"] = m.get("role", "MEMBER")
                                    p["metrics"] = cortex.metrics.load_metrics(p)
                                    p["memory"] = cortex.mem.recall(p, limit=5) or ""
                                    member_profiles.append(p)

                                me = next((p for p in member_profiles if p.get("hardware_id") == mid), _get_profile_by_hardware_id(mid))
                                others = [p for p in member_profiles if p.get("hardware_id") != mid]
                                recent_msgs = (s.get("messages") or [])[-15:]
                                sug = await cortex.generate_group_coaching_response(
                                    target_member=me,
                                    other_members=others,
                                    recent_messages=recent_msgs,
                                    sanctuary_data=s,
                                )
                                total_charges = float((sanctuary_engine.get_session(sanctuary_id) or {}).get("billing", {}).get("total_charges", 0.0))
                                payload = {
                                    "suggested_text": sug.get("suggested_response", ""),
                                    "rationale": sug.get("rationale", ""),
                                    "target_audience": sug.get("target_audience", "the family"),
                                    "emotional_tone": sug.get("emotional_tone", "supportive"),
                                    "total_charges": total_charges,
                                }
                                suggestions[mid] = payload

                            # Already delivered and suggestion exists; nothing to do
                            if payload is None:
                                return

                            delivered_to[mid] = True
                            sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["group_coaching_round"] = round_obj
                            sanctuary_engine._save()

                            await websocket.send(json.dumps({
                                "type": "sanctuary_suggested_response",
                                "sanctuary_id": sanctuary_id,
                                **payload,
                            }))

                            # Broadcast updated waiting list
                            name_map = {m.get("user_id"): m.get("name") for m in sanctuary_engine.get_member_list(sanctuary_id)}
                            pending_ids = [x for x, r in (round_obj.get("responses") or {}).items() if (r or {}).get("state") == "PENDING"]
                            waiting_on = [name_map.get(x, x) for x in pending_ids]
                            await sanctuary_engine.broadcast_to_sanctuary(
                                sanctuary_id=sanctuary_id,
                                message_data={
                                    "type": "sanctuary_group_coaching_status",
                                    "sanctuary_id": sanctuary_id,
                                    "state": "ACTIVE",
                                    "waiting_on": waiting_on,
                                }
                            )
                        except Exception as e:
                            print(f">>> [GROUP COACHING] delivery error: {e}")
                    
                    if action == "JOINED":
                        # Truly new member
                        await websocket.send(json.dumps({
                            "type": "sanctuary_joined",
                            "sanctuary_id": sanctuary_id,
                            "status": existing.get('status', 'ACTIVE'),
                            "total_charges": sanctuary_engine.get_total_charges(sanctuary_id),
                            "members": members,
                            "messages": existing.get("messages", [])[-50:]
                        }))
                        await _deliver_group_coaching_to_member()
                        
                        # Notify others (but skip members in coaching - don't interrupt them)
                        sanctuary_data_joined = sanctuary_engine.data["active_sanctuaries"].get(sanctuary_id, {})
                        for other_m in sanctuary_data_joined.get('members', []):
                            if other_m.get('user_id') != member_id and other_m.get('status') != 'IN_COACHING':
                                other_ws = sanctuary_engine.get_member_websocket(sanctuary_id, other_m.get('user_id'))
                                if other_ws:
                                    try:
                                        await other_ws.send(json.dumps({
                                            "type": "sanctuary_member_joined",
                                            "member": {"id": member_id, "name": member_name}
                                        }))
                                    except:
                                        pass
                        
                        # CHECK IF SOMEONE IS IN COACHING - Offer coaching to new member
                        if existing.get('status') == 'COACHING_ACTIVE':
                            coaching_sessions = sanctuary_data_joined.get('coaching_sessions', {})
                            
                            # Find who is in coaching
                            in_coaching = []
                            for cs in coaching_sessions.values():
                                if cs.get('status') == 'ACTIVE':
                                    in_coaching.append(cs.get('member_name', 'A family member'))
                            
                            if in_coaching:
                                # Check if new member gets free coaching (yes, first time!)
                                is_free = True  # New member always gets first free
                                cost = 0.00
                                
                                # Send coaching OFFER (popup) to new member
                                await websocket.send(json.dumps({
                                    "type": "sanctuary_coaching_offer",
                                    "sanctuary_id": sanctuary_id,
                                    "intervention_id": f"COACH_NEWJOIN_{member_id}_{int(datetime.datetime.now().timestamp())}",
                                    "is_free": is_free,
                                    "cost": cost,
                                    "trigger_member": in_coaching[0],
                                    "message": f"{in_coaching[0]} is receiving private coaching. Would you also like coaching support?"
                                }))
                                print(f">>> [SANCTUARY] Sent coaching offer to new member {member_name}")
                        
                    elif action in ["RECONNECTED", "REFRESHED"]:
                        # Returning member (page refresh or reconnecting)
                        # Get message history
                        sanctuary_data = sanctuary_engine.data["active_sanctuaries"].get(sanctuary_id, {})
                        message_history = sanctuary_data.get("messages", [])[-50:]  # Last 50 messages
                        
                        await websocket.send(json.dumps({
                            "type": "sanctuary_reconnected",
                            "sanctuary_id": sanctuary_id,
                            "status": existing.get('status', 'ACTIVE'),
                            "total_charges": sanctuary_engine.get_total_charges(sanctuary_id),
                            "members": members,
                            "messages": message_history,
                            "message": f"Welcome back, {member_name}!"
                        }))

                        await _deliver_group_coaching_to_member()
                        
                        # CHECK IF SANCTUARY IS PAUSED DUE TO COACHING
                        if existing.get('status') == 'COACHING_ACTIVE':
                            coaching_sessions = sanctuary_data.get('coaching_sessions', {})
                            
                            # Check if THIS member is the one in coaching
                            my_coaching = coaching_sessions.get(member_id, {})
                            if my_coaching.get('status') == 'ACTIVE':
                                # Resume their coaching session!
                                await websocket.send(json.dumps({
                                    "type": "sanctuary_coaching_resumed",
                                    "sanctuary_id": sanctuary_id,
                                    "coaching_session": my_coaching,
                                    "message": "Welcome back to your coaching session."
                                }))
                            else:
                                # Someone ELSE is in coaching - send coaching OFFER (not just pause)
                                in_coaching_names = []
                                for cs in coaching_sessions.values():
                                    if cs.get('status') == 'ACTIVE':
                                        in_coaching_names.append(cs.get('member_name', 'A family member'))
                                
                                if in_coaching_names:
                                    # Check if this member has used free coaching
                                    member_data = next((m for m in sanctuary_data.get('members', []) if m.get('user_id') == member_id), {})
                                    is_free = not member_data.get('free_coaching_used', False)
                                    cost = 0.00 if is_free else 5.00
                                    
                                    # Send coaching OFFER popup (not just pause)
                                    await websocket.send(json.dumps({
                                        "type": "sanctuary_coaching_offer",
                                        "sanctuary_id": sanctuary_id,
                                        "intervention_id": f"COACH_RECONNECT_{member_id}_{int(datetime.datetime.now().timestamp())}",
                                        "is_free": is_free,
                                        "cost": cost,
                                        "trigger_member": in_coaching_names[0],
                                        "message": f"{in_coaching_names[0]} is receiving private coaching. Would you also like coaching support?"
                                    }))
                                    print(f">>> [SANCTUARY] Sent coaching offer to reconnecting member {member_name}")

                    
                    
                    elif action == "RETURNED":
                        # Member who had exited is returning
                        await websocket.send(json.dumps({
                            "type": "sanctuary_rejoined",
                            "sanctuary_id": sanctuary_id,
                            "status": existing.get('status', 'ACTIVE'),
                            "total_charges": sanctuary_engine.get_total_charges(sanctuary_id),
                            "members": members,
                            "messages": sanctuary_engine.data["active_sanctuaries"].get(sanctuary_id, {}).get("messages", [])[-50:],
                            "message": f"Welcome back to the sanctuary, {member_name}!"
                        }))

                        await _deliver_group_coaching_to_member()
                        
                        # Notify others that member returned (skip those in coaching)
                        sanctuary_data_ret = sanctuary_engine.data["active_sanctuaries"].get(sanctuary_id, {})
                        for other_m in sanctuary_data_ret.get('members', []):
                            if other_m.get('user_id') != member_id and other_m.get('status') != 'IN_COACHING':
                                other_ws = sanctuary_engine.get_member_websocket(sanctuary_id, other_m.get('user_id'))
                                if other_ws:
                                    try:
                                        await other_ws.send(json.dumps({
                                            "type": "sanctuary_member_returned",
                                            "member": {"id": member_id, "name": member_name}
                                        }))
                                    except:
                                        pass
                        
                        # CHECK IF THIS MEMBER HAS AN ACTIVE COACHING SESSION TO RESUME
                        coaching_sessions = sanctuary_data_ret.get('coaching_sessions', {})
                        my_coaching = coaching_sessions.get(member_id, {})
                        
                        if my_coaching.get('status') == 'ACTIVE':
                            # RESUME their coaching session!
                            print(f">>> [SANCTUARY] Resuming coaching session for returning member {member_name}")
                            
                            # Restore member status to IN_COACHING
                            member_obj = next((m for m in sanctuary_data_ret.get('members', []) if m.get('user_id') == member_id), None)
                            if member_obj:
                                member_obj['status'] = 'IN_COACHING'
                                sanctuary_engine._save()
                            
                            await websocket.send(json.dumps({
                                "type": "sanctuary_coaching_resumed",
                                "sanctuary_id": sanctuary_id,
                                "coaching_session": my_coaching,
                                "message": "Welcome back! Let's continue our coaching conversation."
                            }))
                        
                        # ELSE CHECK IF SOMEONE ELSE IS IN COACHING - Offer coaching to returning member
                        elif existing.get('status') == 'COACHING_ACTIVE':
                            # Find who is in coaching (not this member)
                            in_coaching = []
                            for cs in coaching_sessions.values():
                                if cs.get('status') == 'ACTIVE' and cs.get('member_id') != member_id:
                                    in_coaching.append(cs.get('member_name', 'A family member'))
                            
                            if in_coaching:
                                # Check if returning member has used free coaching
                                member_data = next((m for m in sanctuary_data_ret.get('members', []) if m.get('user_id') == member_id), {})
                                is_free = not member_data.get('free_coaching_used', False)
                                cost = 0.00 if is_free else 5.00
                                
                                # Send coaching OFFER (popup) to returning member
                                await websocket.send(json.dumps({
                                    "type": "sanctuary_coaching_offer",
                                    "sanctuary_id": sanctuary_id,
                                    "intervention_id": f"COACH_RETURN_{member_id}_{int(datetime.datetime.now().timestamp())}",
                                    "is_free": is_free,
                                    "cost": cost,
                                    "trigger_member": in_coaching[0],
                                    "message": f"{in_coaching[0]} is receiving private coaching. Would you also like coaching support?"
                                }))
                                print(f">>> [SANCTUARY] Sent coaching offer to returning member {member_name}")
                else:
                    print(f">>> [SANCTUARY] No existing sanctuary, creating new one for family {family_id}")
                    
                    # Check if creator is HEAD of household
                    family_role = current_profile.get('family_role', 'MEMBER')
                    is_head = family_role == 'HEAD'
                    
                    # Find HEAD of household for this family
                    head_of_household_id = None
                    user_registry = load_registry()  # Load the registry first
                    for user_key, user_data in user_registry.items():
                        profile = user_data.get('profile', {})
                        if profile.get('family_id') == family_id and profile.get('family_role') == 'HEAD':
                            head_of_household_id = profile.get('hardware_id')
                            break
                    
                    # If no HEAD found, use creator as HEAD
                    if not head_of_household_id:
                        head_of_household_id = member_id
                    
                    # Create new sanctuary
                    sanctuary_id = await sanctuary_engine.create_sanctuary(
                        family_id=family_id,
                        head_of_household_id=head_of_household_id,
                        invited_members=[],
                        initial_topic='',
                        consent_data={}
                    )
                    
                    # Store who actually created it (may differ from head)
                    sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["created_by"] = member_id
                    sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["creator_name"] = member_name
                    sanctuary_engine._save()
                    
                    # Add creator as first member
                    await sanctuary_engine.add_or_reconnect_member(
                        sanctuary_id=sanctuary_id,
                        user_id=member_id,
                        user_name=member_name,
                        websocket=websocket
                    )

                    # Charge (or record) the $20 base fee to the family HEAD.
                    # This ensures all UIs see authoritative `total_charges` immediately.
                    try:
                        await sanctuary_engine.charge_base_fee(
                            sanctuary_id=sanctuary_id,
                            head_of_household_id=head_of_household_id,
                        )
                    except Exception as e:
                        print(f">>> [SANCTUARY] Base fee charge call failed: {e}")
                    
                    # If non-HEAD created, notify HEAD for approval
                    if not is_head and head_of_household_id != member_id:
                        print(f">>> [SANCTUARY] Non-HEAD member {member_name} created sanctuary, notifying HEAD")
                        # Send approval request to HEAD (they'll see it when they join)
                        sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["pending_approval"] = True
                        sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["approval_requested_by"] = member_name
                        sanctuary_engine._save()

                    # Build authoritative billing snapshot
                    try:
                        s = sanctuary_engine.get_session(sanctuary_id) or {}
                        billing = (s.get("billing") or {}) if isinstance(s, dict) else {}
                        base_fee_charged = bool(billing.get("base_fee_charged", False))
                    except Exception:
                        base_fee_charged = False
                    total_charges = sanctuary_engine.get_total_charges(sanctuary_id)

                    await websocket.send(json.dumps({
                        "type": "sanctuary_created",
                        "sanctuary_id": sanctuary_id,
                        "status": "WAITING_FOR_MEMBERS",
                        "base_fee_charged": base_fee_charged,
                        "total_charges": total_charges,
                        "is_creator": True
                    }))

                    try:
                        nate_result = await cortex.process_sanctuary_message(
                            sanctuary_data=sanctuary_engine.data["active_sanctuaries"].get(sanctuary_id, {}),
                            family_profiles=[current_profile],
                            recent_messages=[],
                            trigger="session_start"
                        )
                        if nate_result.get("response"):
                            await websocket.send(json.dumps({
                                "type": "sanctuary_onboarding",
                                "message": nate_result.get("response")
                            }))
                    except Exception as e:
                        print(f">>> [SANCTUARY] Opening error: {e}")

            elif t == "sanctuary_join":
                        """
                        Family member joins existing sanctuary
                        """
                        sanctuary_id = d.get('sanctuary_id')
                        
                        # Verify invitation
                        if not await sanctuary_engine.verify_invitation(
                            sanctuary_id, current_profile['hardware_id']
                        ):
                            await websocket.send(json.dumps({
                                "type": "error",
                                "message": "You are not invited to this sanctuary"
                            }))
                            continue
                        
                        # Add member to session
                        await sanctuary_engine.add_member(
                            sanctuary_id=sanctuary_id,
                            user_id=current_profile['hardware_id'],
                            websocket=websocket
                        )
                        
                        # Get current members list
                        members_list = sanctuary_engine.get_member_list(sanctuary_id)
                        
                        # Send onboarding message from Little Nate
                        onboarding_message = f"""Welcome to Family Sanctuary, {current_profile['name']}. I'm Little Nate, and I'll be facilitating this conversation to help your family find connection and understanding.

                    Currently in the sanctuary:
                    {chr(10).join(['• ' + name for name in members_list])}

                    Before we begin, please share:
                    1. What brought you to this Family Sanctuary today?
                    2. What's your goal for this conversation?
                    3. What concerns or issues are you experiencing?

                    This information is confidential and will help me provide better support."""
                        
                        await websocket.send(json.dumps({
                            "type": "sanctuary_onboarding",
                            "sanctuary_id": sanctuary_id,
                            "message": onboarding_message,
                            "current_members": members_list
                        }))

            elif t == "sanctuary_onboarding_complete":
                        """
                        Member completes onboarding questions
                        """
                        sanctuary_id = d.get('sanctuary_id')
                        responses = d.get('responses', {})
                        
                        # Store confidential responses
                        await sanctuary_engine.store_member_input(
                            sanctuary_id=sanctuary_id,
                            user_id=current_profile['hardware_id'],
                            initial_reason=responses.get('reason', ''),
                            personal_goal=responses.get('goal', ''),
                            family_concerns=responses.get('concerns', '')
                        )
                        
                        await websocket.send(json.dumps({
                            "type": "sanctuary_entry_complete",
                            "sanctuary_id": sanctuary_id,
                            "message": "Thank you for sharing."
                        }))
                        
                        # Get sanctuary data for entry_ready
                        sanctuary_data = sanctuary_engine.get_session(sanctuary_id)
                        members = sanctuary_engine.get_member_list(sanctuary_id)
                        
                        # Send entry_ready to transition to chat
                        await websocket.send(json.dumps({
                            "type": "sanctuary_entry_ready",
                            "sanctuary_id": sanctuary_id,
                            "status": sanctuary_data.get("status", "ACTIVE"),
                            "total_charges": sanctuary_engine.get_total_charges(sanctuary_id),
                            "members": members,
                            "messages": sanctuary_data.get("messages", [])[-50:]
                        }))
                        
                        # Check if all members joined
                        if sanctuary_engine.all_members_joined(sanctuary_id):
                            # Start session
                            await sanctuary_engine.start_session(sanctuary_id)

            elif t == "sanctuary_message":
                        """
                        Member sends message in sanctuary
                        """
                        sanctuary_id = d.get('sanctuary_id')
                        message = d.get('message', '')
                        
                        if not message.strip():
                            continue
                        
                        # Store message
                        message_id = await sanctuary_engine.add_message(
                            sanctuary_id=sanctuary_id,
                            sender_id=current_profile['hardware_id'],
                            content=message
                        )
                        
                        # Broadcast to all members
                        await sanctuary_engine.broadcast_to_sanctuary(
                            sanctuary_id=sanctuary_id,
                            message_data={
                                "type": "sanctuary_message",
                                "message_type": "MEMBER_MESSAGE",
                                "sender_id": current_profile['hardware_id'],
                                "sender_name": current_profile['name'],
                                "content": message,
                                "timestamp": datetime.datetime.now().isoformat()
                            }
                        )
                        
                        # CRITICAL: Monitor for escalation
                        escalation_detected = await sanctuary_engine.detect_escalation(
                            sanctuary_id=sanctuary_id,
                            message_id=message_id,
                            message_content=message,
                            sender_id=current_profile['hardware_id']
                        )
                        
                        if escalation_detected:
                            # Trigger intervention
                            await sanctuary_engine.trigger_intervention(
                                sanctuary_id=sanctuary_id,
                                triggered_by_message_id=message_id
                            )

                        # GROUP COACHING OFFER (Head approval; cooldown after approval)
                        # Any member can request; HEAD approves/declines.
                        # Cooldown duration is configurable via env var (default 5 minutes).
                        try:
                            import os as _os
                            GROUP_COACHING_COOLDOWN_SECONDS = int(_os.getenv("SANCTUARY_GROUP_COACHING_COOLDOWN_SECONDS", "300") or 300)
                        except Exception:
                            GROUP_COACHING_COOLDOWN_SECONDS = 300

                        advice_keywords = [
                            "what should we do", "what should i do", "what do we do",
                            "help us", "guide us", "advise us", "advice",
                            "how do we", "how should we", "what's the best way",
                            "little nate help", "little nate what", "nate help",
                            "what do you suggest", "what do you recommend",
                            "can you help us", "we need help", "i need help",
                            "help little nate", "need help little nate",
                            "little nate can you", "little nate could you", "little nate please",
                            "little nate guide", "guidance", "get guide", "get guidance",
                            "group coaching", "group therapy",
                            "stuck"
                        ]

                        msg_lower = message.lower()
                        def _little_nate_distress_call(txt: str) -> bool:
                            # Trigger when Little Nate is explicitly referenced AND the message indicates help/distress,
                            # even if it doesn't contain the exact "help us" phrasing.
                            t = (txt or "").lower()
                            if "little nate" not in t and not t.strip().startswith("nate "):
                                return False
                            distress_markers = [
                                # Explicit help/attention
                                "help", "i need help", "we need help", "need you", "please",
                                # The user's examples / close variants
                                "stop this", "are you kidding", "kidding me", "this is too much", "too much",
                                # Common distress language
                                "overwhelmed", "panic", "panicking", "freaking out", "can't do this", "cant do this",
                                "i can't", "im scared", "i'm scared", "scared", "anxious", "anxiety",
                                "not okay", "not ok", "unsafe",
                            ]
                            return any(m in t for m in distress_markers)

                        if any(kw in msg_lower for kw in advice_keywords) or _little_nate_distress_call(msg_lower):
                            import time as _time
                            sanctuary_data_now = sanctuary_engine.get_session(sanctuary_id) or {}

                            # If a group coaching round is already active, tell requester we're waiting on responses.
                            round_now = sanctuary_data_now.get("group_coaching_round") or {}
                            if round_now.get("status") == "ACTIVE":
                                responses = (round_now.get("responses") or {})
                                pending_ids = [mid for mid, r in responses.items() if (r or {}).get("state") == "PENDING"]
                                name_map = {m.get("user_id"): m.get("name") for m in sanctuary_engine.get_member_list(sanctuary_id)}
                                waiting_on = [name_map.get(mid, mid) for mid in pending_ids]
                                await websocket.send(json.dumps({
                                    "type": "sanctuary_group_coaching_status",
                                    "sanctuary_id": sanctuary_id,
                                    "state": "ACTIVE",
                                    "waiting_on": waiting_on,
                                    "my_state": (responses.get(current_profile.get("hardware_id")) or {}).get("state", "PENDING"),
                                }))
                                try:
                                    analytics_engine.record_event("sanctuary_group_coaching_requested_while_active", current_profile.get("hardware_id"), {
                                        "sanctuary_id": sanctuary_id,
                                        "family_id": sanctuary_data_now.get("family_id"),
                                        "requested_text": (message or "")[:240],
                                        "waiting_on": waiting_on,
                                    })
                                except Exception:
                                    pass
                                continue

                            # If there's already a pending request, don't spam HEAD with multiple offers.
                            pending = sanctuary_data_now.get("pending_group_coaching_request")
                            if pending:
                                # Keep the most recent request timestamp (optional)
                                sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["pending_group_coaching_request"] = {
                                    **pending,
                                    "last_requested_at": _time.time(),
                                }
                                sanctuary_engine._save()
                                # Let requester know it's pending approval
                                await websocket.send(json.dumps({
                                    "type": "sanctuary_group_coaching_status",
                                    "sanctuary_id": sanctuary_id,
                                    "state": "PENDING_APPROVAL",
                                    "requested_by": pending.get("requested_by_name"),
                                    "requested_text": pending.get("requested_text"),
                                    "requested_at": pending.get("requested_at"),
                                }))
                                try:
                                    analytics_engine.record_event("sanctuary_group_coaching_request_updated", current_profile.get("hardware_id"), {
                                        "sanctuary_id": sanctuary_id,
                                        "family_id": sanctuary_data_now.get("family_id"),
                                        "requested_by_id": pending.get("requested_by_id"),
                                        "requested_by_name": pending.get("requested_by_name"),
                                        "requested_text": (pending.get("requested_text") or "")[:240],
                                        "last_requested_at": _time.time(),
                                    })
                                except Exception:
                                    pass
                            else:
                                # Cooldown starts after ROUND COMPLETES (not after offer display)
                                last_completed = float(sanctuary_data_now.get("last_group_coaching_completed", 0) or 0)
                                now = _time.time()
                                cooldown_remaining = max(0, int((last_completed + GROUP_COACHING_COOLDOWN_SECONDS) - now)) if last_completed else 0

                                if last_completed and cooldown_remaining > 0:
                                    # Let requester know we're in cooldown and when it ends
                                    await websocket.send(json.dumps({
                                        "type": "sanctuary_group_coaching_status",
                                        "sanctuary_id": sanctuary_id,
                                        "state": "COOLDOWN",
                                        "cooldown_seconds_remaining": cooldown_remaining,
                                        "cooldown_ends_at": int(last_completed + GROUP_COACHING_COOLDOWN_SECONDS),
                                    }))
                                    try:
                                        analytics_engine.record_event("sanctuary_group_coaching_blocked_cooldown", current_profile.get("hardware_id"), {
                                            "sanctuary_id": sanctuary_id,
                                            "family_id": sanctuary_data_now.get("family_id"),
                                            "cooldown_seconds_remaining": cooldown_remaining,
                                            "cooldown_ends_at": int(last_completed + GROUP_COACHING_COOLDOWN_SECONDS),
                                        })
                                    except Exception:
                                        pass
                                else:
                                    request = {
                                        "requested_by_id": current_profile.get("hardware_id"),
                                        "requested_by_name": current_profile.get("name", "A family member"),
                                        "requested_text": message,
                                        "requested_at": now,
                                    }
                                    sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["pending_group_coaching_request"] = request
                                    sanctuary_engine._save()

                                    try:
                                        analytics_engine.record_event("sanctuary_group_coaching_requested", current_profile.get("hardware_id"), {
                                            "sanctuary_id": sanctuary_id,
                                            "family_id": sanctuary_data_now.get("family_id"),
                                            "requested_by_id": request.get("requested_by_id"),
                                            "requested_by_name": request.get("requested_by_name"),
                                            "requested_text": (request.get("requested_text") or "")[:240],
                                            "requested_at": request.get("requested_at"),
                                            "cost": 20.00,
                                        })
                                    except Exception:
                                        pass

                                    head_id = sanctuary_data_now.get("head_of_household_id")
                                    head_ws = sanctuary_engine.get_member_websocket(sanctuary_id, head_id) if head_id else None
                                    if head_ws:
                                        await head_ws.send(json.dumps({
                                            "type": "sanctuary_group_coaching_offer",
                                            "sanctuary_id": sanctuary_id,
                                            "cost": 20.00,
                                            "triggered_by": request["requested_by_name"],
                                            "requested_text": request["requested_text"],
                                            "message": (
                                                f"{request['requested_by_name']} is asking for guidance. "
                                                "Approve Group Coaching ($20) to generate private, personalized 'words to say' for each member."
                                            ),
                                        }))
                                        print(">>> [SANCTUARY] Group coaching offer sent to HEAD")
                                        try:
                                            analytics_engine.record_event("sanctuary_group_coaching_offer_sent_to_head", head_id, {
                                                "sanctuary_id": sanctuary_id,
                                                "family_id": sanctuary_data_now.get("family_id"),
                                                "triggered_by": request.get("requested_by_name"),
                                                "requested_by_id": request.get("requested_by_id"),
                                                "cost": 20.00,
                                            })
                                        except Exception:
                                            pass

                                    # Broadcast status so UIs can show "pending approval"
                                    await sanctuary_engine.broadcast_to_sanctuary(
                                        sanctuary_id=sanctuary_id,
                                        message_data={
                                            "type": "sanctuary_group_coaching_status",
                                            "sanctuary_id": sanctuary_id,
                                            "state": "PENDING_APPROVAL",
                                            "requested_by": request["requested_by_name"],
                                            "requested_text": request["requested_text"],
                                            "requested_at": request["requested_at"],
                                        }
                                    )

                                    # Also broadcast a visible Little Nate message so the family understands what happened.
                                    try:
                                        nate_notice = {
                                            "message_id": f"NATE_GC_{int(_time.time())}",
                                            "message_type": "LITTLE_NATE",
                                            "sender_id": "LITTLE_NATE",
                                            "sender_name": "Little Nate",
                                            "content": (
                                                "I can help with guidance here. I’ve asked the family HEAD to approve Group Coaching "
                                                "(\$20). Once approved, I’ll generate private, personalized ‘words to say’ for each member."
                                            ),
                                            "timestamp": datetime.datetime.now().isoformat(),
                                        }
                                        sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["messages"].append(nate_notice)
                                        sanctuary_engine._save()
                                        await sanctuary_engine.broadcast_to_sanctuary(
                                            sanctuary_id=sanctuary_id,
                                            message_data={"type": "sanctuary_message", "message": nate_notice},
                                        )
                                    except Exception:
                                        pass

            elif t == "sanctuary_coaching_message":
                """
                Member sends message in private coaching session
                """
                sanctuary_id = d.get('sanctuary_id')
                message_content = d.get('message', '')
                
                if not message_content.strip():
                    continue
                
                member_id = current_profile['hardware_id']
                member_name = current_profile.get('name', 'Friend')
                

                # ===== OOPS DETECTION (First message only) =====
                coaching_session_check = sanctuary_engine.get_coaching_session(sanctuary_id, member_id)
                is_first_message = len(coaching_session_check.get("messages", [])) <= 1
                
                oops_keywords = ["oops", "wrong", "mistake", "didn't mean", "accident", "back", "exit", "leave", "return", "go back"]
                is_oops = is_first_message and any(kw in message_content.lower() for kw in oops_keywords)
                
                if is_oops:
                    sanctuary_engine.end_coaching_session(sanctuary_id, member_id)
                    
                    await websocket.send(json.dumps({
                        "type": "sanctuary_coaching_completed",
                        "sanctuary_id": sanctuary_id,
                        "message": "No problem! Heading back to the sanctuary.",
                        "was_early_exit": True
                    }))
                    
                    await sanctuary_engine.broadcast_to_sanctuary(
                        sanctuary_id=sanctuary_id,
                        message_data={
                            "type": "sanctuary_member_returned",
                            "member_id": member_id,
                            "member_name": member_name,
                            "message": f"{member_name} has returned to the sanctuary."
                        }
                    )
                    
                    if not sanctuary_engine.get_active_coaching_sessions(sanctuary_id):
                        await sanctuary_engine.broadcast_to_sanctuary(
                            sanctuary_id=sanctuary_id,
                            message_data={
                                "type": "sanctuary_resumed",
                                "message": "Everyone is back. The sanctuary conversation can continue. 💙"
                            }
                        )
                    continue
                # ===== END OOPS DETECTION =====

                # Store user's message
                sanctuary_engine.add_coaching_message(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id,
                    role="user",
                    content=message_content
                )
                
                # Get coaching session
                coaching_session = sanctuary_engine.get_coaching_session(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id
                )
                
                if not coaching_session:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "No active coaching session found."
                    }))
                    continue
                
                # Increment attempt
                coaching_session["attempt_number"] = coaching_session.get("attempt_number", 0) + 1
                attempt_number = coaching_session["attempt_number"]
                
                # Get max steps (default 5, can be extended with $5 payment)
                max_steps = coaching_session.get("max_steps", 5)
                
                # CHECK IF LIMIT REACHED (step 6+ without extension)
                if attempt_number > max_steps:
                    # User has exceeded their allowed steps - send limit reached message
                    is_deescalated = coaching_session.get("is_deescalated", False)
                    
                    await websocket.send(json.dumps({
                        "type": "sanctuary_coaching_limit_reached",
                        "sanctuary_id": sanctuary_id,
                        "attempt_number": attempt_number,
                        "max_steps": max_steps,
                        "is_deescalated": is_deescalated,
                        "options": {
                            "continue_cost": 5.00,
                            "assisted_response_cost": 3.00
                        },
                        "message": f"You've completed {max_steps} coaching exchanges. Would you like to continue or return to your family?"
                    }))
                    
                    # Decrement the attempt since we're not processing this message
                    coaching_session["attempt_number"] = max_steps
                    sanctuary_engine.update_coaching_session(
                        sanctuary_id=sanctuary_id,
                        member_id=member_id,
                        updates={"attempt_number": max_steps}
                    )
                    continue
                
                # Get sanctuary data
                sanctuary_data = sanctuary_engine.get_session(sanctuary_id)
                
                # Generate Little Nate's response
                result = await cortex.process_private_coaching(
                    member_profile=current_profile,
                    sanctuary_data=sanctuary_data,
                    coaching_session=coaching_session,
                    trigger="coaching_response"
                )
                
                # Store Little Nate's response
                sanctuary_engine.add_coaching_message(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id,
                    role="assistant",
                    content=result["response"]
                )
                
                # Update coaching session
                sanctuary_engine.update_coaching_session(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id,
                    updates={
                        "attempt_number": attempt_number,
                        "is_deescalated": result.get("is_deescalated", False)
                    }
                )
                
                # Build response
                response_data = {
                    "type": "sanctuary_coaching_response",
                    "sanctuary_id": sanctuary_id,
                    "coaching_message": {
                        "role": "assistant",
                        "content": result["response"],
                        "attempt_number": attempt_number
                    },
                    "is_deescalated": result.get("is_deescalated", False),
                    # Must respect extensions (max_steps can be > 5)
                    "attempts_remaining": max(0, max_steps - attempt_number)
                }
                
                # Check if should offer assisted response
                if result.get("should_offer_assisted"):
                    response_data["offer_assisted_response"] = True
                    response_data["assisted_response_cost"] = 3.00
                    response_data["assisted_response_message"] = "Would you like me to help craft a response for you? For $3, I can express your feelings in a way your family can hear."
                
                await websocket.send(json.dumps(response_data))


            elif t == "sanctuary_coaching_accept":
                """
                Member accepts coaching offer - START private 1-on-1 session
                """
                sanctuary_id = d.get('sanctuary_id')
                intervention_id = d.get('intervention_id')
                wants_assisted_response = d.get('assisted_response', False)
                
                member_id = current_profile['hardware_id']
                member_name = current_profile.get('name', 'Friend')
                
                # Check if this is member's first coaching
                member_coaching_count = sanctuary_engine.get_member_coaching_count(
                    sanctuary_id, member_id
                )
                
                # Determine charge
                if member_coaching_count == 0:
                    charge_amount = 0.00
                    is_free = True
                else:
                    charge_amount = 5.00
                    is_free = False
                
                # Charge if not free
                if not is_free:
                    sanctuary = sanctuary_engine.get_session(sanctuary_id)
                    charge_result = await sanctuary_engine.charge_coaching(
                        sanctuary_id=sanctuary_id,
                        intervention_id=intervention_id,
                        member_id=member_id,
                        amount=charge_amount
                    )
                    
                    if not charge_result[0]:
                        await websocket.send(json.dumps({
                            "type": "error",
                            "message": "Payment failed. Please try again."
                        }))
                        continue
                
                # Start private coaching session
                coaching_session = sanctuary_engine.start_private_coaching(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id,
                    intervention_id=intervention_id
                )
                
                # Get sanctuary data for context
                sanctuary_data = sanctuary_engine.get_session(sanctuary_id)
                
                # Generate initial coaching message
                result = await cortex.process_private_coaching(
                    member_profile=current_profile,
                    sanctuary_data=sanctuary_data,
                    coaching_session=coaching_session,
                    trigger="coaching_start"
                )
                
                # Store Little Nate's opening message
                sanctuary_engine.add_coaching_message(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id,
                    role="assistant",
                    content=result["response"]
                )
                
                # Increment coaching count
                sanctuary_engine.increment_coaching_count(sanctuary_id, member_id)
                
                # Notify member that coaching started
                free_msg = "🎁 Your first coaching is FREE!" if is_free else f"💰 Coaching: ${charge_amount:.2f}"
                
                sanctuary_total = 0.0
                try:
                    sanctuary_total = float(
                        (sanctuary_engine.get_session(sanctuary_id) or {})
                        .get("billing", {})
                        .get("total_charges", 0.0)
                    )
                except Exception:
                    sanctuary_total = 0.0

                await websocket.send(json.dumps({
                    "type": "sanctuary_coaching_started",
                    "sanctuary_id": sanctuary_id,
                    "intervention_id": intervention_id,
                    "is_free": is_free,
                    "charge_amount": charge_amount,
                    "total_charges": sanctuary_total,
                    "message": free_msg,
                    "coaching_message": {
                        "role": "assistant",
                        "content": result["response"],
                        "attempt_number": 1
                    }
                }))
           
                # BROADCAST to group chat that member stepped away
                cost_text = "FREE" if is_free else f"${charge_amount:.2f}"
                stepped_away_msg = {
                    "message_id": f"SYS_{int(datetime.datetime.now().timestamp())}",
                    "message_type": "SYSTEM",
                    "sender_id": "SYSTEM",
                    "sender_name": "System",
                    "content": f"💙 {member_name} has stepped away for private coaching with Little Nate ({cost_text})",
                    "timestamp": datetime.datetime.now().isoformat()
                }
                
                # Add to sanctuary messages
                sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["messages"].append(stepped_away_msg)
                sanctuary_engine._save()
                
                # Broadcast to all connected members
                await sanctuary_engine.broadcast_to_sanctuary(
                    sanctuary_id=sanctuary_id,
                    message_data={
                        "type": "sanctuary_message",
                        "message": stepped_away_msg,
                    },
                )
                
                # Notify other members and OFFER them coaching too
                sanctuary_data = sanctuary_engine.get_session(sanctuary_id)
                other_members = [m for m in sanctuary_data.get('members', []) if m.get('user_id') != member_id]
                
                for other_member in other_members:
                    other_id = other_member.get('user_id')
                    other_name = other_member.get('name', 'Friend')
                    
                    # SKIP if this member is already in their own coaching session
                    if other_member.get('status') == 'IN_COACHING':
                        print(f">>> [SANCTUARY] Skipping offer to {other_name} - already in coaching")
                        continue
                    
                    # Check if they've used free coaching
                    other_free = not other_member.get('free_coaching_used', False)
                    other_cost = 0.00 if other_free else 5.00
                    
                    # Get their websocket
                    other_ws = sanctuary_engine.get_member_websocket(sanctuary_id, other_id)
                    if other_ws:
                        try:
                            # Send coaching offer (shows popup modal)
                            await other_ws.send(json.dumps({
                                "type": "sanctuary_coaching_offer",
                                "sanctuary_id": sanctuary_id,
                                "intervention_id": f"COACH_OFFER_{other_id}_{int(datetime.datetime.now().timestamp())}",
                                "is_free": other_free,
                                "cost": other_cost,
                                "trigger_member": member_name,
                                "message": f"{member_name} is receiving private coaching. Would you also like coaching support?"
                            }))
                            print(f">>> [SANCTUARY] Sent coaching offer to {other_name} (free={other_free})")
                        except Exception as e:
                            print(f">>> [SANCTUARY] Failed to send offer to {other_name}: {e}")
                            # Fall back to just pause notification
                            try:
                                await other_ws.send(json.dumps({
                                    "type": "sanctuary_member_coaching",
                                    "member_id": member_id,
                                    "member_name": member_name,
                                    "message": f"{member_name} is receiving private support from Little Nate. The sanctuary is paused."
                                }))
                            except:
                                pass


            elif t == "sanctuary_coaching_extend":
                """
                Member pays $5 to continue coaching for 5 more steps
                """
                sanctuary_id = d.get('sanctuary_id')
                member_id = current_profile['hardware_id']
                member_name = current_profile.get('name', 'Friend')
                
                # Get coaching session
                coaching_session = sanctuary_engine.get_coaching_session(sanctuary_id, member_id)
                if not coaching_session or coaching_session.get('status') != 'ACTIVE':
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "No active coaching session found."
                    }))
                    continue
                
                # Charge $5 for extension
                charge_result = await sanctuary_engine.charge_coaching(
                    sanctuary_id=sanctuary_id,
                    intervention_id=coaching_session.get("intervention_id", ""),
                    member_id=member_id,
                    amount=5.00
                )
                
                if not charge_result[0]:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "Payment failed. Please try again."
                    }))
                    continue
                
                # Extend the session by 5 more steps
                current_max = coaching_session.get("max_steps", 5)
                new_max = current_max + 5
                
                sanctuary_engine.update_coaching_session(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id,
                    updates={"max_steps": new_max}
                )
                
                await websocket.send(json.dumps({
                    "type": "sanctuary_coaching_extended",
                    "sanctuary_id": sanctuary_id,
                    "new_max_steps": new_max,
                    "charge_amount": 5.00,
                    "total_charges": float((sanctuary_engine.get_session(sanctuary_id) or {}).get("billing", {}).get("total_charges", 0.0)),
                    "message": f"Your coaching session has been extended! You now have {new_max - coaching_session.get('attempt_number', 0)} more exchanges available. 💙"
                }))
                
                print(f">>> [COACHING] Extended session for {member_name} to {new_max} steps (+$5)")

            elif t == "sanctuary_coaching_complete":
                """
                Member ends private coaching and returns to sanctuary
                """
                sanctuary_id = d.get('sanctuary_id')
                request_assisted_response = d.get('request_assisted_response', False)
                
                member_id = current_profile['hardware_id']
                member_name = current_profile.get('name', 'Friend')
                
                # Get coaching session
                coaching_session = sanctuary_engine.get_coaching_session(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id
                )
                
                if not coaching_session:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "No active coaching session found."
                    }))
                    continue
                
                assisted_response = None
                
                # Generate assisted response if requested
                if request_assisted_response:
                    # Charge $3 for assisted response (distinct ledger type)
                    charge_result = await sanctuary_engine.charge_assisted_response(
                        sanctuary_id=sanctuary_id,
                        member_id=member_id,
                        amount=3.00,
                    )
                    
                    if charge_result[0]:
                        sanctuary_data = sanctuary_engine.get_session(sanctuary_id)
                        
                        result = await cortex.process_private_coaching(
                            member_profile=current_profile,
                            sanctuary_data=sanctuary_data,
                            coaching_session=coaching_session,
                            trigger="generate_assisted_response"
                        )
                        
                        # Parse the assisted response
                        response_text = result.get("response", "")
                        if "SUGGESTED_RESPONSE:" in response_text:
                            parts = response_text.split("SUGGESTED_RESPONSE:")
                            if len(parts) > 1:
                                assisted_part = parts[1]
                                if "EXPLANATION:" in assisted_part:
                                    assisted_response = assisted_part.split("EXPLANATION:")[0].strip()
                                else:
                                    assisted_response = assisted_part.strip()
                        else:
                            assisted_response = response_text
                
                # End the coaching session
                sanctuary_engine.end_coaching_session(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id
                )
                
                # Check if all coaching sessions are complete BEFORE sending completion
                active_coaching = sanctuary_engine.get_active_coaching_sessions(sanctuary_id)
                others_still_coaching = [c for c in active_coaching if c.get('member_id') != member_id]
                sanctuary_is_resumed = len(others_still_coaching) == 0
                
                # Send completion to member with sanctuary status
                await websocket.send(json.dumps({
                    "type": "sanctuary_coaching_completed",
                    "sanctuary_id": sanctuary_id,
                    "message": f"Welcome back, {member_name}. You're ready to reconnect with your family.",
                    "assisted_response": assisted_response,
                    "sanctuary_resumed": sanctuary_is_resumed,
                    "others_in_coaching": len(others_still_coaching),
                }))
                
                # Notify sanctuary that member is back
                await sanctuary_engine.broadcast_to_sanctuary(
                    sanctuary_id=sanctuary_id,
                    message_data={
                        "type": "sanctuary_member_returned",
                        "member_id": member_id,
                        "member_name": member_name,
                        "message": f"{member_name} has returned to the sanctuary."
                    }
                )
                
                # Broadcast resume if all coaching done
                if sanctuary_is_resumed:
                    # All coaching done - sanctuary resumes
                    await sanctuary_engine.broadcast_to_sanctuary(
                        sanctuary_id=sanctuary_id,
                        message_data={
                            "type": "sanctuary_resumed",
                            "message": "Everyone is back. The sanctuary conversation can continue. 💙"
                        }
                    )

            elif t == "sanctuary_request_assisted_response":
                """
                Member requests assisted response during coaching (the $3 add-on)
                """
                sanctuary_id = d.get('sanctuary_id')
                
                member_id = current_profile['hardware_id']
                member_name = current_profile.get('name', 'Friend')
                
                # Get coaching session
                coaching_session = sanctuary_engine.get_coaching_session(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id
                )
                
                if not coaching_session:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "No active coaching session found."
                    }))
                    continue
                
                # Charge $3 for assisted response
                charge_result = await sanctuary_engine.charge_assisted_response(
                    sanctuary_id=sanctuary_id,
                    member_id=member_id,
                    amount=3.00,
                )
                
                if not charge_result[0]:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "Payment failed. Please try again."
                    }))
                    continue
                
                # Get sanctuary data
                sanctuary_data = sanctuary_engine.get_session(sanctuary_id)
                
                # Generate assisted response
                result = await cortex.process_private_coaching(
                    member_profile=current_profile,
                    sanctuary_data=sanctuary_data,
                    coaching_session=coaching_session,
                    trigger="generate_assisted_response"
                )
                
                # Parse the assisted response
                response_text = result.get("response", "")
                assisted_response = ""
                explanation = ""
                
                if "SUGGESTED_RESPONSE:" in response_text:
                    parts = response_text.split("SUGGESTED_RESPONSE:")
                    if len(parts) > 1:
                        assisted_part = parts[1]
                        if "EXPLANATION:" in assisted_part:
                            split_parts = assisted_part.split("EXPLANATION:")
                            assisted_response = split_parts[0].strip()
                            explanation = split_parts[1].strip() if len(split_parts) > 1 else ""
                        else:
                            assisted_response = assisted_part.strip()
                else:
                    assisted_response = response_text
                
                # Send to member
                await websocket.send(json.dumps({
                    "type": "sanctuary_assisted_response_generated",
                    "sanctuary_id": sanctuary_id,
                    "assisted_response": assisted_response,
                    "explanation": explanation,
                    "charge_amount": 3.00,
                    "total_charges": float((sanctuary_engine.get_session(sanctuary_id) or {}).get("billing", {}).get("total_charges", 0.0)),
                    "message": "Here's a suggested response. You can edit it before sending, or use it as-is."
                }))


            
            # ENTRY QUESTIONS
            
            
            
            
            
            # COMPLETE SESSION
            
            elif t == "sanctuary_complete":
                """
                COMPLETE SESSION WITH SUMMARY
                
                Uses entry_responses + messages + coaching to generate:
                1. AI summary with personalized insights
                2. Coach history with auto-flagging
                3. Sends summary to each member
                
                Only the CREATOR or HEAD OF HOUSEHOLD can complete the session.
                """
                sanctuary_id = d.get('sanctuary_id')
                print(f">>> [SANCTUARY] Starting session completion for {sanctuary_id}")

                try:
                    analytics_engine.record_event("sanctuary_complete_requested", current_profile.get("hardware_id"), {
                        "sanctuary_id": sanctuary_id,
                        "family_id": (sanctuary_engine.get_session(sanctuary_id) or {}).get("family_id"),
                    })
                except Exception:
                    pass
                
                sanctuary_data = sanctuary_engine.data["active_sanctuaries"].get(sanctuary_id, {})
                if not sanctuary_data:
                    await websocket.send(json.dumps({"type": "error", "message": "Sanctuary not found"}))
                    continue
                
                # Check if current user is allowed to complete
                current_member_id = current_profile.get('hardware_id')
                creator_id = sanctuary_data.get("created_by")
                head_id = sanctuary_data.get("head_of_household_id")
                
                can_complete = current_member_id in [creator_id, head_id]
                if not can_complete:
                    creator_name = sanctuary_data.get("creator_name", "the creator")
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": f"Only {creator_name} or the head of household can complete the sanctuary session."
                    }))
                    print(f">>> [SANCTUARY] User {current_member_id} tried to complete but is not creator ({creator_id}) or head ({head_id})")
                    continue
                
                members = sanctuary_data.get("members", [])
                
                # Notify all: generating summary
                await sanctuary_engine.broadcast_to_sanctuary(
                    sanctuary_id=sanctuary_id,
                    message_data={
                        "type": "sanctuary_generating_summary",
                        "sanctuary_id": sanctuary_id,
                        "message": "Little Nate is preparing your session summary... 💙"
                }
                )
                
              # ============================================
                # GATHER ALL DATA FOR AI SUMMARY
                # ============================================
                
                # Entry questions context (WHY they came, GOALS)
                entry_responses = sanctuary_data.get("entry_responses", {})
                entry_context = ""
                for mid, resp in entry_responses.items():
                    name = resp.get("member_name", mid)
                    entry_context += f"""
{name}:
  - Why entering: {resp.get('why_entering', 'Not provided')}
  - What's happening: {resp.get('whats_happening', 'Not provided')}
  - Goals: {resp.get('goals', 'Not provided')}
  - Feeling at start: {resp.get('feeling_scale', '?')}/10
"""
                
                # Conversation messages
                messages = sanctuary_data.get("messages", [])
                conv_text = "\n".join([
                    f"{m.get('sender_name', '?')}: {m.get('content', '')}"
                    for m in messages[-100:]
                ])
                
                # Coaching sessions
                coaching_sessions = sanctuary_data.get("coaching_sessions", {})
                coaching_summary = f"{len(coaching_sessions)} private coaching session(s)"
                
                # Duration
                created_at = sanctuary_data.get("created_at", datetime.datetime.now().isoformat())
                try:
                    start = datetime.datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                    duration_mins = int((datetime.datetime.now(datetime.timezone.utc) - start).total_seconds() / 60)
                except:
                    duration_mins = 0
                
                member_names = [m.get("name", "Member") for m in members]
                
                # ============================================
                # GENERATE AI SUMMARY
                # ============================================
                
                summary_prompt = f"""You are Little Nate, a compassionate therapeutic AI facilitator for the Family Sanctuary.

Analyze this family session and provide insights that will help each member grow.

FAMILY MEMBERS: {', '.join(member_names)}

ENTRY CONTEXT (what each member shared before starting):
{entry_context if entry_context.strip() else 'No entry responses collected'}

CONVERSATION ({len(messages)} messages over {duration_mins} minutes):
{conv_text if conv_text.strip() else 'No messages recorded'}

COACHING: {coaching_summary}

Generate a therapeutic summary as JSON:
{{
    "key_conflicts": [
        "Brief description of main conflict/tension 1",
        "Brief description of main conflict/tension 2"
    ],
    "points_of_agreement": [
        "Area where family found common ground"
    ],
    "corrective_experiences": [
        "A moment of healing, understanding, or emotional connection"
    ],
    "individual_insights": {{
        "{member_names[0] if member_names else 'Member1'}": {{
            "patterns_observed": "Communication or behavioral patterns you noticed",
            "growth_areas": "Areas for personal development",
            "strengths_shown": "Positive contributions they made",
            "suggested_focus": "What they should focus on moving forward"
        }},
        "{member_names[1] if len(member_names) > 1 else 'Member2'}": {{
            "patterns_observed": "...",
            "growth_areas": "...",
            "strengths_shown": "...",
            "suggested_focus": "..."
        }}
    }},
    "overall_progress": 6,
    "recommended_next_steps": [
        "Specific actionable suggestion 1",
        "Specific actionable suggestion 2",
        "Specific actionable suggestion 3"
    ],
    "coach_notes": "Summary notes for a human coach if they review this session"
}}

IMPORTANT: 
- Include individual_insights for EACH family member by name
- Be warm, encouraging, and growth-focused
- Reference their entry goals in suggested_focus
- Progress score: 1-10 based on how well they met their stated goals"""

                try:
                    summary_response = await call_azure_openai(
                        summary_prompt,
                        system_message="You are a compassionate therapeutic AI. Respond ONLY with valid JSON, no other text.",
                        max_tokens=2500
                    )
                    
                    # Extract JSON from response
                    json_match = re.search(r'\{[\s\S]*\}', summary_response)
                    if json_match:
                        summary_data = json.loads(json_match.group())
                    else:
                        raise ValueError("No valid JSON in AI response")
                    
                    print(f">>> [SANCTUARY] AI summary generated successfully")
                    
                except Exception as e:
                    print(f">>> [SANCTUARY] Summary generation error: {e}")
                    summary_data = {
                        "key_conflicts": ["Please review session manually"],
                        "points_of_agreement": ["Unable to analyze automatically"],
                        "corrective_experiences": [],
                        "individual_insights": {name: {
                            "patterns_observed": "Review needed",
                            "growth_areas": "Discuss with coach",
                            "strengths_shown": "Participated in session",
                            "suggested_focus": "Schedule follow-up"
                        } for name in member_names},
                        "overall_progress": 5,
                        "recommended_next_steps": ["Schedule a follow-up family discussion", "Consider live coaching session"],
                        "coach_notes": f"AI summary failed: {str(e)}. Manual review recommended."
                    }
                
                # ============================================
                # STORE FOR COACH HISTORY
                # ============================================
                
                sanctuary_data["session_summary"] = {
                    "generated_at": datetime.datetime.now().isoformat(),
                    "summary": summary_data,
                    "duration_minutes": duration_mins,
                    "total_messages": len(messages),
                    "coaching_sessions": len(coaching_sessions)
                }
                
                sanctuary_data["completed_at"] = datetime.datetime.now().isoformat()
                sanctuary_data["status"] = "COMPLETED"
                
                # Auto-flag for coach review
                needs_review = False
                review_reasons = []
                
                if duration_mins >= 10080:  # 7+ days
                    needs_review = True
                    review_reasons.append(f"Long session: {duration_mins // 1440} days")
                
                if summary_data.get("overall_progress", 10) <= 4:
                    needs_review = True
                    review_reasons.append(f"Low progress: {summary_data.get('overall_progress')}/10")
                
                # Check for concerning content
                danger_words = ["hurt myself", "suicide", "kill", "abuse", "hit me", "scared", "unsafe"]
                for msg in messages:
                    content_lower = msg.get("content", "").lower()
                    for word in danger_words:
                        if word in content_lower:
                            needs_review = True
                            review_reasons.append(f"Concerning content detected")
                            break
                    if needs_review:
                        break
                
                sanctuary_data["needs_coach_review"] = needs_review
                sanctuary_data["review_reasons"] = review_reasons
                
                # Save to history
                import os as os2
                history_dir = os2.path.join(DATA_DIR, "sanctuary_history")
                os2.makedirs(history_dir, exist_ok=True)
                
                history_path = os2.path.join(history_dir, f"{sanctuary_id}.json")
                with open(history_path, "w") as hf:
                    json.dump(sanctuary_data, hf, indent=2, default=str)
                
                print(f">>> [SANCTUARY] Saved to history: {history_path}")
                print(f">>> [SANCTUARY] Needs coach review: {needs_review} {review_reasons}")
                
                # ============================================
                # SEND PERSONALIZED SUMMARY TO EACH MEMBER
                # ============================================
                
                for member in members:
                    m_id = member.get("user_id")
                    m_name = member.get("name", "Member")
                    
                    # Get their personalized insights
                    personal_insights = summary_data.get("individual_insights", {}).get(m_name, {})
                    
                    ws = sanctuary_engine.get_member_websocket(sanctuary_id, m_id)
                    if ws:
                        try:
                            await ws.send(json.dumps({
                                "type": "sanctuary_summary",
                                "sanctuary_id": sanctuary_id,
                                "summary": {
                                    "key_conflicts": summary_data.get("key_conflicts", []),
                                    "points_of_agreement": summary_data.get("points_of_agreement", []),
                                    "corrective_experiences": summary_data.get("corrective_experiences", []),
                                    "your_insights": personal_insights,
                                    "overall_progress": summary_data.get("overall_progress", 5),
                                    "next_steps": summary_data.get("recommended_next_steps", [])
                                },
                                "session_stats": {
                                    "duration_minutes": duration_mins,
                                    "total_messages": len(messages),
                                    "coaching_sessions": len(coaching_sessions),
                                    "total_charges": float(sanctuary_data.get("billing", {}).get("total_charges", 0.0)),
                                },
                                "message": f"Here's your session summary, {m_name}. Take time to reflect. 💙"
                            }))
                            print(f">>> [SANCTUARY] Sent summary to {m_name}")
                        except Exception as e:
                            print(f">>> [SANCTUARY] Failed to send summary to {m_name}: {e}")

# ============================================
                # UPDATE EACH MEMBER'S STORY.JSON
                # ============================================
                
                for member in members:
                    m_id = member.get("user_id")
                    m_name = member.get("name", "Member")
                    try:
                        await update_client_story(
                            client_id=m_id,
                            member_name=m_name,
                            summary_data=summary_data,
                            messages=messages,
                            coaching_sessions=coaching_sessions,
                            eft_tracker=sanctuary_data.get("eft_tracker") if isinstance(sanctuary_data, dict) else None,
                            reconsolidation_tracker=sanctuary_data.get("reconsolidation_tracker") if isinstance(sanctuary_data, dict) else None,
                        )
                    except Exception as e:
                        print(f">>> [STORY] Failed to update story for {m_name}: {e}")
                
                # ============================================
                # CLOSE SANCTUARY
                # ============================================
                
                # Reve from active
                del sanctuary_engine.data["active_sanctuaries"][sanctuary_id]
                sanctuary_engine._save()
                
                # Clear websocket registry
                # Websockets managed by sanctuary_engine
                
                print(f">>> [SANCTUARY] ✓ Session {sanctuary_id} completed successfully")

            elif t == "sanctuary_entry_responses":
                sanctuary_id = data.get("sanctuary_id")
                responses = data.get("responses", {})
                sanctuary_data = sanctuary_engine.data["active_sanctuaries"].get(sanctuary_id, {})
                if sanctuary_data:
                    if "entry_responses" not in sanctuary_data:
                        sanctuary_data["entry_responses"] = {}
                    sanctuary_data["entry_responses"][member_id] = {
                        **responses,
                        "member_name": member_name,
                        "timestamp": datetime.datetime.now().isoformat()
                    }
                    sanctuary_engine.data["active_sanctuaries"][sanctuary_id] = sanctuary_data
                    sanctuary_engine._save()
                    print(f">>> [SANCTUARY] Entry responses saved for {member_name}")
                    await websocket.send(json.dumps({
                        "type": "sanctuary_entry_complete",
                        "sanctuary_id": sanctuary_id,
                        "message": "Thank you for sharing."
                    }))
                    members = [{"user_id": m.get("user_id"), "name": m.get("name")} for m in sanctuary_data.get("members", [])]
                    await websocket.send(json.dumps({
                        "type": "sanctuary_entry_ready",
                        "sanctuary_id": sanctuary_id,
                        "status": sanctuary_data.get("status", "ACTIVE"),
                        "total_charges": sanctuary_engine.get_total_charges(sanctuary_id),
                        "members": members,
                        "messages": (sanctuary_data.get("messages", []) or [])[-50:]
                    }))

            elif t == "sanctuary_sync_state":
                """
                Sync sanctuary state when app resumes from background
                Returns current coaching status and recent messages
                """
                sanctuary_id = d.get('sanctuary_id')
                member_id = current_profile['hardware_id']
                
                sanctuary_data = sanctuary_engine.get_session(sanctuary_id)
                if not sanctuary_data:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "Sanctuary not found"
                    }))
                    continue

                # If group coaching round is ACTIVE, ensure this member has their private suggestion delivered.
                try:
                    round_obj = sanctuary_data.get("group_coaching_round") or {}
                    if round_obj.get("status") == "ACTIVE":
                        mid = member_id
                        round_obj.setdefault("members_expected", [])
                        if mid not in round_obj["members_expected"]:
                            round_obj["members_expected"].append(mid)
                        round_obj.setdefault("responses", {}).setdefault(mid, {"state": "PENDING"})
                        suggestion = (round_obj.get("suggestions") or {}).get(mid)
                        delivered = (round_obj.get("delivered_to") or {}).get(mid, False)
                        if (not suggestion) or (not delivered):
                            # Build minimal profiles for AI generation
                            def _get_profile_by_hardware_id(hid: str) -> dict:
                                reg = load_registry()
                                for _, v in (reg or {}).items():
                                    p = v.get("profile", {})
                                    if p.get("hardware_id") == hid:
                                        return dict(p)
                                return {"hardware_id": hid, "name": hid}

                            members_now = sanctuary_engine.get_member_list(sanctuary_id)
                            member_profiles = []
                            for m in members_now:
                                hid = m.get("user_id")
                                if not hid:
                                    continue
                                p = _get_profile_by_hardware_id(hid)
                                p["sanctuary_role"] = m.get("role", "MEMBER")
                                p["metrics"] = cortex.metrics.load_metrics(p)
                                p["memory"] = cortex.mem.recall(p, limit=5) or ""
                                member_profiles.append(p)

                            me = next((p for p in member_profiles if p.get("hardware_id") == mid), _get_profile_by_hardware_id(mid))
                            others = [p for p in member_profiles if p.get("hardware_id") != mid]
                            recent_msgs = (sanctuary_data.get("messages") or [])[-15:]
                            sug = await cortex.generate_group_coaching_response(
                                target_member=me,
                                other_members=others,
                                recent_messages=recent_msgs,
                                sanctuary_data=sanctuary_data,
                            )
                            total_charges = float((sanctuary_engine.get_session(sanctuary_id) or {}).get("billing", {}).get("total_charges", 0.0))
                            payload = {
                                "suggested_text": sug.get("suggested_response", ""),
                                "rationale": sug.get("rationale", ""),
                                "target_audience": sug.get("target_audience", "the family"),
                                "emotional_tone": sug.get("emotional_tone", "supportive"),
                                "total_charges": total_charges,
                            }
                            round_obj.setdefault("suggestions", {})[mid] = payload
                            round_obj.setdefault("delivered_to", {})[mid] = True
                            sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["group_coaching_round"] = round_obj
                            sanctuary_engine._save()
                            await websocket.send(json.dumps({
                                "type": "sanctuary_suggested_response",
                                "sanctuary_id": sanctuary_id,
                                **payload,
                            }))
                except Exception as e:
                    print(f">>> [GROUP COACHING] state_sync delivery error: {e}")
                
                # Check if anyone is in active coaching
                coaching_sessions = sanctuary_data.get('coaching_sessions', {})
                active_coaching = []
                for cs in coaching_sessions.values():
                    if cs.get('status') == 'ACTIVE':
                        active_coaching.append({
                            "member_id": cs.get('member_id'),
                            "member_name": cs.get('member_name', 'A family member')
                        })
                
                # Check if THIS member is in coaching
                my_coaching = None
                for cs in coaching_sessions.values():
                    if cs.get('member_id') == member_id and cs.get('status') == 'ACTIVE':
                        my_coaching = cs
                        break
                
                is_paused = len(active_coaching) > 0 and not my_coaching
                
                # Ensure base fee is actually recorded (self-heals older sanctuaries or earlier failures).
                try:
                    s_now = sanctuary_engine.get_session(sanctuary_id) or {}
                    billing_now = (s_now.get("billing") or {}) if isinstance(s_now, dict) else {}
                    if not bool(billing_now.get("base_fee_charged", False)):
                        hoh_id = (s_now.get("head_of_household_id") if isinstance(s_now, dict) else None)
                        if hoh_id:
                            await sanctuary_engine.charge_base_fee(sanctuary_id=sanctuary_id, head_of_household_id=hoh_id)
                            sanctuary_data = sanctuary_engine.get_session(sanctuary_id) or sanctuary_data
                except Exception as e:
                    print(f">>> [SANCTUARY] Base fee self-heal failed: {e}")

                # Keep cooldown display consistent with enforcement
                try:
                    import os as _os
                    GROUP_COACHING_COOLDOWN_SECONDS = int(_os.getenv("SANCTUARY_GROUP_COACHING_COOLDOWN_SECONDS", "300") or 300)
                except Exception:
                    GROUP_COACHING_COOLDOWN_SECONDS = 300

                await websocket.send(json.dumps({
                    "type": "sanctuary_state_sync",
                    "sanctuary_id": sanctuary_id,
                    "status": sanctuary_data.get('status', 'ACTIVE'),
                    "is_paused": is_paused,
                    "active_coaching": active_coaching,
                    "my_coaching_active": my_coaching is not None,
                    "members": sanctuary_engine.get_member_list(sanctuary_id),
                    "total_charges": sanctuary_engine.get_total_charges(sanctuary_id),
                    # Itemized billing ledger (best-effort)
                    "billing_charges": ((sanctuary_data.get("billing", {}) or {}).get("charges", []) or [])[-50:],
                    # Provide both keys for backward compatibility across UIs.
                    "recent_messages": (sanctuary_data.get("messages", []) or [])[-20:],
                    "messages": (sanctuary_data.get("messages", []) or [])[-50:],
                    "group_coaching": {
                        "pending_request": sanctuary_data.get("pending_group_coaching_request"),
                        "cooldown_ends_at": int(float(sanctuary_data.get("last_group_coaching_completed", 0) or 0) + GROUP_COACHING_COOLDOWN_SECONDS) if sanctuary_data.get("last_group_coaching_completed") else None,
                        "round": sanctuary_data.get("group_coaching_round"),
                    },
                }))
                
                print(f">>> [SANCTUARY] State sync for {current_profile.get('name')}: paused={is_paused}, coaching={len(active_coaching)}")

            elif t == "sanctuary_exit":
                        """
                        Member wants to exit sanctuary
                        """
                        sanctuary_id = d.get('sanctuary_id')

                        try:
                            analytics_engine.record_event("sanctuary_exit_initiated", current_profile.get("hardware_id"), {
                                "sanctuary_id": sanctuary_id,
                                "family_id": (sanctuary_engine.get_session(sanctuary_id) or {}).get("family_id"),
                            })
                        except Exception:
                            pass
                        
                        # Little Nate checks in first
                        checkin_message = f"""Hi {current_profile['name']},

                    I notice you want to leave the sanctuary. That's okay. This might be overwhelming.

                    Before you go, can you help me understand?
                    • Are you feeling unsafe?
                    • Is this too much to handle right now?
                    • Do you need a break but want to come back later?

                    Your feelings matter. 💙"""
                        
                        await websocket.send(json.dumps({
                            "type": "sanctuary_exit_checkin",
                            "message": checkin_message
                        }))

            elif t == "sanctuary_exit_confirm":
                        """
                        Member confirms exit after check-in
                        """
                        sanctuary_id = d.get('sanctuary_id')
                        reason = d.get('reason', '')
                        inform_family = d.get('inform_family', True)

                        try:
                            analytics_engine.record_event("sanctuary_exit_confirmed", current_profile.get("hardware_id"), {
                                "sanctuary_id": sanctuary_id,
                                "family_id": (sanctuary_engine.get_session(sanctuary_id) or {}).get("family_id"),
                                "reason": (reason or "")[:240],
                                "inform_family": bool(inform_family),
                            })
                        except Exception:
                            pass
                        
                        # Mark member as exited
                        await sanctuary_engine.member_exit(
                            sanctuary_id=sanctuary_id,
                            member_id=current_profile['hardware_id'],
                            reason=reason
                        )
                        
                        # Notify family if requested
                        if inform_family:
                            exit_message = f"{current_profile['name']} is taking a break from the sanctuary. They can rejoin anytime they're ready. 💙"
                            
                            await sanctuary_engine.broadcast_to_sanctuary(
                                sanctuary_id=sanctuary_id,
                                message_data={
                                    "type": "sanctuary_member_exited",
                                    "member_id": current_profile['hardware_id'],
                                    "message": exit_message
                                }
                            )
                        
                        await websocket.send(json.dumps({
                            "type": "sanctuary_exited",
                            "can_rejoin": True
                        }))

            elif t == "sanctuary_extend":
                        """
                        Extend sanctuary for another 24-hour cycle
                        24-hour check-in from Little Nate
                        """
                        sanctuary_id = d.get('sanctuary_id')
                        member_wants_continue = d.get('continue', False)
                        
                        # Record member's response
                        # TODO: Implement extension voting logic
                        
                        await websocket.send(json.dumps({
                            "type": "sanctuary_extend_recorded",
                            "message": "Your response has been recorded. Waiting for other members..."
                        }))

            elif t == "sanctuary_coaching_decline":
                """
                Member declines coaching offer - show them the pause screen IF someone else is in coaching
                """
                sanctuary_id = d.get('sanctuary_id')
                member_id = current_profile['hardware_id']
                
                # Find who IS in coaching to show in the pause message
                sanctuary_data = sanctuary_engine.get_session(sanctuary_id)
                coaching_sessions = sanctuary_data.get('coaching_sessions', {})
                in_coaching = []
                for cs in coaching_sessions.values():
                    if cs.get('status') == 'ACTIVE':
                        in_coaching.append(cs.get('member_name', 'A family member'))
                
                if in_coaching:
                    # Someone is actually in coaching - show pause screen
                    coaching_member = in_coaching[0]
                    await websocket.send(json.dumps({
                        "type": "sanctuary_member_coaching",
                        "member_name": coaching_member,
                        "message": f"{coaching_member} is receiving private support from Little Nate. The sanctuary is paused."
                    }))
                    print(f">>> [SANCTUARY] {current_profile.get('name')} declined coaching, showing pause screen")
                else:
                    # No one is in coaching - send resume so they stay in chat
                    await websocket.send(json.dumps({
                        "type": "sanctuary_resumed",
                        "message": "The sanctuary conversation can continue. 💙"
                    }))
                    print(f">>> [SANCTUARY] {current_profile.get('name')} declined coaching, no one in coaching so resuming")

            elif t == "sanctuary_post_assisted_response":
                """
                Member wants to post their assisted response to the group chat
                """
                sanctuary_id = d.get('sanctuary_id')
                assisted_text = d.get('assisted_response', '')
                member_id = current_profile['hardware_id']
                member_name = current_profile.get('name', 'Friend')
                
                if not assisted_text:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "No assisted response to post"
                    }))
                    continue
                
                # Store the assisted message in sanctuary messages
                message_id = await sanctuary_engine.add_message(
                    sanctuary_id=sanctuary_id,
                    sender_id=member_id,
                    content=assisted_text,
                    message_type="ASSISTED",
                )

                # Fetch the stored message object (last appended) for consistent UI shape
                stored = sanctuary_engine.get_session(sanctuary_id) or {}
                stored_messages = stored.get("messages", [])
                message_obj = stored_messages[-1] if stored_messages else {
                    "message_id": message_id,
                    "message_type": "ASSISTED",
                    "sender_id": member_id,
                    "sender_name": member_name,
                    "content": assisted_text,
                    "timestamp": str(datetime.datetime.now()),
                }
                
                # Broadcast to all members
                await sanctuary_engine.broadcast_to_sanctuary(
                    sanctuary_id=sanctuary_id,
                    message_data={
                        "type": "sanctuary_message",
                        "message": message_obj
                    }
                )
                
                print(f">>> [SANCTUARY] {member_name} posted assisted response to group chat")
                try:
                    analytics_engine.record_event("sanctuary_assisted_response_posted", member_id, {
                        "sanctuary_id": sanctuary_id,
                        "family_id": (sanctuary_engine.get_session(sanctuary_id) or {}).get("family_id"),
                        "message_id": message_obj.get("message_id"),
                        "chars": len((assisted_text or "")),
                    })
                except Exception:
                    pass

            elif t == "sanctuary_group_coaching_approve":
                """
                HEAD approves group coaching - record $20 (test mode supported) and generate personalized suggestions.
                """
                sanctuary_id = d.get("sanctuary_id")
                if not sanctuary_id:
                    continue

                sanctuary_data = sanctuary_engine.get_session(sanctuary_id) or {}
                head_id = sanctuary_data.get("head_of_household_id")
                if current_profile.get("hardware_id") != head_id:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "Only the family HEAD can approve group coaching."
                    }))
                    continue

                try:
                    analytics_engine.record_event("sanctuary_group_coaching_approved", current_profile.get("hardware_id"), {
                        "sanctuary_id": sanctuary_id,
                        "family_id": sanctuary_data.get("family_id"),
                        "cost": 20.00,
                    })
                except Exception:
                    pass

                import time as _time
                now_ts = _time.time()
                active = sanctuary_engine.data["active_sanctuaries"].get(sanctuary_id, {})

                # If a round is already active, don't start another
                existing_round = active.get("group_coaching_round") or {}
                if existing_round.get("status") == "ACTIVE":
                    await websocket.send(json.dumps({
                        "type": "sanctuary_group_coaching_status",
                        "sanctuary_id": sanctuary_id,
                        "state": "ACTIVE",
                    }))
                    continue

                # Move pending request into a real "round" (or synthesize requester if missing)
                pending_req = active.pop("pending_group_coaching_request", None) or {}
                round_id = f"GC_{int(now_ts)}_{secrets.token_hex(3).upper()}"
                requested_by_name = pending_req.get("requested_by_name") or pending_req.get("requested_by") or "A family member"
                requested_text = pending_req.get("requested_text") or ""

                members_now = sanctuary_engine.get_member_list(sanctuary_id)
                expected_ids = [m.get("user_id") for m in members_now if m.get("user_id")]

                # Include invited members even if not yet joined
                invited = (sanctuary_data.get("invited_member_ids") or []) if isinstance(sanctuary_data, dict) else []
                for mid in invited:
                    if mid and mid not in expected_ids:
                        expected_ids.append(mid)

                # Fallback: include *all* family members (by family_id) from registry.
                # This protects the "late joiner" edge case when invited_member_ids is incomplete.
                family_id = (sanctuary_data.get("family_id") if isinstance(sanctuary_data, dict) else None)
                try:
                    if family_id:
                        reg = load_registry() or {}
                        for _, v in reg.items():
                            p = (v or {}).get("profile", {}) or {}
                            if p.get("family_id") == family_id and p.get("hardware_id") and p.get("role") == "CLIENT":
                                fid = p["hardware_id"]
                                if fid not in expected_ids:
                                    expected_ids.append(fid)
                except Exception as e:
                    print(f">>> [GROUP COACHING] family roster fallback error: {e}")

                # Always include HEAD as expected (safety)
                if head_id and head_id not in expected_ids:
                    expected_ids.append(head_id)

                active["group_coaching_round"] = {
                    "round_id": round_id,
                    "status": "ACTIVE",
                    "approved_at": now_ts,
                    "requested_by_name": requested_by_name,
                    "requested_text": requested_text,
                    "members_expected": expected_ids,
                    "suggestions": {},          # member_id -> suggestion payload
                    "delivered_to": {},         # member_id -> bool
                    "responses": {mid: {"state": "PENDING"} for mid in expected_ids},
                }
                sanctuary_engine.data["active_sanctuaries"][sanctuary_id] = active
                sanctuary_engine._save()

                # Charge (or record) $20
                charge_ok, charge_msg = await sanctuary_engine.charge_group_coaching(
                    sanctuary_id=sanctuary_id,
                    amount=20.00,
                    description="Group Coaching Session"
                )
                if not charge_ok:
                    await websocket.send(json.dumps({"type": "error", "message": charge_msg}))
                    continue

                total_charges = float((sanctuary_engine.get_session(sanctuary_id) or {}).get("billing", {}).get("total_charges", 0.0))

                # Notify all (system message)
                system_msg = {
                    "message_id": f"SYS_{int(datetime.datetime.now().timestamp())}",
                    "message_type": "SYSTEM",
                    "sender_id": "SYSTEM",
                    "sender_name": "System",
                    "content": "💙 Group Coaching activated. Little Nate is preparing private, personalized words for each family member...",
                    "timestamp": datetime.datetime.now().isoformat(),
                }
                sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["messages"].append(system_msg)
                sanctuary_engine._save()
                await sanctuary_engine.broadcast_to_sanctuary(
                    sanctuary_id=sanctuary_id,
                    message_data={"type": "sanctuary_message", "message": system_msg}
                )

                # Helper: get a user profile by hardware_id from registry
                def _get_profile_by_hardware_id(hid: str) -> dict:
                    reg = load_registry()
                    for _, v in (reg or {}).items():
                        p = v.get("profile", {})
                        if p.get("hardware_id") == hid:
                            return dict(p)
                    return {"hardware_id": hid, "name": hid}

                members = sanctuary_data.get("members", [])
                member_profiles = []
                for m in members:
                    hid = m.get("user_id") or m.get("id")
                    if not hid:
                        continue
                    profile = _get_profile_by_hardware_id(hid)
                    profile["sanctuary_role"] = (m.get("role") or "MEMBER")
                    profile["metrics"] = cortex.metrics.load_metrics(profile)
                    profile["memory"] = cortex.mem.recall(profile, limit=5) or ""
                    member_profiles.append(profile)

                recent_messages = sanctuary_data.get("messages", [])[-15:]

                # Generate & send each member a private suggestion
                round_obj = (sanctuary_engine.get_session(sanctuary_id) or {}).get("group_coaching_round") or {}
                for profile in member_profiles:
                    hid = profile.get("hardware_id")
                    user_ws = sanctuary_engine.get_member_websocket(sanctuary_id, hid)
                    others = [p for p in member_profiles if p.get("hardware_id") != hid]
                    suggestion = await cortex.generate_group_coaching_response(
                        target_member=profile,
                        other_members=others,
                        recent_messages=recent_messages,
                        sanctuary_data=sanctuary_data
                    )

                    # Persist suggestion for delivery to late joiners/reconnects
                    round_obj = (sanctuary_engine.get_session(sanctuary_id) or {}).get("group_coaching_round") or {}
                    round_obj.setdefault("suggestions", {})[hid] = {
                        "suggested_text": suggestion.get("suggested_response", ""),
                        "rationale": suggestion.get("rationale", ""),
                        "target_audience": suggestion.get("target_audience", "the family"),
                        "emotional_tone": suggestion.get("emotional_tone", "supportive"),
                        "total_charges": total_charges,
                    }
                    round_obj.setdefault("delivered_to", {})[hid] = bool(user_ws)
                    sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["group_coaching_round"] = round_obj
                    sanctuary_engine._save()

                    if user_ws:
                        await user_ws.send(json.dumps({
                            "type": "sanctuary_suggested_response",
                            "sanctuary_id": sanctuary_id,
                            **round_obj["suggestions"][hid],
                        }))

                # Optional: broadcast charge update for any UIs that want it
                await sanctuary_engine.broadcast_to_sanctuary(
                    sanctuary_id=sanctuary_id,
                    message_data={
                        "type": "sanctuary_charge_update",
                        "sanctuary_id": sanctuary_id,
                        "total_charges": total_charges,
                        "latest_charge": {"amount": 20.00, "description": "Group Coaching Session"},
                    }
                )

                # Broadcast ACTIVE status so UIs can lock chat until everyone responds/declines
                waiting_on = []
                try:
                    round_obj = (sanctuary_engine.get_session(sanctuary_id) or {}).get("group_coaching_round") or {}
                    responses = round_obj.get("responses", {}) or {}
                    pending_ids = [mid for mid, r in responses.items() if (r or {}).get("state") == "PENDING"]
                    member_name_map = {m.get("user_id"): m.get("name") for m in sanctuary_engine.get_member_list(sanctuary_id)}
                    waiting_on = [member_name_map.get(mid, mid) for mid in pending_ids]
                except Exception:
                    waiting_on = []

                await sanctuary_engine.broadcast_to_sanctuary(
                    sanctuary_id=sanctuary_id,
                    message_data={
                        "type": "sanctuary_group_coaching_status",
                        "sanctuary_id": sanctuary_id,
                        "state": "ACTIVE",
                        "waiting_on": waiting_on,
                    }
                )

                # NOTE: cooldown starts when the round completes (after all members send/decline)

                print(f">>> [SANCTUARY] Group coaching approved; total_charges={total_charges}")

            elif t == "sanctuary_group_coaching_decline":
                """
                HEAD declines group coaching
                """
                sanctuary_id = d.get("sanctuary_id")
                sanctuary_data = sanctuary_engine.get_session(sanctuary_id) or {}
                head_id = sanctuary_data.get("head_of_household_id")
                if current_profile.get("hardware_id") != head_id:
                    await websocket.send(json.dumps({
                        "type": "error",
                        "message": "Only the family HEAD can decline group coaching."
                    }))
                    continue

                try:
                    analytics_engine.record_event("sanctuary_group_coaching_declined", current_profile.get("hardware_id"), {
                        "sanctuary_id": sanctuary_id,
                        "family_id": sanctuary_data.get("family_id"),
                    })
                except Exception:
                    pass

                # Clear pending request so another member can ask again
                sanctuary_engine.data["active_sanctuaries"][sanctuary_id].pop("pending_group_coaching_request", None)
                sanctuary_engine._save()
                # Broadcast status to clear UI indicator
                await sanctuary_engine.broadcast_to_sanctuary(
                    sanctuary_id=sanctuary_id,
                    message_data={
                        "type": "sanctuary_group_coaching_status",
                        "sanctuary_id": sanctuary_id,
                        "state": "IDLE",
                        "cooldown_ends_at": None,
                    }
                )

                await sanctuary_engine.broadcast_to_sanctuary(
                    sanctuary_id=sanctuary_id,
                    message_data={
                        "type": "sanctuary_message",
                        "message": {
                            "message_id": f"SYS_{int(datetime.datetime.now().timestamp())}",
                            "message_type": "LITTLE_NATE",
                            "sender_id": "LITTLE_NATE",
                            "sender_name": "Little Nate",
                            "content": "I understand. Let’s continue naturally. You can ask for Group Coaching whenever you’re ready. 💙",
                            "timestamp": datetime.datetime.now().isoformat(),
                        }
                    }
                )

            elif t == "sanctuary_send_suggested_response":
                """
                Member sends their suggested response (as-is or edited).
                """
                sanctuary_id = d.get("sanctuary_id")
                response_text = (d.get("response_text") or "").strip()
                was_edited = bool(d.get("was_edited", False))

                if not sanctuary_id or not response_text:
                    continue

                member_id = current_profile["hardware_id"]
                member_name = current_profile.get("name", "Friend")
                msg_type = "COACHED" if not was_edited else "MEMBER_MESSAGE"

                message_id = await sanctuary_engine.add_message(
                    sanctuary_id=sanctuary_id,
                    sender_id=member_id,
                    content=response_text,
                    message_type=msg_type,
                )

                stored = sanctuary_engine.get_session(sanctuary_id) or {}
                stored_messages = stored.get("messages", [])
                message_obj = stored_messages[-1] if stored_messages else {
                    "message_id": message_id,
                    "message_type": msg_type,
                    "sender_id": member_id,
                    "sender_name": member_name,
                    "content": response_text,
                    "timestamp": datetime.datetime.now().isoformat(),
                }

                await sanctuary_engine.broadcast_to_sanctuary(
                    sanctuary_id=sanctuary_id,
                    message_data={"type": "sanctuary_message", "message": message_obj}
                )

                try:
                    analytics_engine.record_event("sanctuary_group_coaching_response_sent", member_id, {
                        "sanctuary_id": sanctuary_id,
                        "family_id": (sanctuary_engine.get_session(sanctuary_id) or {}).get("family_id"),
                        "was_edited": bool(was_edited),
                        "message_type": msg_type,
                    })
                except Exception:
                    pass

                # Mark group coaching response state
                s = sanctuary_engine.get_session(sanctuary_id) or {}
                round_obj = s.get("group_coaching_round") or {}
                if round_obj.get("status") == "ACTIVE":
                    round_obj.setdefault("responses", {}).setdefault(member_id, {})["state"] = "SENT"
                    round_obj["responses"][member_id]["at"] = datetime.datetime.now().isoformat()
                    sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["group_coaching_round"] = round_obj
                    sanctuary_engine._save()

                    # Broadcast updated status + check completion
                    member_name_map = {m.get("user_id"): m.get("name") for m in sanctuary_engine.get_member_list(sanctuary_id)}
                    pending_ids = [mid for mid, r in (round_obj.get("responses") or {}).items() if (r or {}).get("state") == "PENDING"]
                    waiting_on = [member_name_map.get(mid, mid) for mid in pending_ids]

                    if not pending_ids:
                        import time as _time
                        now_ts = _time.time()
                        sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["last_group_coaching_completed"] = now_ts
                        round_obj["status"] = "COMPLETE"
                        sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["group_coaching_round"] = round_obj
                        sanctuary_engine._save()
                        try:
                            analytics_engine.record_event("sanctuary_group_coaching_round_completed", member_id, {
                                "sanctuary_id": sanctuary_id,
                                "family_id": (sanctuary_engine.get_session(sanctuary_id) or {}).get("family_id"),
                                "round_id": round_obj.get("round_id"),
                                "completed_at": now_ts,
                                "completed_via": "SENT",
                                "responses": round_obj.get("responses", {}),
                            })
                        except Exception:
                            pass
                        try:
                            import os as _os
                            GROUP_COACHING_COOLDOWN_SECONDS = int(_os.getenv("SANCTUARY_GROUP_COACHING_COOLDOWN_SECONDS", "300") or 300)
                        except Exception:
                            GROUP_COACHING_COOLDOWN_SECONDS = 300
                        await sanctuary_engine.broadcast_to_sanctuary(
                            sanctuary_id=sanctuary_id,
                            message_data={
                                "type": "sanctuary_group_coaching_status",
                                "sanctuary_id": sanctuary_id,
                                "state": "COOLDOWN",
                                "cooldown_ends_at": int(now_ts + GROUP_COACHING_COOLDOWN_SECONDS),
                                "waiting_on": [],
                            }
                        )
                    else:
                        await sanctuary_engine.broadcast_to_sanctuary(
                            sanctuary_id=sanctuary_id,
                            message_data={
                                "type": "sanctuary_group_coaching_status",
                                "sanctuary_id": sanctuary_id,
                                "state": "ACTIVE",
                                "waiting_on": waiting_on,
                            }
                        )

            elif t == "sanctuary_decline_suggested_response":
                """
                Member declines to send their suggested response.
                """
                sanctuary_id = d.get("sanctuary_id")
                member_id = current_profile.get("hardware_id")
                await websocket.send(json.dumps({
                    "type": "sanctuary_suggestion_declined",
                    "message": "No problem. Take your time — there’s no pressure to respond."
                }))

                if sanctuary_id and member_id:
                    try:
                        analytics_engine.record_event("sanctuary_group_coaching_response_declined", member_id, {
                            "sanctuary_id": sanctuary_id,
                            "family_id": (sanctuary_engine.get_session(sanctuary_id) or {}).get("family_id"),
                        })
                    except Exception:
                        pass
                    s = sanctuary_engine.get_session(sanctuary_id) or {}
                    round_obj = s.get("group_coaching_round") or {}
                    if round_obj.get("status") == "ACTIVE":
                        round_obj.setdefault("responses", {}).setdefault(member_id, {})["state"] = "DECLINED"
                        round_obj["responses"][member_id]["at"] = datetime.datetime.now().isoformat()
                        sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["group_coaching_round"] = round_obj
                        sanctuary_engine._save()

                        member_name_map = {m.get("user_id"): m.get("name") for m in sanctuary_engine.get_member_list(sanctuary_id)}
                        pending_ids = [mid for mid, r in (round_obj.get("responses") or {}).items() if (r or {}).get("state") == "PENDING"]
                        waiting_on = [member_name_map.get(mid, mid) for mid in pending_ids]

                        if not pending_ids:
                            import time as _time
                            now_ts = _time.time()
                            sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["last_group_coaching_completed"] = now_ts
                            round_obj["status"] = "COMPLETE"
                            sanctuary_engine.data["active_sanctuaries"][sanctuary_id]["group_coaching_round"] = round_obj
                            sanctuary_engine._save()
                            try:
                                analytics_engine.record_event("sanctuary_group_coaching_round_completed", member_id, {
                                    "sanctuary_id": sanctuary_id,
                                    "family_id": (sanctuary_engine.get_session(sanctuary_id) or {}).get("family_id"),
                                    "round_id": round_obj.get("round_id"),
                                    "completed_at": now_ts,
                                    "completed_via": "DECLINED",
                                    "responses": round_obj.get("responses", {}),
                                })
                            except Exception:
                                pass
                            try:
                                import os as _os
                                GROUP_COACHING_COOLDOWN_SECONDS = int(_os.getenv("SANCTUARY_GROUP_COACHING_COOLDOWN_SECONDS", "300") or 300)
                            except Exception:
                                GROUP_COACHING_COOLDOWN_SECONDS = 300
                            await sanctuary_engine.broadcast_to_sanctuary(
                                sanctuary_id=sanctuary_id,
                                message_data={
                                    "type": "sanctuary_group_coaching_status",
                                    "sanctuary_id": sanctuary_id,
                                    "state": "COOLDOWN",
                                    "cooldown_ends_at": int(now_ts + GROUP_COACHING_COOLDOWN_SECONDS),
                                    "waiting_on": [],
                                }
                            )
                        else:
                            await sanctuary_engine.broadcast_to_sanctuary(
                                sanctuary_id=sanctuary_id,
                                message_data={
                                    "type": "sanctuary_group_coaching_status",
                                    "sanctuary_id": sanctuary_id,
                                    "state": "ACTIVE",
                                    "waiting_on": waiting_on,
                                }
                            )

            elif t == "sanctuary_request_coach":
                        """
                        Request live coach escalation
                        """
                        sanctuary_id = d.get('sanctuary_id')
                        
                        # TODO: Generate coach summary and notify coach
                        
                        await websocket.send(json.dumps({
                            "type": "coach_notified",
                            "message": "A coach will be notified within 24 hours."
                        }))                     

    except websockets.exceptions.ConnectionClosed:
        print(f">>> [SOCKET] Connection closed for {uid}")
    except Exception as e:
        print(f">>> [ERROR] {type(e).__name__}: {e}")
    finally:
        cortex.unregister(uid, websocket)
        notification_system.unregister_connection(uid, websocket)
        nevedal_handler.cleanup_connection(websocket)


async def main():
    """Start the WebSocket server"""
    print(f"[*] Starting Sovereign Bridge v16.1 on {HOST}:{PORT}")
    print(f"[*] Azure Endpoint: {AZURE_ENDPOINT[:50]}...")
    print(f"[*] Data Directory: {DATA_DIR}")
    
    # Run Night School on startup (async background task)
    asyncio.create_task(night_school.start_session())
    
    async with websockets.serve(handle_client, HOST, PORT):
        print(f"[*] Bridge Online. Awaiting connections...")
        await asyncio.Future()  # Run forever

if __name__ == "__main__":
    asyncio.run(main())
